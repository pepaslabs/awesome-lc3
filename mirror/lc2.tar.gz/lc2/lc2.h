#ifndef __LC2_H__
#define __LC2_H__

#define LC2_VERSION "Version 5.1 (August 4, 2000)"

/* Constants that define properties of the LC-2 ISA */
#define NUM_OPCODES       16
#define OPCODE_SIZE       4       /* bits */
#define WORD_SIZE         16      /* bits */
#define BYTES_PER_WORD    2
#define PGADDR_SIZE       9       /* bits */
#define NUM_REGS          8

enum language_index {

#define DEFISA(OP, STRING) OP,
#include "lc2.def"
#undef DEFISA

NUM_INSTS

};

typedef enum language_index language_index;

#endif
