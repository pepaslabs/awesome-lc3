/******************************************************************************
* File:		xlc2sim.c - LC-2 simulator
* Author:	Matt Postiff, postiffm@umich.edu
* 
* Notices:	(C) Matt Postiff, 1995-1996. ALL RIGHTS RESERVED.
* 		    See the file NOTICE for a full copyright notice.
* 
* EECS 100 -- University of Michigan
* 
* Description:	
* 
* History:	Date		Who	Version	Change
* 		--------	---	-------	-------------------------------
*               8/22/97         MAP     4.0     Change to Motif
*               Fall 1997       MAP     4.0     Fix bugs as reports come in
*               Fall 1998       MAP     4.2     Cleanup and move LC2 specific
*                                                code to cpu.[ch]
*
* To Do:
* get rid of execute_program function
* case 'i' in do_command duplicates code too much?
* add -trace option to dump address/instruction/data trace for debugging
* don't make writing to keyboard data register a fatal error; you could put
* this functionality into the OS!
* can load files that are not legal (like .c files!), do some more checking
* figure out how to position the Exit and File open dialogs near to place
*  of request
* Button3 works in the console window, but something not quite right about it
* center_mem_at_PC problematic, highlight of PC would be nice!
* Error: XawTextSourceScan's 1st parameter must be subclass of asciiSrc.
*   appears when you run a program without the console popped up
*
* NEXT IMMEDIATE STUFF:
*
* lesstif - Motif clone for Linux, under the GNU license. www.lesstif.org
*
******************************************************************************/

#include "global.h"
#include "xlc2sim.h"
#include "cpu.h"
#include "memory.h"
#include "icon.h"
#include <stdlib.h>
#include <unistd.h>
#include "../lc2.h"

#define SYNTAX_MSG "Usage: simulate [\"command\"]\n\t\
See Appendix B for supported commands\n"

/* Not local, but not export so all files don't need setjmp.h */
jmp_buf spim_top_level_env; /* For ^C */

/* The LC-2 requires these variables. */
int stepintotraps = 0;
int insttrace = 0;

int console_is_visible = 0;
int source_file;		/* Program is source, not binary */
int pipe_out;

/*Widget message, console, command;*/
XtAppContext app_context;
XFontStruct *text_font;

FILE *lc2_log = NULL;
FILE *consoleinfile = NULL;

int DISPLAY_LOW = LC2_USER_START_ADDRESS;
/* HP cc: "xlc2sim.c", line 71: warning 558: Empty declaration. WHY? */
int DISPLAY_HIGH = LC2_USER_START_ADDRESS + DEFAULT_DISPLAY_HEIGHT;
int changed_display_size = 0;

static String fallback_resources[] =
{
  /* by Larus, et. al. */
  "*font:		*-courier-medium-r-normal--12-*-75-*",
  "*Label*font:		*-adobe-helvetica-bold-r-*-*-12-*-75-*",
  "*panel*font:		*-adobe-helvetica-medium-r-*-*-12-*-75-*",
  "*ShapeStyle:		Rectangle",
  "*.translations: #override <Ctrl>C: signal_handler()",
  "*dialog*value.translations: #override <Key>Return: confirm()",
  "*Form*left:		ChainLeft",
  "*Form*right:		ChainLeft",
  "*Form*top:		ChainTop",
  "*Form*bottom:	ChainTop",

  /* by Matt Postiff */
  "*iconName:                 LC-2 Simulator",
  "*foreground:               black",
  "*background:               white",
  "*topLevel.geometry:        675x680+0+0",
  "*console_shell.geometry:   560x335-0-0",
  "*console_shell*iconName:   LC-2 Console",
  "*console_shell*foreground: lightgray",
  "*console_shell*background: black",

  NULL
};

void delete_char(void)
{
  printf("delete_char::called\n");
}

static XtActionsRec actionTable[] =
{
  {"confirm", (XtActionProc) confirm},
  {"signal_handler", (XtActionProc) signal_handler}
};

static XtResource resources[] =
{
  {XtNfont, XtCFont, XtRString, sizeof (char *),
   XtOffset (AppResources *, textFont), XtRString, NULL}
};

Dimension app_width;
Dimension button_height;
Dimension reg_min_height;
Dimension reg_max_height;
Dimension mem_watch_height;
Dimension info_height;
Dimension console_height;
Dimension console_width;
Widget topLevel, paned_window, console_shell;
int RUNNING = 0;
int INITIALIZING = 1;

void initialize (AppResources app_res)
{
  if (app_res.textFont == NULL) {
    app_res.textFont = (String)XtNewString ("*-courier-medium-r-normal--12-*-75-*");
  }
  if (!(text_font = XLoadQueryFont (XtDisplay (topLevel),
				    app_res.textFont))) {
    error (FATAL, "Cannot open font '%s'\n", app_res.textFont);
  }

  button_height    = (Dimension) (TEXTHEIGHT * 1.6);
  app_width        = 720; /* TEXTWIDTH * 4 * 22; */  /* 4 reg values per row plus 1 extra */
  reg_min_height   = 6 * TEXTHEIGHT + 4;
  reg_max_height   = reg_min_height + 8 * TEXTHEIGHT + 4;
  mem_watch_height = 20 * TEXTHEIGHT + 1;
  info_height      = 12 * TEXTHEIGHT + 4;
  console_height   = 24 * TEXTHEIGHT;
  console_width    = 80 * TEXTWIDTH;
}

int main(int argc, char **argv)
{
  AppResources app_res;
  Arg al[10];
  int ac, i, num_commands;
  Display *display;

  lc2_log = fopen("./lc2.log", "w");

  lc2_record_simulator_startup_path(argv[0]);

  // Initialize Xt Intrinsics - modified from 
  // http://www.cs.stedwards.edu/usr/man/info/C/a_doc_lib/motif/motifpg/toc.htm
  //  topLevel = XtAppInitialize(&app_context, "topLevel",
  //			     (XrmOptionDescList) NULL, 0, &argc, argv,
  //			     (String *) NULL, (ArgList) NULL, 0);
  //  display = XtDisplay(topLevel);
 
  topLevel = XtOpenApplication(&app_context, "topLevel", NULL, ZERO,
  			       &argc, argv,
  			       fallback_resources, applicationShellWidgetClass, NULL, ZERO);

  XtAppAddActions (app_context, actionTable, XtNumber (actionTable));

  XtGetApplicationResources (topLevel, (XtPointer) &app_res, resources,
  			     XtNumber (resources), NULL, ZERO);

  initialize (app_res);

  paned_window = create_sub_windows (topLevel, app_width,
				     reg_min_height, reg_max_height,
				     button_height, mem_watch_height,
				     info_height, console_height);

  /*
   static char addXlations[] = "#override\n\
 ~Shift~Ctrl~Meta~Alt<Key>osfDelete: delete-previous-character()\n\
 ~Shift~Ctrl~Meta~Alt<Key>osfBackSpace: delete-previous-character()";
   static XtTranslations parsed_xlations;
   parsed_xlations = XtParseTranslationTable(addXlations);
*/

  XtRealizeWidget(topLevel);

  ac = 0;
  /*  XtSetArg (al[ac], XmNtranslations, parsed_xlations); ac++; */
  XtSetArg (al[ac], XmNallowShellResize, True);  ac++;
  XtSetArg (al[ac], XmNdeleteResponse, XmDO_NOTHING);  ac++;
  XtSetArg (al[ac], XmNiconPixmap,
            XCreateBitmapFromData(XtDisplay(topLevel),
                                  RootWindowOfScreen(XtScreen(topLevel)),
                                  (char *)Icon_bits,
                                  Icon_width,
                                  Icon_height));  ac++;
  XtSetValues (topLevel, al, ac);

  mem_clear();
  lc2_init();
  print_version();

  execute_program (LC2_ROM_BOOT_ADDR, 0, 0); /* run the ROM startup routine */
  lc2_set_PC(LC2_USER_START_ADDRESS);        /* set PC to user start address */
  lc2_unhalt();

  redisplay_data();

  /* set up the signal handlers (non-X) */
  signal(SIGINT, signal_handler);
  /* HP-UX doesn't like the next line */
  /* signal(SIGTSTP, signal_handler); */

  /* if there was a command on the command-line, run it */
  num_commands = argc - 1;
  for (i = 1; i <= num_commands; i++) {
    if (argv[i][0] != '\0') {
      put_str((Widget)info_port, argv[i]);
      put_str((Widget)info_port, "\n");
      do_command(argv[i]);
    }
  }

  XtAppMainLoop(app_context);

  fclose(lc2_log);
  return (0);
}

void syntax (char *program_name)
{
  fprintf (stderr, SYNTAX_MSG);
  exit(1);
}

void signal_handler (int arg)
{
/* printinfo("RUNNING=%d, arg=%d\n", RUNNING, arg); */

  if (RUNNING) {
    printinfo("*** Execution interrupted ***\n");
    redisplay_data ();
    continue_prompt (1);
    longjmp (spim_top_level_env, 1);
  }
  else {
    printinfo("*** Caught stop signal. Please use File|Exit to quit. ***\n");
  }

  /* reset signal handler -- this may be a problem spot */
  signal(arg, signal_handler);
}

void popup_console (Widget w, XtPointer client_data, XtPointer call_data)
{
  if (console_is_visible) {
     console_is_visible = 0;
     XtPopdown (console_shell);
  }
  else {
    console_is_visible = 1;
    XtPopup (console_shell, XtGrabNone);
  }
}

void execute_program (int pc, int steps, int cont_bkpt)
{
  if (!setjmp (spim_top_level_env)) {
      RUNNING = 1;
      if (lc2_run_program (pc, steps, cont_bkpt))
        continue_prompt (0);
  }
  RUNNING = 0;
  redisplay_data ();
}

/* Redisplay the contents of the registers and, if modified, the memory
   contents. */

void redisplay_data (void)
{
  display_registers();
  display_memory();
}

/******************************************************************************
*  display_registers
*    Print the registers in the CPU watch window.
*  Parameters: none
*  Calls: sprintf, XSetArg, XSetValues
*  Returns: none
******************************************************************************/
void display_registers (void)
{
  static String buf;
  String bufp;
  char *grstr;
  char *fill;
  Arg args [2];

  if (buf == NULL)
    buf = (String) malloc(8192);
  *buf = '\0';
  bufp = buf;

  grstr = " R%-2d  = %04x (%5d)", fill = "  ";
  sprintf(bufp, "\t\t\t\tGeneral Purpose Registers\n"); bufp += strlen (bufp);

  sprintf(bufp, grstr, 0, lc2_get_reg(0), lc2_get_reg(0));     bufp += strlen(bufp);
  sprintf(bufp, fill);                                  bufp += strlen(bufp);
  sprintf(bufp, grstr, 1, lc2_get_reg(1), lc2_get_reg(1));     bufp += strlen(bufp);
  sprintf(bufp, fill);                                  bufp += strlen(bufp);
  sprintf(bufp, grstr, 2, lc2_get_reg(2), lc2_get_reg(2));     bufp += strlen(bufp);
  sprintf(bufp, fill);                                  bufp += strlen(bufp);
  sprintf(bufp, grstr, 3, lc2_get_reg(3), lc2_get_reg(3));     bufp += strlen(bufp);
  sprintf(bufp, "\n");                                  bufp += strlen(bufp);
  sprintf(bufp, grstr, 4, lc2_get_reg(4), lc2_get_reg(4));     bufp += strlen(bufp);
  sprintf(bufp, fill);                                  bufp += strlen(bufp);
  sprintf(bufp, grstr, 5, lc2_get_reg(5), lc2_get_reg(5));     bufp += strlen(bufp);
  sprintf(bufp, fill);                                  bufp += strlen(bufp);
  sprintf(bufp, grstr, 6, lc2_get_reg(6), lc2_get_reg(6));     bufp += strlen(bufp);
  sprintf(bufp, fill);                                  bufp += strlen(bufp);
  sprintf(bufp, grstr, 7, lc2_get_reg(7), lc2_get_reg(7));     bufp += strlen(bufp);
  sprintf(bufp, "\n");                                  bufp += strlen(bufp);

  fill = "          ";
  sprintf(bufp, "\n\t\t\t\t    Special Registers\n");   bufp += strlen(bufp);
  sprintf(bufp, " PC   = %04x", lc2_get_PC());          bufp += strlen(bufp);
  sprintf(bufp, fill);                                  bufp += strlen(bufp);
  sprintf(bufp, " IR   = %04x", lc2_get_IR());          bufp += strlen(bufp);
  sprintf(bufp, fill);                                  bufp += strlen(bufp);
  sprintf(bufp, " CC (NZP) = %d%d%d",
	   lc2_get_CCRN(), lc2_get_CCRZ(), lc2_get_CCRP());

  bufp += strlen(bufp);

  XtSetArg(args[0], XtNstring, buf);
  XtSetArg(args[1], XtNlength, bufp - buf);
  XtSetValues(reg_window, args, TWO);

  return;
}

/* Display the contents of memory, if they have been modified. */

void display_memory (void)
{
  XmString membuf = NULL; /* memory buffer */
  int i, limit;
  char *bufp;
  Arg al[10];
  int ac;

  if (mem_modified == 0) {     /* save some compute and display time */
    /*    center_mem_at_PC(); */
    return;
  }

  if (changed_display_size == 1) {
    free(membuf);
    membuf = NULL;
    changed_display_size = 0;
  }
  if (membuf == NULL) {
    limit = LINE_LEN * (DISPLAY_HIGH - DISPLAY_LOW + 1);
    membuf = (String) malloc(limit);
    if (!membuf) {
      error(FATAL, "out of memory allocating memory display buffer");
    }
    *membuf = '\0';  /* in case given range is X..Y, where Y < X */
  }
  bufp = membuf;

  for (i = DISPLAY_LOW; i <= DISPLAY_HIGH; i++) {
    mem_print(i, bufp);
    bufp += strlen(bufp);
  }

  ac = 0;
  XtSetArg (al[ac], XtNstring, membuf);  ac++;
  XtSetArg (al[ac], XtNlength, limit);  ac++;
  /*XtSetArg (al[ac], XmNvalue, membuf); ac++;*/
  XtSetValues (mem_window, al, ac);

  /*  center_mem_at_PC(); */
  mem_modified = 0;
  return;
}

/* I/O */

void write_output (port fp, char *string)
{
  Widget w;
  w = (Widget) fp;
  put_str (w, string);   /* may not be portable... */

  /* Look for keyboard input (such as ^C) */
  while (XtAppPending (app_context)) {
      XEvent event;
      XtAppNextEvent (app_context, &event);
      XtDispatchEvent (&event);
  }
}

/* Simulate the semantics of fgets (not gets) on an X window. */
void read_input (char *str, int str_size)
{
  static char buffer[80];
  KeySym key;
  XComposeStatus compose;
  XEvent event;
  char *ptr;

  ptr = str;
  str_size -= 1;		/* Reserve space for null */

  while (1) {
      XtAppNextEvent (app_context, &event);
      if (event.type == KeyPress) {
	  int chars = XLookupString (&event.xkey, buffer, 79, &key, &compose);
	  /*	  printf("key=0x%08X\n", key); */
	  if ((key == XK_Return) || (key == XK_KP_Enter)) {
	      *ptr++ = '\n';
	      *ptr = '\0';
	      return;
	  }
	  /*	  else if ((key == osfXK_BackSpace) || (key == osfXK_Delete)) { */
	  else if ((key == XK_BackSpace) || (key == XK_Delete)) {
	    /* doesn't work on screen, but does in buffer */
	    if (ptr > str) {
	      ptr--;
	      *ptr = '\0';
	      printf("Putting backspace %d\n", '\b');
	    }
	    else {
	      /* doesn't always work */
	      fprintf(stderr, "\a");
	    }
	  }
	  else if (*buffer == 3) /* ^C */
	    XtDispatchEvent (&event);
	  else {
	      int n = (chars < str_size ? chars : str_size);
	      strncpy (ptr, buffer, n);
	      ptr += n;
	      *ptr = '\0';
	      str_size -= n;
	      buffer[chars] = '\0';
	      if (str_size == 0)
		return;
	  }
      }
      else
	XtDispatchEvent (&event);
  }
}

char get_console_char (void)
{
  char buffer[11];
  XEvent event;
  buffer[0] = 0;

  redisplay_data ();

  if (!console_is_visible) {
      XtPopup (console_shell, XtGrabNone);
      console_is_visible = 1;
  }

  /* if there is an file open to provide console input, read from it instead
     of the console */
  if (consoleinfile) {
    if (feof(consoleinfile)) {
      /* close out the stream properly */
      fclose(consoleinfile);
      consoleinfile = NULL;
    }  /* fall through and input from console */
    else {  /* read from the file and return */
      buffer[0] = fgetc(consoleinfile);
      if (*buffer == 13) *buffer = 10;   /* fix up CR's into LF's (HP) */
      if ((*buffer != 0) && (*buffer != EOF)) return buffer[0];
    }
  }

  /* input from the console */
  while (1) {
      XtAppNextEvent (app_context, &event);
      if (event.type == KeyPress) {
	  KeySym key;
	  XComposeStatus compose;
          buffer[0] = 0;   /* zero out the first character just for safety */
	  XLookupString (&event.xkey, buffer, 10, &key, &compose);

	  if (*buffer == 3) {		       /* ^C */
	    XtDispatchEvent (&event);
	  }
	  else if (*buffer != 0) {
            if (*buffer == 13) *buffer = 10;   /* fix up CR's into LF's (HP) */
	    return (buffer[0]);
	  }
      }
      else
	XtDispatchEvent (&event);
  }
}

void put_console_char (char c)
{
  char buf[3];

  buf[0] = c;
  buf[1] = '\0';
  if (!console_is_visible) {
      XtPopup (console_shell, XtGrabNone);
      console_is_visible = 1;
  }
  write_text_to_window ((Widget)console_port, buf);
  fputc(c, lc2_log); fflush(lc2_log);
}

void put_str (Widget w, char *s)
{
  if ((w == console_port) && (!console_is_visible)) {
      XtPopup (console_shell, XtGrabNone);
      console_is_visible = 1;
  }
  write_text_to_window (w, s);
  fputs(s, lc2_log); fflush(lc2_log);
}

void put_char (Widget w, char c)
{
  char buf[3];

  if ((w == console_port) && (!console_is_visible)) {
      XtPopup (console_shell, XtGrabNone);
      console_is_visible = 1;
  }
  buf[0] = c;
  buf[1] = '\0';
  write_text_to_window (w, buf);
  fputs(buf, lc2_log); fflush(lc2_log);
}

void write_text_to_window (Widget w, char *s)
{
  XawTextBlock textblock;
  XawTextPosition ip = XawTextGetInsertionPoint (w);

  if (!s || strlen (s) == 0) return;

  textblock.firstPos = 0;
  textblock.length = strlen (s);
  textblock.ptr = s;
  textblock.format = FMT8BIT;

  XawTextReplace (w, ip, ip, &textblock);
  XawTextSetInsertionPoint (w,
			    XawTextGetInsertionPoint (w) + textblock.length);
}

/******************************************************************************
*  print_registers
*    Format and print the registers. Duplicate of some code above.
*  Parameters: none
*  Returns: none
******************************************************************************/
void print_registers (void)
{
  int i;

  printinfo("\nRegister Contents\n");
  for (i = 0; i < NUM_REGS; i++) {
    printinfo("\tR%-2d  = %04x (%5d)\n", i, lc2_get_reg(i), lc2_get_reg(i));
  }
  printinfo("\tPC   = %04x = %5d\n", lc2_get_PC(), lc2_get_PC());
  printinfo("\tIR   = %04x = %5d\n", lc2_get_IR(), lc2_get_IR());
  printinfo("\tCC (NZP) = %d%d%d\n",
	   lc2_get_CCRN(), lc2_get_CCRZ(), lc2_get_CCRP());
  return;
}

/******************************************************************************
  print_opcodes
    Print a listing of mnemonics and encodings to the information window.
******************************************************************************/
void print_opcodes(void)
{
  int i;

  printinfo("Mnemonic      Opcode\n");
  printinfo("--------      ------\n");

  for (i = 0; i < NUM_OPCODES; i++) {
    printinfo("%8s      %1x (%2d)\n", opcode_list[i], i, i);
  }
}

void print_command_help (void)
{
  printinfo("\nCommand                 \tFunction\n");
  printinfo("------------------------\t------------------------------------------------\n");
  printinfo("b a       = breakpoint a \tToggle breakpoint at address a\n");
  printinfo("c         = clear        \tClear registers (set PC=$3000)\n");
  printinfo("e msg     = echo msg     \tEcho message to log file lc2.log\n");
  printinfo("g [a]     = go [a]       \tRun from current PC or a if specified\n");
  printinfo("h, ?      = help         \tPrint this help message\n");
  printinfo("i         = initialize   \tReinitialize/reload the simulator\n");
  printinfo("l file    = load file    \tLoad code from file\n");
  printinfo("m a1 [a2] = mdump a1 [a2]\tDump memory address a1, through a2 if specified\n");
  printinfo("n file    = console file \tRead input from file as if it were console\n");
  printinfo("p         = pause        \tWait for a keypress before continuing\n");
  printinfo("q         = quit         \tQuit the simulator\n");
  printinfo("r         = rdump        \tDump contents of all registers\n");
  printinfo("t         = trace        \tToggle instruction trace mode\n");
  printinfo("s [n]     = step [n]     \tExecute 1 [n] instructions from PC\n");
  printinfo("w loc val = write loc val \tWrite memory or register\n");
  printinfo("x file    = xecute file \teXecute script in file\n\n");
}

void print_syntax (void)
{
 printinfo(SYNTAX_MSG);
}

void print_README (void)
{
  printinfo("README file not yet written\n");
}

/******************************************************************************
* alloc_string
* allocates and initializes a string
******************************************************************************/
char *alloc_string(char *strptr, char *init)
{
  if (strptr) { free(strptr); }   /* don't free if already NULL */
  strptr = (char *) malloc (strlen(init) + 1);
  strcpy(strptr, init);
  return strptr;
}

/******************************************************************************
* Write version, copyright, and author information
******************************************************************************/
void print_version(void)
{
 printinfo("LC-2 Simulator %s\n", LC2_VERSION);
 printinfo("Copyright (C) 1995-1999 by Matt Postiff (postiffm@umich.edu)\n");
 printinfo("Portions of X-interface copyright (C) 1990-1994 by James R. Larus (larus@cs.wisc.edu).\n");
 printinfo("ALL RIGHTS RESERVED.\n\n");
 printinfo("See the file NOTICE in the source distribution for a full copyright notice.\n\n");
}

/* Execute the given script command; destroys the origcmd buffer */
void do_command(char *origcmd)
{
  unsigned long addr = 0;
  unsigned long from, to;
  FILE *infile;
  char *loc, *val;
  char buf[BUFLEN];
  char cmdchar;
  char *cmd = origcmd;
  int steps;

  while (isspace(*cmd) && *cmd) cmd++;    /* ignore leading whitespace */
  cmdchar = tolower(*cmd);                /* grab the command character */
  while (!isspace(*cmd) && *cmd) cmd++;   /* move past first (command) word */
  while (isspace(*cmd) && *cmd) cmd++;
  if (origcmd[strlen(origcmd)-1] == '\n') origcmd[strlen(origcmd)-1] = '\0';

  switch (cmdchar) {  /* each command has a unique first character */
  case 'b': /* toggle breakpoint at addr */
      addr = parse_val(cmd);
      if (addr > 0x0000FFFF) {
        error(NORMAL, "Address out of range in '%s'\n", origcmd);
      }
      else if (mem_breakpoint(addr)) {
        mem_remove_breakpoint(addr);
      }
      else {
        mem_add_breakpoint(addr);
      }
      break;
  case 'c': /* clear registers */
      lc2_init_regs();
      display_registers();
      break;
  case 'e':
      printinfo("%s\n", cmd);
      break;
  case 'g': /* go [from addr]*/
      addr = parse_val(cmd);
      if (*cmd == '\0') {
	printinfo("Running from address 0x%04X\n",
		     LC2_USER_START_ADDRESS);
	execute_program (LC2_USER_START_ADDRESS, -1, 0);
      }
      else if (addr <= 0x0000FFFF) {
	printinfo("Running from address 0x%04X\n", addr);
	execute_program (addr, -1, 0);
      }
      else {
        error(NORMAL, "Address out of range in '%s'\n", origcmd);
      }
      break;
  case 'h':
  case '?': /* help */
      print_command_help();
      break;
  case 'i': /* intialize machine */
      mem_clear();
      lc2_init();
      print_version();
      redisplay_data();
      break;
  case 'l': {
      int load_address = lc2_load_code(cmd);
      DISPLAY_LOW = load_address;
      DISPLAY_HIGH = load_address + DEFAULT_DISPLAY_HEIGHT;
      changed_display_size = 1; /* both of next flags needed to coerce redraw */
      mem_modified = 1;
      redisplay_data();
      break;
  }
  case 'm':
      from = parse_val (cmd);
      while (!isspace(*cmd) && *cmd) cmd++; 
      while (isspace(*cmd) && *cmd) cmd++;
      to = parse_val (cmd);
      if (streq (cmd, "")) {
	printinfo("Dumping memory location [%04x]\n", from);
	mem_print (from, NULL);
      }
      else {
	printinfo("Dumping memory locations [%04x] to [%04x]\n", from, to);
	for ( ; from <= to; from++) {
	  mem_print (from, NULL);
        }
      }
      break;
  case 'n':
    /* if the consoleinfile is already open, close it */
    if (consoleinfile) {
      printinfo("Closing current console input file\n");
      fclose(consoleinfile);
      consoleinfile = NULL;
    }
    /* open consoleinfile for read and leave it at that */
    if ((consoleinfile = fopen(cmd, "r")) == NULL) {
      error(NORMAL, "Cannot open '%s' for input", cmd);
    }
    else {
      /* otherwise, consoleinfile is not NULL and we are ready to go */
      printinfo("Console input from '%s' until EOF\n", cmd);
    }
    break;
  case 'p':
      error(NORMAL, "Command PAUSE FOR KEYSTROKE not yet implemented\n");
      break;
  case 'q': /* quit */
      printinfo("Quitting at user's request...\n");
      XtDestroyApplicationContext (app_context);
      exit(0);
      break;
  case 'r':
      print_registers();
      break;
  case 's':
      steps = atoi(cmd);
      while (isspace(*cmd) && *cmd) cmd++;
      if (*cmd == '\0') steps = 1; /* default to 1 step if just s is typed */
      if (steps > 0) {
	printinfo("Stepping %d steps from PC=$%04x\n", steps, lc2_get_PC());
        execute_program (lc2_get_PC(), steps, 1);  /* ignore breakpoints */
      }
      else {
        error (NORMAL, "Cannot step 0 or fewer steps (%d).\n", steps);
      }
      break;
  case 't':
    insttrace = !insttrace;
    printinfo("Instruction tracing toggled %s\n",
	      insttrace == 0 ? "off" : "on");
    break;
  case 'w':
      loc = cmd;
      while (!isspace(*cmd) && *cmd) cmd++;   /* separate loc from value */
      *cmd++ = '\0';
      while (isspace(*cmd) && *cmd) cmd++;
      val = cmd;
      set_value_action(loc, val);
      break;
  case 'x':
      /* read the file and (recursively) go through it's commands */
      if ((infile = fopen(cmd, "r")) == NULL) {
        error(NORMAL, "Cannot open script file '%s'\n", cmd);
        break;
      }
      while (fgets(buf, BUFLEN, infile)) {
	if (*buf == '\n') continue;
	do_command(buf);
      }
      fclose(infile);
      break;
  default:
      error(NORMAL, "Unrecognized command '%s'\n", origcmd);
      break;
  }
  return;
}

void set_value_action (char *location_str, char *value_str)
{
  unsigned long value = 0xFFFFFFFF;
  unsigned long location = 0xFFFFFFFF;
  int reg_flag = 0;

  if ((*value_str == 0x0) || (*location_str == 0x0)) {
    error (NORMAL, "Empty register/memory location or value\n"); 
    return;
  }

  printinfo("Putting %s into %s\n", value_str, location_str);

  value = parse_val(value_str);
  if (value > 0x0000FFFF) return;
  if ((*location_str == 'r') || (*location_str == 'R')) reg_flag = 1;

  if (streqi (location_str, "CCR"))
    lc2_set_CCR(value);
  else if (streqi (location_str, "IR"))
    error (NORMAL, "Instruction register cannot be modified\n");
  else if (streqi (location_str, "PC"))
    lc2_set_PC(value);
  else {
  location = parse_val(location_str);
  if (reg_flag) {
    if ((location >= 0) && (location < NUM_REGS))
      lc2_set_reg(location, value);
  }
  else if ((value >= 0) && (value <= 0x0000FFFF)) {
    if (mem_in_bounds(location)) {
      mem_write(location, 0x0000FFFF & value);
    }
    else
      error (NORMAL, "Could not process location %04x and/or value %04x\n", location, value);
  }
  }
  redisplay_data ();
}
