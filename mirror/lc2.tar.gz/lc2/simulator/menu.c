/******************************************************************************
* File:		Menu.c - LC-2 simulator
* Author:	Matt Postiff, postiffm@umich.edu
* 
* Notices:	(C) Matt Postiff, 1995-1996. ALL RIGHTS RESERVED.
* 		    See the file NOTICE for a full copyright notice.
* 
* EECS 100 -- University of Michigan
* 
* Description:	Menu creation code.
* 
* History:	Date		Who	Version	Change
* 		--------	---	-------	-------------------------------
*               8/4/97          MAP     1       Created
* 
*      CreateMenuBar() -- a convenience function for creating
*                         the application's menu bar.
* 
*   CreateMenuButton() -- a convenience function for adding
*                         individual buttons to panes within
*                         the menu bar.
* 
*       AddSeparator() -- a convenience function for adding 
*                         separators to panes within the menu bar
* 
*             MenuCB() -- A general-purpose callback
*                         routine used for processing menu commands.
*
******************************************************************************/

#include "menu.h"
#include "dialog.h"
#include "buttons.h"
#include "memory.h"
#include "xlc2sim.h"   /* for info_port; should move to Global? */
/* also for stepintotraps, insttrace, display_registers */
#include "cpu.h"

int    currentView;     /*  This holds the current state of the View menu. */

int    currentOption;   /*  This holds the current option (from the second
			    group of toggles in the Options menu).  */

Widget opt1Toggle, opt2Toggle, opt3Toggle;  /* These are the radio buttons 
					       from the Options menu. */
Widget  popupMenu;

Widget CreateMenuBar (Widget parent)
{
  Widget  menuBar;
  Widget  cascade;
  Widget  pulldownPane;
  Arg al[10];
  int ac;

  XmString  label;

  /* Create menu bar. */
  ac = 0;
  menuBar = XmCreateMenuBar (parent, "menuBar", al, ac);

  /************************************************************
                            F i l e
 ************************************************************/

  ac = 0;
  pulldownPane = XmCreatePulldownMenu (menuBar, "pulldownPane", al, ac);

  /*** Load Program ... ***/
  CreateMenuButton (pulldownPane, NULL, MENU_File_LoadProgram,
		    "Load Program ...", 'P', PushButton, NULL, NULL);

  /*** Load Script ... ***/
  CreateMenuButton (pulldownPane, NULL, MENU_File_LoadScript,
		    "Load&Run Script ...", 'S', PushButton, NULL, NULL);

  /*** Run Script Command ... ***/
  CreateMenuButton (pulldownPane, NULL, MENU_File_RunCommand,
		    "Run Script Command ...", 'C', PushButton, NULL, NULL);

  /* ----------------- */  AddSeparator(pulldownPane);

  /*** Exit ***/
  CreateMenuButton (pulldownPane, NULL, MENU_File_Exit,
		    "Exit ...", 'x', PushButton, "Meta<Key>F4:","Meta+F4");

  /*** File cascade button ****/
  label = XmStringCreateSimple ("File");
  ac = 0;
  XtSetArg (al[ac], XmNsubMenuId, pulldownPane);  ac++;
  XtSetArg (al[ac], XmNlabelString, label);  ac++;
  XtSetArg (al[ac], XmNmnemonic, 'F'); ac++;
  cascade= XmCreateCascadeButtonGadget (menuBar, NULL, al, ac);
  XtManageChild (cascade);
  XmStringFree(label);  

#if 0
  /************************************************************
	                    E d i t
 ************************************************************/

  ac = 0;
  pulldownPane = XmCreatePulldownMenu (menuBar, "pulldownPane", al, ac);

  /*** Undo ***/ CreateMenuButton (pulldownPane, NULL, MENU_Edit_Undo,
				   "Undo", 'U', PushButton,
				   "Meta<Key>BackSpace:","Alt+Backspace");

  /* ----------------- */  AddSeparator(pulldownPane);

  /*** Cut ***/ CreateMenuButton (pulldownPane, NULL, MENU_Edit_Cut,
				  "Cut", 't', PushButton,
				  "Shift<Key>DeleteChar:", "Shift+Del");

  /*** Copy ***/ CreateMenuButton (pulldownPane, NULL, MENU_Edit_Copy,
				   "Copy", 'C', PushButton,
				   "Ctrl<Key>InsertChar:", "Ctrl+Ins");

  /*** Paste ***/ CreateMenuButton (pulldownPane, NULL, MENU_Edit_Paste,
				    "Paste", 'P', PushButton,
				    "Shift<Key>InsertChar:", "Shift+Ins");

  /* ----------------- */  AddSeparator(pulldownPane);

  /*** Clear ***/ CreateMenuButton (pulldownPane, NULL, MENU_Edit_Clear,
				    "Clear", 'e', PushButton,
				    NULL, NULL);

  /*** Delete ***/ CreateMenuButton (pulldownPane, NULL, MENU_Edit_Delete,
				     "Delete", 'D', PushButton,
				     NULL, NULL);

  /*** Edit cascade button ****/
  label = XmStringCreateSimple ("Edit");
  ac = 0;
  XtSetArg (al[ac], XmNsubMenuId, pulldownPane);  ac++;
  XtSetArg (al[ac], XmNlabelString, label);  ac++;
  XtSetArg (al[ac], XmNmnemonic, 'E'); ac++;
  cascade = XmCreateCascadeButtonGadget (menuBar, NULL, al, ac);
  XtManageChild (cascade);
  XmStringFree(label);

#endif

  /************************************************************
           	              R u n
 ************************************************************/

  ac = 0;
  pulldownPane = XmCreatePulldownMenu (menuBar, "pulldownPane", al, ac);

  /*** Run Program... ***/
  CreateMenuButton (pulldownPane, NULL, MENU_Run_RunProgram,
		    "Run Program ...", 'R', PushButton, NULL, NULL);

  /*** Step Program ... ***/
  CreateMenuButton (pulldownPane, NULL, MENU_Run_StepProgram,
		    "Step Program ...", 'S', PushButton, NULL, NULL);

  /* ----------------- */  AddSeparator(pulldownPane);

  /*** Breakpoints ***/
  CreateMenuButton (pulldownPane, NULL, MENU_Run_Breakpoints,
		    "Breakpoints ...", 'B', PushButton, NULL, NULL);

  /*** Run cascade button ****/
  label = XmStringCreateSimple ("Run");
  ac = 0;
  XtSetArg (al[ac], XmNsubMenuId, pulldownPane);  ac++;
  XtSetArg (al[ac], XmNlabelString, label);  ac++;
  XtSetArg (al[ac], XmNmnemonic, 'R'); ac++;
  cascade= XmCreateCascadeButtonGadget (menuBar, NULL, al, ac);
  XtManageChild (cascade);
  XmStringFree(label);


  /************************************************************
           	          Set Values
 ************************************************************/

  ac = 0;
  pulldownPane = XmCreatePulldownMenu (menuBar, "pulldownPane", al, ac);

  /*** Reinitialize Machine ***/
  CreateMenuButton (pulldownPane, NULL, MENU_SetValues_ReinitializeMachine,
		    "Reinitialize machine", 'R', PushButton, NULL, NULL);

  /*** Clear Registers ... ***/
  CreateMenuButton (pulldownPane, NULL, MENU_SetValues_ClearRegisters,
		    "Clear Registers", 'C', PushButton, NULL, NULL);

  /*** Set Register or Memory  ***/
  CreateMenuButton (pulldownPane, NULL, MENU_SetValues_SetRegorMemory,
		    "Set Register or memory", 'S', PushButton, NULL, NULL);

  /*** Set Values cascade button ****/
  label = XmStringCreateSimple ("Set Values");
  ac = 0;
  XtSetArg (al[ac], XmNsubMenuId, pulldownPane);  ac++;
  XtSetArg (al[ac], XmNlabelString, label);  ac++;
  XtSetArg (al[ac], XmNmnemonic, 'S'); ac++;
  cascade= XmCreateCascadeButtonGadget (menuBar, NULL, al, ac);
  XtManageChild (cascade);
  XmStringFree(label);

  /************************************************************
           	          Display
 ************************************************************/

  ac = 0;
  pulldownPane = XmCreatePulldownMenu (menuBar, "pulldownPane", al, ac);

  /*** Memory ... ***/
  CreateMenuButton (pulldownPane, NULL, MENU_Display_Memory,
		    "Memory ...", 'M', PushButton, NULL, NULL);

  /*** Registers ... ***/
  CreateMenuButton (pulldownPane, NULL, MENU_Display_Registers,
		    "Registers", 'R', PushButton, NULL, NULL);

  /*** Set Register or Memory  ***/
  CreateMenuButton (pulldownPane, NULL, MENU_Display_Refresh,
		    "Refresh", 'f', PushButton, NULL, NULL);

  /*** Display cascade button ****/
  label = XmStringCreateSimple ("Display");
  ac = 0;
  XtSetArg (al[ac], XmNsubMenuId, pulldownPane);  ac++;
  XtSetArg (al[ac], XmNlabelString, label);  ac++;
  XtSetArg (al[ac], XmNmnemonic, 'D'); ac++;
  cascade= XmCreateCascadeButtonGadget (menuBar, NULL, al, ac);
  XtManageChild (cascade);
  XmStringFree(label);


  /************************************************************
           	              V i e w
 ************************************************************/

  /* This menu pane demonstrates how setting the XmNradioBehavior resources
     enables the menu pane (a row column manager) to enforce a one-of-many
     selection among its toggle button children.  

     This technique has a side effect worth noting: The MenuCB() routine
     is called twice each time the user chooses a toggle button from the
     menu pane.	 The first call occurs when the row column manager unsets
     the current selection.  The second call occurs when the row column
     manager sets the new selection.  Refer to the MenuCB() routine to
     see how behavior for the View menu is handled.	 */

#if 0
  ac = 0;
  XtSetArg (al[ac], XmNradioBehavior, True);  ac++;
  pulldownPane = XmCreatePulldownMenu (menuBar, "pulldownPane", al, ac);

  /*** As One ***/ CreateMenuButton (pulldownPane, NULL, MENU_View_AsOne,
				     "As One", 'O', RadioButtonOn,
				     NULL, NULL); 
  currentView = MENU_View_AsOne;

  /*** As Two ***/ CreateMenuButton (pulldownPane, NULL, MENU_View_AsTwo,
				     "As Two", 'w', RadioButton,
				     NULL, NULL);

  /*** As Three ***/ CreateMenuButton (pulldownPane, NULL, MENU_View_AsThree,
				       "As Three", 'h', RadioButton,
				       NULL, NULL);

  /*** View cascade button ****/
  label = XmStringCreateSimple ("View");
  ac = 0;
  XtSetArg (al[ac], XmNsubMenuId, pulldownPane);  ac++;
  XtSetArg (al[ac], XmNlabelString, label); ac++;
  XtSetArg (al[ac], XmNmnemonic, 'V'); ac++;
  cascade = XmCreateCascadeButtonGadget (menuBar, NULL, al, ac);
  XtManageChild (cascade);
  XmStringFree(label);
#endif

  /************************************************************
         	          O p t i o n s
 ************************************************************/

  /* This menu pane contains two groups of toggle buttons: One group of
     check boxes, and one group of radio buttons.  Since the pane (row
     column manager) has no way of distinguishing separate groups, radio
     behavior cannot be enforced using the same technique used in the View
     menu.  

     In this case, the radio behavior for the second group of toggle
     buttons is implemented within the MenuCB() routine.  The widget IDs
     for the three radio buttons are saved in variables (eg. opt1Toggle)
     for access within MenuCB(). */

  ac = 0;
  pulldownPane = XmCreatePulldownMenu (menuBar, "pulldownPane", al, ac);

  /*** Step into traps ***/        /* use CheckBoxOn to set initial state */
  CreateMenuButton (pulldownPane, NULL, MENU_Options_StepIntoTraps,
		    "Step into traps", 'S', CheckBox, NULL, NULL);

  /*** Dump Trace of Insts  ***/    /* use CheckBoxOn to set initial state */
  CreateMenuButton (pulldownPane, NULL, MENU_Options_InstTrace,
		    "Dump Instruction Trace", 'D', CheckBox, NULL, NULL);

#if 0
  /* ----------------- */  AddSeparator(pulldownPane);
  
                     opt1Toggle = 
  /*** Option 1 ***/ CreateMenuButton (pulldownPane, NULL, MENU_Options_Opt1,
				       "Option 1", '1', RadioButtonOn,
				       NULL, NULL);
  currentOption = MENU_Options_Opt1;

                     opt2Toggle = 
  /*** Option 2 ***/ CreateMenuButton (pulldownPane, NULL, MENU_Options_Opt2,
				       "Option 2", '2', RadioButton,
				       NULL, NULL);

                     opt3Toggle = 
  /*** Option 3 ***/ CreateMenuButton (pulldownPane, NULL, MENU_Options_Opt3,
				       "Option 3", '3', RadioButton,
				       NULL, NULL);
#endif

  /*** Options cascade button ****/
  label = XmStringCreateSimple ("Options");
  ac = 0;
  XtSetArg (al[ac], XmNsubMenuId, pulldownPane);  ac++;
  XtSetArg (al[ac], XmNlabelString, label); ac++;
  XtSetArg (al[ac], XmNmnemonic, 'O'); ac++;
  cascade = XmCreateCascadeButtonGadget (menuBar, NULL, al, ac);
  XtManageChild (cascade);
  XmStringFree(label);


  /************************************************************
	                   H e l p     
 ************************************************************/

  ac = 0;
  pulldownPane = XmCreatePulldownMenu (menuBar, "pulldownPane", al, ac);

  /*** Instruction Set ***/
  CreateMenuButton (pulldownPane, NULL, MENU_Help_InstructionSet,
		    "Instruction Set", 'I', PushButton, NULL, NULL);

  /*** Simulator Commands ***/
  CreateMenuButton (pulldownPane, NULL, MENU_Help_Commands,
		    "Simulator Commands", 'S', PushButton, NULL, NULL);

  /*** Simulator Syntax ***/
  CreateMenuButton (pulldownPane, NULL, MENU_Help_Syntax,
		    "Simulator Syntax", 'y', PushButton, NULL, NULL);

  /*** View README ***/
  CreateMenuButton (pulldownPane, NULL, MENU_Help_ViewReadme,
		    "View README", 'R', PushButton, NULL, NULL);

#if 0
 /*** On Application ... ***/ CreateMenuButton (pulldownPane, NULL,
						MENU_Help_OnApplication,
						"On Application ...", 'A',
						PushButton, "<Key>F1", "F1");
#endif
  /* ----------------- */  AddSeparator(pulldownPane);

  /*** Version ***/
  CreateMenuButton (pulldownPane, NULL, MENU_Help_Version, 
		    "Version", 'V', PushButton, NULL, NULL);

  /*** Help cascade button ****/
  label = XmStringCreateSimple ("Help");
  ac = 0;
  XtSetArg (al[ac], XmNsubMenuId, pulldownPane);  ac++;
  XtSetArg (al[ac], XmNlabelString, label);  ac++;
  XtSetArg (al[ac], XmNmnemonic, 'H'); ac++;
  cascade = XmCreateCascadeButtonGadget (menuBar, NULL, al, ac);
  XtManageChild (cascade);
  XmStringFree(label);

  /*** Make Help button right-justified in menu bar ***/
  ac = 0;
  XtSetArg (al[ac], XmNmenuHelpWidget, cascade); ac++;
  XtSetValues(menuBar, al, ac);
  
  return(menuBar);

} /* End of the CreateMenuBar() function. */



/******************************************************************************
              C r e a t e   M e n u   B u t t o n   U t i l i t y
******************************************************************************/

Widget CreateMenuButton(Widget parent,
			char *name,
			int buttonID,           /* Values defined in Menu.h */
			char *buttonLabelStr,   /* Values defined in Menu.h */ 
			char buttonMnemonic, 
			int buttonType,
			char *buttonAccelerator,
			char *buttonAcceleratorTextStr)
{
  Widget    button;
  XmString  buttonLabel;
  XmString  buttonAcceleratorText;
  Arg al[10];
  int ac;

  if ((buttonLabelStr) && (strlen(buttonLabelStr) > 0)) {
    buttonLabel = XmStringCreateSimple (buttonLabelStr);
  }
  else {
    buttonLabel = NULL;
  }

  if ((buttonAcceleratorTextStr) && (strlen(buttonAcceleratorTextStr) > 0)) {
    buttonAcceleratorText = XmStringCreateSimple (buttonAcceleratorTextStr);
  }
  else {
    buttonAcceleratorText = NULL;
  }

  ac = 0;
  XtSetArg (al[ac], XmNlabelString, buttonLabel); ac++;
  XtSetArg (al[ac], XmNmnemonic, buttonMnemonic); ac++;
  XtSetArg (al[ac], XmNaccelerator, buttonAccelerator); ac++;
  XtSetArg (al[ac], XmNacceleratorText, buttonAcceleratorText); ac++;

  if (buttonType == CascadeButton)
    {
      button = XmCreateCascadeButtonGadget (parent, NULL, al, ac);
    }
  else if (buttonType == CheckBox    || buttonType == CheckBoxOn ||
	   buttonType == RadioButton || buttonType == RadioButtonOn)
    {
      /* Radio buttons should have one-of-many (diamond shaped) indicator. */
      if (buttonType == RadioButton || buttonType == RadioButtonOn)
	{
	  XtSetArg (al[ac], XmNindicatorType, XmONE_OF_MANY); ac++;
	}

      /* If the toggle button is "on," set the "set" resource. */
      if (buttonType == CheckBoxOn || buttonType == RadioButtonOn)
	{
	  XtSetArg (al[ac], XmNset, True); ac++;
	}

      button = XmCreateToggleButtonGadget (parent, NULL, al, ac);
      XtAddCallback(button, XmNvalueChangedCallback,
		    MenuCB, (XtPointer)buttonID);
    }
  else /* Create a push button by default. */
    {
      button = XmCreatePushButtonGadget (parent, NULL, al, ac);
      XtAddCallback(button, XmNactivateCallback,
		    MenuCB, (XtPointer) buttonID);
    }
  XtManageChild (button);

  XmStringFree(buttonLabel);
  XmStringFree(buttonAcceleratorText);

  return (button);

}



/******************************************************************************
                   A d d   S e p a r a t o r   U t i l i t y
******************************************************************************/

void AddSeparator(Widget parent)
{
  Widget separator;
  Arg al[10];
  int ac;
  
  ac = 0;
  separator = XmCreateSeparatorGadget (parent, NULL, al, ac);
  XtManageChild (separator);
}

void MenuCB (Widget w,              /*  widget id		*/
	     XtPointer client_data, /*  data from application   */
	     XtPointer call_data)   /*  data from widget class  */
{
  Widget commandDialog;
  Widget exitDialog;
  /* Some menu commands may not return immediately, so update  */
  /* the display to prevent the application from looking dead */
  XmUpdateDisplay(topLevel);

  switch ((int)client_data) {
    case MENU_File_LoadProgram:
      XtManageChild(ProgramSelDialog);
      break;
    case MENU_File_LoadScript:
      XtManageChild(ScriptSelDialog);
      break;
    case MENU_File_RunCommand:
      commandDialog = CreateCommandDialog(topLevel, "");
      XtManageChild(commandDialog);
      break;
    case MENU_File_Exit:
      exitDialog = CreateExitDialog(topLevel);
      XtManageChild(exitDialog);
      break;
#if 0
    case MENU_Edit_Undo:
      printf("Edit: Undo!\n");
      break;
    case MENU_Edit_Cut:
      printf("Edit: Cut!\n");
      break;
    case MENU_Edit_Copy:
      printf("Edit: Copy!\n");
      break;
    case MENU_Edit_Paste:
      printf("Edit: Paste!\n");
      break;
    case MENU_Edit_Clear:
      printf("Edit: Clear!\n");
      break;
    case MENU_Edit_Delete:
      printf("Edit: Delete!\n");
      break;
#endif
    case MENU_Run_RunProgram:
      run_prompt(w);
      break;
    case MENU_Run_StepProgram:
      step_prompt(w);
      break;
    case MENU_Run_Breakpoints:
      breakpoint_prompt(w);
      break;
    case MENU_SetValues_ReinitializeMachine:
      mem_clear();
      lc2_init();
      print_version();
      redisplay_data();
      break;
    case MENU_SetValues_ClearRegisters:
      lc2_init_regs();
      display_registers();
      break;
    case MENU_SetValues_SetRegorMemory:
      set_value_prompt(w);
      break;
#if 0
    case MENU_View_AsOne:
    case MENU_View_AsTwo:
    case MENU_View_AsThree:
      /* This MenuCB() routine is called twice each time a choice is
	 made from the View menu: First for the toggle being unset, then
	 for the toggle being set.  Therefore, a response is needed only
	 if the toggle is set and it isn't already the current view.  */

      if (XmToggleButtonGadgetGetState(w) && (int)client_data != currentView)
	{
	  switch ((int)client_data)
	    {
	    case MENU_View_AsOne:
	      printf("View: As One!\n");
	      break;
	    case MENU_View_AsTwo:
	      printf("View: As Two!\n");
	      break;
	    case MENU_View_AsThree:
	      printf("View: As Three!\n");
	      break;
	    }
	  currentView = (int)client_data;
	}
      break;
#endif
    case MENU_Options_StepIntoTraps:
      /*
     printf("Options: Option ");
      switch ((int)client_data)
	{
	case MENU_Options_StepIntoTraps:
	  printf("A");
	  break;
	}
	*/
      if (XmToggleButtonGadgetGetState(w)) {
 	/* the item is toggled on */
	stepintotraps = 1;
	printinfo("Step into traps turned on\n");
      }
      else {
	/* the item is toggled off */
	stepintotraps = 0;
	printinfo("Step into traps turned off\n");
      }
      break;

    case MENU_Options_InstTrace:
      if (XmToggleButtonGadgetGetState(w)) {
 	/* the item is toggled on */
	insttrace = 1;
	printinfo("Instruction tracing turned on\n");
      }
      else {
	/* the item is toggled off */
	insttrace = 0;
	printinfo("Instruction tracing turned off\n");
      }
      break;

#if 0
    case MENU_Options_Opt1:
    case MENU_Options_Opt2:
    case MENU_Options_Opt3:
      /* Enforce radio behavior by clearing all three toggles,
	 then setting the toggle just chosen (w). */
      XmToggleButtonGadgetSetState (opt1Toggle, False, False);
      XmToggleButtonGadgetSetState (opt2Toggle, False, False);
      XmToggleButtonGadgetSetState (opt3Toggle, False, False);
      XmToggleButtonGadgetSetState (w,          True,  False);

      /* Behavior for the current choice goes here.  If the option
	 was already selected, nothing happens. */

      if (currentOption != (int)client_data)
	{
	  currentOption = (int)client_data;

	  switch (currentOption)
	    {
	    case MENU_Options_Opt1:
	      printf("Options: Switched to Option 1!\n");
	      break;
	    case MENU_Options_Opt2:
	      printf("Options: Switched to Option 2!\n");
	      break;
	    case MENU_Options_Opt3:
	      printf("Options: Switched to Option 3!\n");
	      break;
	    }
	}
      break;
#endif
    case MENU_Display_Memory:
      print_mem_prompt(w);
      break;
    case MENU_Display_Registers:
      print_registers();
      break;
    case MENU_Display_Refresh:
      redisplay_data();
      break;

    case MENU_Help_InstructionSet:
      print_opcodes();
      break;
    case MENU_Help_Commands:
      print_command_help();
      break;
    case MENU_Help_Syntax:
      print_syntax();
      break;
    case MENU_Help_ViewReadme:
      print_README();
      break;
    case MENU_Help_Version:
      print_version();
      break;
      
    default:
      /* A client_data was received for which 
	 there is no case setup to handle */
      printf ("Unknown client_data in MenuCB(): 0x%08X\n", (unsigned)client_data);
      break;
    }
}

Widget CreatePopupMenu (Widget parent)
{
  Widget  button;
  Arg al[10];
  int ac;

  XmString  label;

  /* Create the popup menu pane */
  popupMenu = XmCreatePopupMenu(parent, "popupMenu", NULL, 0);
  XtAddEventHandler(parent, ButtonPressMask, False,
		    (XtEventHandler)PostPopup, popupMenu);
  XtAddEventHandler(console_window, ButtonPressMask, False,
		    (XtEventHandler)PostPopup, popupMenu);

  /* Add the pane title (a label gadget) */
  label = XmStringCreateSimple("Common Operations");
  ac = 0;
  XtSetArg(al[ac], XmNlabelString, label); ac++;
  button = XmCreateLabelGadget(popupMenu, NULL, al, ac);
  XtManageChild(button);
  XmStringFree(label);

  /* Add a separator */
  button = XmCreateSeparatorGadget(popupMenu, NULL, NULL, 0);
  XtManageChild(button);

  /* Load Program ... */
  label = XmStringCreateSimple("Load Program ...");
  ac = 0;
  XtSetArg(al[ac], XmNlabelString, label); ac++;
  button = XmCreatePushButtonGadget(popupMenu, NULL, al, ac);
  XtManageChild(button);
  XtAddCallback(button, XmNactivateCallback, MenuCB,
		(XtPointer)MENU_File_LoadProgram);
  XmStringFree(label);

  /* Run Program ... */
  label = XmStringCreateSimple("Run Program ...");
  ac = 0;
  XtSetArg(al[ac], XmNlabelString, label); ac++;
  button = XmCreatePushButtonGadget(popupMenu, NULL, al, ac);
  XtManageChild(button);
  XtAddCallback(button, XmNactivateCallback, MenuCB,
		(XtPointer)MENU_Run_RunProgram);
  XmStringFree(label);

  /* Step Program  */
  label = XmStringCreateSimple("Step Program...");
  ac = 0;
  XtSetArg(al[ac], XmNlabelString, label); ac++;
  button = XmCreatePushButtonGadget(popupMenu, NULL, al, ac);
  XtManageChild(button);
  XtAddCallback(button, XmNactivateCallback, MenuCB,
		(XtPointer)MENU_Run_StepProgram);
  XmStringFree(label);

  /* Breakpoint */
  label = XmStringCreateSimple("Breakpoints ...");
  ac = 0;
  XtSetArg(al[ac], XmNlabelString, label); ac++;
  button = XmCreatePushButtonGadget(popupMenu, NULL, al, ac);
  XtManageChild(button);
  XtAddCallback(button, XmNactivateCallback, MenuCB,
		(XtPointer)MENU_Run_Breakpoints);
  XmStringFree(label);

  /* Run Script Command */
  label = XmStringCreateSimple("Run Script Command ...");
  ac = 0;
  XtSetArg(al[ac], XmNlabelString, label); ac++;
  button = XmCreatePushButtonGadget(popupMenu, NULL, al, ac);
  XtManageChild(button);
  XtAddCallback(button, XmNactivateCallback, MenuCB,
		(XtPointer)MENU_File_RunCommand);
  XmStringFree(label);

  /* Run Script Command */
  label = XmStringCreateSimple("Exit ...");
  ac = 0;
  XtSetArg(al[ac], XmNlabelString, label); ac++;
  button = XmCreatePushButtonGadget(popupMenu, NULL, al, ac);
  XtManageChild(button);
  XtAddCallback(button, XmNactivateCallback, MenuCB,
		(XtPointer)MENU_File_Exit);
  XmStringFree(label);

  return(popupMenu);
}

/*** This function posts the popup menu ***/
void PostPopup(Widget w, Widget popupMenu, XButtonEvent *event)
{
  /* If the even is not a mouse button 3 press, then ignore it */
  if (event->button != Button3) { 
    /*    printf("PostPopup caught non-Button3 event\n"); */
    return;
  }

  /* Use the event to determine where to position the pane */
  XmMenuPosition(popupMenu, event);

  /* Display the menu pane by managing it */
  XtManageChild(popupMenu);
}

void HandleKeystroke(Widget w, Widget popupMenu, XKeyEvent *event)
{
  Widget commandDialog;
  printf("key pressed = %c\n", event->keycode);

  /* popup the script command input dialog */
  commandDialog = CreateCommandDialog(topLevel, "junk");
  /*HERE: position the dialog in the right spot and set focus! */
  XtManageChild(commandDialog);
}
