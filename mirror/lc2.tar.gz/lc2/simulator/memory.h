/******************************************************************************
* File:		memory.h - LC-2 simulator
* Author:	Matt Postiff, postiffm@umich.edu
* 
* Notices:	(C) Matt Postiff, 1995-1996. ALL RIGHTS RESERVED.
* 		    See the file NOTICE for a full copyright notice.
* 
* EECS 100 -- University of Michigan
* 
* Description:	Interface for memory-handling code. Allows simulator-
*                       implementation of memory structures such as ROMs and
*                       RAMs. The unit of memory is the integer. The high
*                       high half of the word is essentially wasted, except
*                       that bit 16 is used as a breakpoint bit.
* 
* History:	Date		Who	Version	Change
* 		--------	---	-------	-------------------------------
* 		7/4/95		MAP	1	Created
* 
******************************************************************************/

#ifndef __MEMORY_H__
#define __MEMORY_H__

extern char *labels[]; /* so disassembler can get at the labels */

void mem_clear(void);
int  mem_read(int address, int do_devices);
void mem_write(int address, int data);
void mem_print(int address, char *result_buffer);
void mem_add_breakpoint(int address);
void mem_remove_breakpoint(int address);
void mem_list_breakpoints(void);
void mem_remove_all_breakpoints(void);
int  mem_breakpoint(int address);
int  mem_in_bounds(int address);
void mem_add_label(char *label, int address);
void mem_erase_label(int address);

extern int mem_modified;

#endif










