/******************************************************************************
* File:		buttons.c - LC-2 simulator
* Author:	Matt Postiff, postiffm@umich.edu
* 
* Notices:	(C) Matt Postiff, 1995-1996. ALL RIGHTS RESERVED.
* 		    See the file NOTICE for a full copyright notice.
* 
* EECS 100 -- University of Michigan
* 
* Description:	Interface to menu bar and button creation code
* 
* History:	Date		Who	Version	Change
* 		--------	---	-------	-------------------------------
*               7/8/95          MAP     1       Created
*               1/1/96          MAP     2       Modified for Wintier 1996
*               8/29/96         MAP     3       Modified for Fall 1996
*
* To Do: Add parse_val error checking; rename other parse_ functions
*        Does dialog box code belong in create_buttons?
*
******************************************************************************/

#include <stdio.h>
#include <setjmp.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdarg.h>

#include "global.h"
#include "xlc2sim.h"
#include "memory.h"
#include "buttons.h"
#include "util.h"
#include "cpu.h"

/* External flags */
extern int console_is_visible;

/* Local variables */
static void (*confirmAction)(Widget, XtPointer, XtPointer) = noop;
char *object_file_name = NULL;	/* Retain last file's name. */

/* *** Run *** */

static char *start_address = NULL;
static Widget run_popup = NULL;
static Widget run_field1_text;

void run_prompt (Widget button)
{
  static char temp[10];
  if (run_popup == NULL) {
      sprintf(temp, "0x%04x", lc2_get_PC());
      start_address = alloc_string(start_address, temp);
      run_popup = popup_one_field_dialog
	(button, "Run Program",
	 "Start Address:", start_address,
	 "Run",
	 run_program_action,
	 NULL, NULL, NULL, NULL,
	 &run_field1_text, 100
	 );
      XtAddCallback (run_popup, XtNdestroyCallback, destroy_run_prompt,
		     (XtPointer) 0);
  }
  confirmAction = run_program_action;
  XtPopup (run_popup, XtGrabNone);
}

void destroy_run_prompt (Widget w, XtPointer client_data,
			     XtPointer call_data)
{
  run_popup = NULL;
}
void run_program_action (Widget w, XtPointer client_data, XtPointer call_data)
{
  Arg args[10];
  String value1;
  Widget form = XtParent (w);
  int addr;

  XtSetArg (args[0], XtNstring, &value1);
  XtGetValues (run_field1_text, args, ONE);
  
  /* remember the last address typed */
  start_address = alloc_string(start_address, value1);

  destroy_popup_prompt (NULL, (XtPointer) form, NULL);

  addr = parse_val (value1);
  printinfo("Running from location %04x\n", addr);
  execute_program (addr, -1, 0);
}

/* *** Step *** */

static char *step_size = NULL;	/* Retain step size */
static Widget step_popup = NULL;
static Widget step_field1_text;

void step_prompt (Widget button)
{
  if (step_popup == NULL) {
      if (step_size == NULL) {
	step_size = alloc_string(step_size, "1");
      }
      step_popup = popup_one_field_dialog (button, "Step Program",
					  "number steps:", step_size,
					  "Step", step_program_action,
					  "Continue", step_continue_action,
					  NULL, NULL,
					  &step_field1_text, 100);
      XtAddCallback (step_popup, XtNdestroyCallback, destroy_step_prompt,
		     (XtPointer) 0);
  }
  confirmAction =  step_program_action;
  XtPopup (step_popup, XtGrabNone);
}

void destroy_step_prompt (Widget w, XtPointer client_data,
				 XtPointer call_data)
{
  step_popup = NULL;
}

void step_program_action (Widget w, XtPointer client_data, XtPointer call_data)
{
  Arg args[10];
  String value1;
  int steps;
  Widget dialog = (Widget) client_data;

  XtSetArg (args[0], XtNstring, &value1);
  XtGetValues (step_field1_text, args, ONE);

  steps = parse_val (value1);
  step_size = alloc_string(step_size, value1);

  if (steps > 0) {
    execute_program (lc2_get_PC(), steps, 1);  /* ignore breakpoints */
    if (lc2_is_halted() == 1) {
	destroy_popup_prompt (NULL, (XtPointer) dialog, (XtPointer) NULL);
	step_popup = NULL;
    }
  }
  else {
    error (NORMAL, "Cannot step 0 or fewer steps (%d).\n", steps);
  }
}

void step_continue_action (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget dialog = (Widget) client_data;

  XtPopdown (XtParent (dialog));
  destroy_popup_prompt (NULL, (XtPointer) dialog, (XtPointer) NULL);
  step_popup = NULL;
  execute_program (lc2_get_PC(), 1, 1);  /* do one instruction, ignore bkpts */
  execute_program (lc2_get_PC(), -1, 0); /* may be incorrect */
}

/* *** Set Value *** */

static Widget set_value_popup = NULL;
static Widget set_field1_text, set_field2_text;

void set_value_prompt (Widget button)
{
  if (set_value_popup == NULL) {
      set_value_popup = popup_two_field_dialog (button, "Set Value",
					   "Register/Memory Location:", "",
					   "                   Value:", "",
					   "Set", parse_set_value,
					   NULL, NULL,
					   &set_field1_text, &set_field2_text);
      XtAddCallback (set_value_popup, XtNdestroyCallback,
		     set_value_destroyed, (XtPointer) 0);
  }
  confirmAction = parse_set_value;
  XtPopup (set_value_popup, XtGrabNone);
}

void parse_set_value (Widget w, XtPointer client_data, XtPointer call_data)
{
  Arg args[10];
  String value1, value2;
  Widget form = XtParent (w);

  XtSetArg (args[0], XtNstring, &value1);
  XtGetValues (set_field1_text, args, ONE);

  XtSetArg (args[0], XtNstring, &value2);
  XtGetValues (set_field2_text, args, ONE);

  destroy_popup_prompt (NULL, (XtPointer) form, NULL);

  set_value_action (value1, value2);
}

void set_value_destroyed (Widget w, XtPointer client_data, XtPointer call_data)
{
  set_value_popup = NULL;
}

static Widget print_popup = NULL;
static Widget print_field1_text, print_field2_text;

void print_mem_prompt (Widget button)
{
  if (print_popup == NULL) {
      print_popup = popup_two_field_dialog (XtParent (button), "Print memory",
					"From:", "",
					"  To:", "",
					"Print", parse_print_value,
					NULL, NULL,
					&print_field1_text,
					&print_field2_text);
      XtAddCallback (print_popup, XtNdestroyCallback, destroy_print_prompt,
		     (XtPointer) 0);
  }
  confirmAction = parse_print_value;
  XtPopup (print_popup, XtGrabNone);
}

void destroy_print_prompt (Widget w, XtPointer client_data,
			     XtPointer call_data)
{
  print_popup = NULL;
}

void parse_print_value (Widget w, XtPointer client_data, XtPointer call_data)
{
  Arg args[10];
  String value1, value2;
  Widget form = XtParent (w);

  XtSetArg (args[0], XtNstring, &value1);
  XtGetValues (print_field1_text, args, ONE);

  XtSetArg (args[0], XtNstring, &value2);
  XtGetValues (print_field2_text, args, ONE);

  XtPopdown (XtParent (form));
  destroy_popup_prompt (NULL, (XtPointer) form, NULL);

  if (!streq (value1, "")) {
      unsigned long from, to;
      from = parse_val (value1);
      to = parse_val (value2);
      if (streq (value2, "")) {
	printinfo("Dumping memory location [%04x]\n", from);
	mem_print (from, NULL);
      }
      else {
	DISPLAY_LOW = from;
	DISPLAY_HIGH = to;
	changed_display_size = 1; /* both of next flags needed to coerce redraw */
	mem_modified = 1;
	redisplay_data();
      }
  }
}

/* *** Breakpoints **** */

static char *bkpt_addr = NULL;    /* Retain last breakpoint address */
static Widget bkpt_popup = NULL;
static Widget bkpt_field1_text;

void breakpoint_prompt(Widget button)
{
  if (bkpt_popup == NULL) {
    bkpt_popup = popup_one_field_dialog (XtParent (button), "Breakpoints",
           				"Address", bkpt_addr,
					"Add", add_breakpoint_action,
					"Delete", delete_breakpoint_action,
					"List", list_breakpoint_action,
					&bkpt_field1_text, 110);
    XtAddCallback (bkpt_popup, XtNdestroyCallback, destroy_bkpt_prompt,
		   (XtPointer) 0);
  }
  confirmAction = add_breakpoint_action;
  XtPopup (bkpt_popup, XtGrabNone);
}

void destroy_bkpt_prompt (Widget w, XtPointer client_data,
				       XtPointer call_data)
{
  bkpt_popup = NULL;
}

void add_breakpoint_action (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget form = XtParent (w);
  Arg args[2];
  String dialog_bkpt_value;
  int addr;

  XtSetArg (args[0], XtNstring, &dialog_bkpt_value);
  XtGetValues (bkpt_field1_text, args, ONE);

  if (!streq(dialog_bkpt_value, "")) {
    addr = parse_val (dialog_bkpt_value);
    bkpt_addr = alloc_string(bkpt_addr, dialog_bkpt_value);
    mem_add_breakpoint (addr);
  }
  destroy_popup_prompt (NULL, (XtPointer) form, (XtPointer) NULL);
}

void delete_breakpoint_action (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget form = XtParent (w);  
  Arg args[2];
  String dialog_bkpt_value;
  int addr;

  XtSetArg (args[0], XtNstring, &dialog_bkpt_value);
  XtGetValues (bkpt_field1_text, args, ONE);

  if (!streq(dialog_bkpt_value, "")) {
    addr = parse_val (dialog_bkpt_value);
    bkpt_addr = alloc_string(bkpt_addr, dialog_bkpt_value);
    mem_remove_breakpoint (addr);
  }
  destroy_popup_prompt (NULL, (XtPointer) form, (XtPointer) NULL);
}

void list_breakpoint_action (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget dialog = (Widget) client_data;
  mem_list_breakpoints ();
  destroy_popup_prompt (NULL, (XtPointer) dialog, (XtPointer) NULL);
  /* remember the value in the box, supposing they typed something in and */
  /* hit list accidentally */
}

/* Unimplemented functionality--have this function be the callback for stuff
   that is not yet implemented. */

/* *** Continue *** */
/* interrupt_seen == 1 if CTRL-C, 0 if hit breakpoint */

static Widget continue_popup = NULL;

void continue_prompt (int interrupt_seen)
{
  Widget dialog;
  Arg args[5];
  Position x, y;
  char msg[256];

  if (continue_popup != NULL) return; /* not XtDestroyWidget(continue_popup);*/

  XtTranslateCoords (topLevel, (Position) 0, (Position) 0, &x, &y);
  XtSetArg (args[0], XtNx, x);
  XtSetArg (args[1], XtNy, y);
  continue_popup = XtCreatePopupShell ("Continue", transientShellWidgetClass,
                                      topLevel, args, TWO);

  XtAddCallback (continue_popup, XtNdestroyCallback,
                 destroy_continue_prompt, (XtPointer) 0);

  if (interrupt_seen)
    sprintf (msg, "Execution interrupt at 0x%04x", lc2_get_PC());
  else
    sprintf (msg, "Breakpoint encountered at 0x%04x", lc2_get_PC());

  XtSetArg (args[0], XtNlabel, msg);
  dialog = XtCreateManagedWidget ("Continue", dialogWidgetClass,
                                  continue_popup, args, ONE);

  XawDialogAddButton (dialog, "Continue", continue_action,
                      (XtPointer) dialog);
  XawDialogAddButton (dialog, "Cancel", destroy_popup_prompt,
                      (XtPointer) dialog);

  confirmAction = continue_action;
  XtPopup (continue_popup, XtGrabNone);
}

void destroy_continue_prompt (Widget w, XtPointer client_data,
			     XtPointer call_data)
{
  continue_popup = NULL;
}

void continue_action (Widget w, XtPointer client_data, 
                             XtPointer call_data)
{
  Widget dialog = (Widget) client_data;

  XtPopdown (XtParent (dialog));
  destroy_popup_prompt (NULL, (XtPointer) dialog, (XtPointer) NULL);
  continue_popup = NULL;
  execute_program (lc2_get_PC(), 1, 1); /* Step over breakpoint */
  execute_program (lc2_get_PC(), 0, 0);  /* will not work right--what if not execing already? */
}

void confirm (Widget widget, XEvent *event, String *params, Cardinal *num_params)
{
  Widget dialog = XtParent (widget);
  (*confirmAction) (widget, (XtPointer) dialog, (XtPointer) NULL);
}

void destroy_popup_prompt (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget popup;
  if (!client_data) return;  /* most likely, w and call_data are NULL */
  popup = XtParent ((Widget) client_data);
  confirmAction = noop;
  XtDestroyWidget (popup);
}

void noop (Widget w, XtPointer client_data, XtPointer call_data)
{ }

Widget
popup_one_field_dialog (Widget button, String name, String field1_label,
			String field1_value, String action_name,
			void (*action) (Widget, XtPointer, XtPointer), String action2_name,
			void (*action2) (Widget, XtPointer, XtPointer), String action3_name,
                        void (*action3) (Widget, XtPointer, XtPointer), Widget *field1_text,
                        unsigned field_widths)
{
  Widget popup, form;
  Widget field1;
  Widget button1, button2, button3, cancelbutton;
  Widget parent = XtParent (button);
  Arg args[10];
  Position x, y;
  static XtActionsRec action_table []
    = {{"warp_to_second_dialog", warp_to_second_dialog},};

  XtTranslateCoords (button, (Position) 0, (Position) 0, &x, &y);

  XtSetArg (args[0], XtNx, x);
  XtSetArg (args[1], XtNy, y);
  popup = XtCreatePopupShell (name, transientShellWidgetClass, parent,
			      args, TWO);

  form = XtCreateManagedWidget ("form", formWidgetClass, popup, NULL, ZERO);

  XtSetArg (args[0], XtNborderWidth, 0);
  XtSetArg (args[1], XtNlabel, field1_label);
  field1 = XtCreateManagedWidget ("field1", labelWidgetClass, form, args,
				  TWO);

  XtSetArg (args[0], XtNfromHoriz, field1);
  XtSetArg (args[1], XtNeditType, "edit");
  XtSetArg (args[2], XtNstring, field1_value);
  XtSetArg (args[3], XtNtype, XawAsciiString);
  XtSetArg (args[4], XtNwidth, field_widths);
  *field1_text = XtCreateManagedWidget ("field1_text", asciiTextWidgetClass,
					form, args, FIVE);
  XtOverrideTranslations (*field1_text,
			 XtParseTranslationTable
			 ("#override \n <Key>Return: confirm()"));

  XtOverrideTranslations (*field1_text,
			 XtParseTranslationTable
			 ("#override \n <Key>osfBackSpace: delete-previous-character()"));
  XtOverrideTranslations (*field1_text,
			 XtParseTranslationTable
			 ("#override \n <Key>osfDelete: delete-previous-character()"));

  XtAppAddActions (app_context, action_table, XtNumber (action_table));

  XtSetArg (args[0], XtNfromVert, *field1_text);
  button1 = XtCreateManagedWidget (action_name, commandWidgetClass, form,
				   args, ONE);
  XtAddCallback (button1, XtNcallback, action, (XtPointer) form);

  if (action2 != NULL) {
      XtSetArg (args[0], XtNfromHoriz, button1);
      XtSetArg (args[1], XtNfromVert,  *field1_text);
      button2 = XtCreateManagedWidget (action2_name, commandWidgetClass, form,
				       args, TWO);
      XtAddCallback (button2, XtNcallback, action2, (XtPointer) form);
  }

  if (action3 != NULL) {
      XtSetArg (args[0], XtNfromHoriz, button2);
      XtSetArg (args[1], XtNfromVert,  *field1_text);
      button3 = XtCreateManagedWidget (action3_name, commandWidgetClass, form,
				       args, TWO);
      XtAddCallback (button3, XtNcallback, action3, (XtPointer) form);
  }

  XtSetArg (args[0], XtNfromHoriz, action2 == NULL ? button1 : (action3 == NULL ? button2 : button3));
  XtSetArg (args[1], XtNfromVert,  *field1_text);
  cancelbutton = XtCreateManagedWidget ("Cancel", commandWidgetClass,
					form, args, TWO);
  XtAddCallback (cancelbutton, XtNcallback, destroy_popup_prompt,
		 (XtPointer) form);

  return (popup);
}

Widget
popup_two_field_dialog (Widget button, String name, String field1_label,
			String field1_value, String field2_label,
			String field2_value, String action_name,
			void (*action) (Widget, XtPointer, XtPointer), String action2_name,
			void (*action2) (Widget, XtPointer, XtPointer), Widget *field1_text,
			Widget *field2_text)
{
  Widget popup, form;
  Widget field1, field2;
  Widget button1, button2, cancelbutton;
  Widget parent = XtParent (button);
  Arg args[10];
  Position x, y;
  static XtActionsRec action_table []
    = {{"warp_to_second_dialog", warp_to_second_dialog},};

  XtTranslateCoords (button, (Position) 0, (Position) 0, &x, &y);

  XtSetArg (args[0], XtNx, x);
  XtSetArg (args[1], XtNy, y);
  popup = XtCreatePopupShell (name, transientShellWidgetClass, parent,
			      args, TWO);

  form = XtCreateManagedWidget ("form", formWidgetClass, popup, NULL, ZERO);

  XtSetArg (args[0], XtNborderWidth, 0);
  XtSetArg (args[1], XtNlabel, field1_label);
  field1 = XtCreateManagedWidget ("field1", labelWidgetClass, form, args,
				  TWO);

  XtSetArg (args[0], XtNfromHoriz, field1);
  XtSetArg (args[1], XtNeditType, "edit");
  XtSetArg (args[2], XtNstring, field1_value);
  XtSetArg (args[3], XtNtype, XawAsciiString);
  *field1_text = XtCreateManagedWidget ("field1_text", asciiTextWidgetClass,
					form, args, FOUR);
  XtOverrideTranslations (*field1_text,
			  XtParseTranslationTable
			  ("#override \n <Key>Return:warp_to_second_dialog()"));
  XtOverrideTranslations (*field1_text,
			  XtParseTranslationTable
			  ("#override \n <Key>Tab:warp_to_second_dialog()"));

  XtOverrideTranslations (*field1_text,
			 XtParseTranslationTable
			 ("#override \n <Key>osfBackSpace: delete-previous-character()"));
  XtOverrideTranslations (*field1_text,
			 XtParseTranslationTable
			 ("#override \n <Key>osfDelete: delete-previous-character()"));
  XtAppAddActions (app_context, action_table, XtNumber (action_table));

  XtSetArg (args[0], XtNfromVert, *field1_text);
  XtSetArg (args[1], XtNborderWidth, 0);
  XtSetArg (args[2], XtNlabel, field2_label);
  field2 = XtCreateManagedWidget ("field2", labelWidgetClass, form, args,
				  THREE);

  XtSetArg (args[0], XtNfromHoriz, field1);
  XtSetArg (args[1], XtNfromVert, *field1_text);
  XtSetArg (args[2], XtNeditType, "edit");
  XtSetArg (args[3], XtNstring, field2_value);
  XtSetArg (args[4], XtNtype, XawAsciiString);
  *field2_text = XtCreateManagedWidget ("field2_text", asciiTextWidgetClass,
					form, args, FIVE);
  XtOverrideTranslations (*field2_text,
			  XtParseTranslationTable
			  ("#override \n <Key>Return: confirm()"));

  XtOverrideTranslations (*field2_text,
			 XtParseTranslationTable
			 ("#override \n <Key>osfBackSpace: delete-previous-character()"));
  XtOverrideTranslations (*field2_text,
			 XtParseTranslationTable
			 ("#override \n <Key>osfDelete: delete-previous-character()"));
  XtSetArg (args[0], XtNfromVert, *field2_text);
  button1 = XtCreateManagedWidget (action_name, commandWidgetClass, form,
				   args, ONE);
  XtAddCallback (button1, XtNcallback, action, (XtPointer) form);

  if (action2 != NULL)
    {
      XtSetArg (args[0], XtNfromHoriz, button1);
      XtSetArg (args[1], XtNfromVert, *field2_text);
      button2 = XtCreateManagedWidget (action2_name, commandWidgetClass, form,
				       args, TWO);
      XtAddCallback (button2, XtNcallback, action2, (XtPointer) form);
    }

  XtSetArg (args[0], XtNfromHoriz, action2 == NULL ? button1 : button2);
  XtSetArg (args[1], XtNfromVert, *field2_text);
  cancelbutton = XtCreateManagedWidget ("Cancel", commandWidgetClass,
					form, args, TWO);
  XtAddCallback (cancelbutton, XtNcallback, destroy_popup_prompt,
		 (XtPointer) form);

  /*  RemapDeleteKey(popup); WHY DO i have to do it above???? */
  return (popup);
}

void warp_to_second_dialog (Widget widget, XEvent *event, 
                                   String *params, Cardinal *num_params)
{
  Widget form = XtParent (widget);
  Widget second_dialog;

  second_dialog = XtNameToWidget (form, "field2_text");
  if (second_dialog)
    XWarpPointer (XtDisplay (second_dialog), None, XtWindow (second_dialog),
		  0, 0, 0, 0, 0, 10);
}

static int RemapDeleteEnabled = 1;

/* for some reason this doesn't work so well! */

/*
** This routine kludges around the problem of backspace not being mapped
** correctly when Motif is used between a server with a delete key in
** the traditional typewriter backspace position and a client that
** expects a backspace key in that position.  Though there are three
** distinct levels of key re-mapping in effect when a user is running
** a Motif application, none of these is really appropriate or effective
** for eliminating the delete v.s. backspace problem.  Our solution is,
** sadly, to eliminate the forward delete functionality of the delete key
** in favor of backwards delete for both keys.  So as not to prevent the
** user or the application from applying other translation table re-mapping,
** we apply re-map the key as a post-processing step, applied after widget
** creation.  As a result, the re-mapping necessarily becomes embedded
** throughout an application (wherever text widgets are created), and
** within library routines, including the Nirvana utility library.  To
** make this remapping optional, the SetDeleteRemap function provides a
** way for an application to turn this functionality on and off.  It is
** recommended that applications that use this routine provide an
** application resource called remapDeleteKey so savvy users can get
** their forward delete functionality back.
*/
void RemapDeleteKey(Widget w)
{
  /* still doesn't work!! */
  static XtTranslations table = NULL;
  static char *translations =
"~Shift~Ctrl~Meta~Alt<Key>osfDelete: delete-previous-character()\n\
~Shift~Ctrl~Meta~Alt<Key>osfBackSpace: delete-previous-character()\n";

  if (RemapDeleteEnabled) {
    if (table == NULL) {
      table = XtParseTranslationTable(translations);
    }
    XtOverrideTranslations(w, table);
  }
}

void SetDeleteRemap(int state)
{
  RemapDeleteEnabled = state;
}
