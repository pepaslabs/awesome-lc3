/******************************************************************************
* File:		windows.h - LC-2 simulator
* Author:	Matt Postiff, postiffm@umich.edu
* 
* Notices:	(C) Matt Postiff, 1995-1996. ALL RIGHTS RESERVED.
* 		    See the file NOTICE for a full copyright notice.
* 
* EECS 100 -- University of Michigan
* 
* Description:	Interface for X-window creation code
* 
* History:	Date		Who	Version	Change
* 		--------	---	-------	-------------------------------
*               8/28/96         MAP     3       Modified for Fall 1996
* 
******************************************************************************/

#ifndef __WINDOWS_H__
#define __WINDOWS_H__

#include "global.h"

void create_reg_window (Widget parent, Dimension app_width, Dimension reg_min_height,
			       Dimension reg_max_height);

void create_mem_window (Widget parent, Dimension app_width, Dimension mem_height);
void center_mem_at_PC (void);

void create_info_window (Widget parent, Dimension app_width, Dimension info_height);
void create_console_window (Widget parent, Dimension console_height);
Widget create_sub_windows (Widget parent, Dimension app_width,
			   Dimension reg_min_height, Dimension reg_max_height,
			   Dimension button_height,
			   Dimension mem_watch_height,
			   Dimension display_height,
			   Dimension console_height);

extern Widget reg_window, mem_window, info_window, console_window;
extern Widget reg_window_label, mem_window_label, 
              info_window_label, console_window_label;
extern port info_port, console_port;

#endif
