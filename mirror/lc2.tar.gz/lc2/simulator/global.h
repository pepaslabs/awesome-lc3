/******************************************************************************
* File:		windows.c - LC-2 simulator
* Author:	Matt Postiff, postiffm@umich.edu
* 
* Notices:	(C) Matt Postiff, 1995-1996. ALL RIGHTS RESERVED.
* 		    See the file NOTICE for a full copyright notice.
* 
* EECS 100 -- University of Michigan
* 
* Description:	Global definitions for the GUI.
* 
* History:	Date		Who	Version	Change
* 		--------	---	-------	-------------------------------
*               8/4/97          MAP     1       Created
* 
******************************************************************************/

#ifndef __GLOBAL_H__
#define __GLOBAL_H__

/* Standard includes */
#include <stdio.h>

/* X includes */
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Shell.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/AsciiText.h>   /* order of include matters ???!!! */
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Dialog.h>
#include <X11/Xaw/Label.h>
#include <X11/Xaw/Paned.h>
#include <X11/Xaw/Box.h>
#include <X11/Xaw/MenuButton.h>
#include <X11/Xaw/SimpleMenu.h>
#include <X11/Xaw/Sme.h>
#include <X11/Xaw/SmeBSB.h>
#include <X11/Xaw/Cardinals.h>
#include <X11/keysym.h>

/* Motif includes */
#include <Xm/MwmUtil.h>
#include <Xm/Xm.h>
#include <Xm/CascadeBG.h>
#include <Xm/CutPaste.h>
#include <Xm/Form.h>
#include <Xm/Label.h>
#include <Xm/LabelG.h>
#include <Xm/MainW.h>
#include <Xm/Text.h>
#include <Xm/MessageB.h>
#include <Xm/PushBG.h>
#include <Xm/PanedW.h>
#include <Xm/RowColumn.h>
#include <Xm/SeparatoG.h>
#include <Xm/ToggleBG.h>
#include <Xm/SelectioB.h>  /* for XmCreatePromptDialog */
#include <Xm/FileSB.h>     /* for XmCreateFileSelectionDialog */
#include <Xm/VirtKeys.h>   /* for osfXK_KEY */

/* Top-level application shell widget and related functions. */
extern Widget topLevel;
extern Widget paned_window;
extern Widget console_shell;

typedef void* port;

#define MAXPATH 256  /* maximum length of file and path name */

#endif
