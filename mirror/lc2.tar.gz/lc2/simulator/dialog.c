/******************************************************************************
* File:		Dialog.h - LC-2 simulator
* Author:	Matt Postiff, postiffm@umich.edu
* 
* Notices:	(C) Matt Postiff, 1995-1996. ALL RIGHTS RESERVED.
* 		    See the file NOTICE for a full copyright notice.
* 
* EECS 100 -- University of Michigan
* 
* Description:	This file contains defines DialogCB(), a general-purpose 
*               callback routine for reacting to button presses within dialogs.
* 
* History:	Date		Who	Version	Change
* 		--------	---	-------	-------------------------------
*               8/7/97          MAP     1       Created from newapp example.
* 
******************************************************************************/

#include "global.h"
#include "dialog.h"
#include "menu.h"
#include "xlc2sim.h"
#include "cpu.h"
#include "memory.h"

/* exported variables */

Widget ProgramSelDialog;
Widget ScriptSelDialog;

void DialogCB (Widget w,                /*  widget id		*/
	       XtPointer client_data,   /*  data from application   */
	       XtPointer call_data)     /*  data from widget class  */
{
  Widget InfoDialog;
  XmSelectionBoxCallbackStruct *scb;
  XmFileSelectionBoxCallbackStruct *fcb;
  char *command;
  char *filename;
  char load_script_command[MAXPATH];
  Arg al[10];
  int ac;
  XmString messageString;

  switch ((int)client_data) {
    case DIALOG_Exit_OK:
      /* Prepare Xt to quit. */
      XtUnmapWidget(topLevel);
      XtDestroyApplicationContext(XtWidgetToApplicationContext(topLevel));

      /* Exit without error. */
      exit(0);
      break;
  case DIALOG_File_LoadProgram: {
      int load_address;
      fcb = (XmFileSelectionBoxCallbackStruct *) call_data;

      /* Get the filename from the file selection box */
      XmStringGetLtoR(fcb->value, XmFONTLIST_DEFAULT_TAG, &filename);
      
      load_address = lc2_load_code(filename);
      DISPLAY_LOW = load_address;
      DISPLAY_HIGH = load_address + DEFAULT_DISPLAY_HEIGHT;
      changed_display_size = 1; /* both of next flags needed to coerce redraw */
      mem_modified = 1;
      redisplay_data();

      /* Popdown the file selection box */
      XtUnmanageChild (ProgramSelDialog);
      break;
  }
    case DIALOG_File_LoadScript:
      fcb = (XmFileSelectionBoxCallbackStruct *) call_data;

      /* Get the filename from the file selection box */
      XmStringGetLtoR(fcb->value, XmFONTLIST_DEFAULT_TAG, &filename);

      strcpy(load_script_command, "x ");
      strcat(load_script_command, filename);
      do_command(load_script_command);

      /* Popdown the file selection box */
      XtUnmanageChild (ScriptSelDialog);
      break;

    case DIALOG_ScriptCommand_OK: 
      scb = (XmSelectionBoxCallbackStruct *) call_data;
      XmStringGetLtoR(scb->value, XmFONTLIST_DEFAULT_TAG, &command);
      put_str((Widget)info_port, command);
      put_str((Widget)info_port, "\n");
      do_command(command);
      /* free the command somehow */
      break;

  case DIALOG_Cancel_LoadProgram:
    XtUnmanageChild(ProgramSelDialog);
    break;
  case DIALOG_Cancel_LoadScript:
    XtUnmanageChild(ScriptSelDialog);
    break;

  case DIALOG_Help_NoHelp:
    ac = 0;
    /* HERE: add string to info window! */
    messageString = XmStringCreateLtoR("No help is available.",
				       XmFONTLIST_DEFAULT_TAG);
    XtSetArg(al[ac], XmNmessageString, messageString); ac++;
    InfoDialog = XmCreateInformationDialog (w, "info", al, ac);
    XtManageChild (InfoDialog);
    XmStringFree(messageString);
    break;
  default:
      /* A client_data was received for which 
	 there is no case setup to handle */
      printf ("Unknown client_data in DialogCB(): 0x%08X\n", (unsigned)client_data);
      break;
    }
}

/******************************************************************************
                C r e a t e   E x i t   D i a l o g
******************************************************************************/

Widget CreateExitDialog(Widget parent)
{
  Widget    dialog;
  XmString  message;
  Arg al[10];
  int ac;
  XmString exitString;

  /* Create the XmStrings needed for creating the dialog. */
  message = XmStringCreateSimple ("Exit LC-2 Simulator?");

  /* Create the dialog widget. */
  ac = 0;
  XtSetArg(al[ac], XmNmessageString, message);  ac++;
  XtSetArg(al[ac], XmNtransient, True);  ac++;
  XtSetArg(al[ac], XmNdialogStyle, XmDIALOG_FULL_APPLICATION_MODAL);  ac++;
  XtSetArg(al[ac], XmNnoResize, True);  ac++;

  /* Change the default 'OK' text to 'Exit' */
  exitString = XmStringCreateLtoR("Exit", XmFONTLIST_DEFAULT_TAG);
  XtSetArg(al[ac], XmNokLabelString, exitString);  ac++;

  dialog = XmCreateQuestionDialog (parent, "exitDialog", al, ac);

  /* Remove the Help button (since there is no help available). */
  XtUnmanageChild (XmMessageBoxGetChild(dialog, XmDIALOG_HELP_BUTTON));

  /* Add the callback for the OK button. */
  XtAddCallback (dialog, XmNokCallback, DialogCB, (XtPointer)DIALOG_Exit_OK);

  /* Free the memory used to create the original XmStrings. */
  XmStringFree (message);
  XmStringFree (exitString);

  /* Return the widget ID of the dialog. */
  return(dialog);
}

Widget CreateCommandDialog(Widget parent, char *initialstring)
{
  Widget    dialog;
  XmString  label_string;
  Arg al[10];
  int ac;

  /* Create the XmStrings needed for creating the dialog. */
  label_string = XmStringCreateLtoR ("Script command:", XmFONTLIST_DEFAULT_TAG);

  /* Create the dialog widget. */
  ac = 0;
  printf("Not implemented: intialstring = '%s'\n", initialstring);
  XtSetArg(al[ac], XmNselectionLabelString, label_string); ac++;
  dialog = XmCreatePromptDialog (parent, "commandDialog", al, ac);

  /* add the initial string to the command dialog */
  /* ? */

  /* Add the callback for the OK and Help buttons. */
  XtAddCallback(dialog, XmNokCallback, DialogCB, (XtPointer)DIALOG_ScriptCommand_OK);
  XtAddCallback(dialog, XmNhelpCallback, MenuCB, (XtPointer)MENU_Help_Commands);

  /* Free the memory used to create the original XmStrings. */
  XmStringFree(label_string);

  /* Return the widget ID of the dialog. */
  return(dialog);
}

Widget CreateFileSelDialog(Widget parent, int OKCallBackCode,
			   int CancelCallBackCode)
{
  Widget FileSelDialog;

  FileSelDialog = XmCreateFileSelectionDialog(parent,
         "File Selection Dialog", NULL, 0);

  XtAddCallback (FileSelDialog, XmNokCallback, DialogCB,
		 (XtPointer)OKCallBackCode);
  XtAddCallback (FileSelDialog, XmNcancelCallback, DialogCB,
		 (XtPointer)CancelCallBackCode);
  XtAddCallback (FileSelDialog, XmNhelpCallback, DialogCB,
		 (XtPointer)DIALOG_Help_NoHelp);
  return FileSelDialog;
}

