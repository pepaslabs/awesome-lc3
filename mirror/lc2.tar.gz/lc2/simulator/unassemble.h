/******************************************************************************
* File:		unassemble.h - LC-2 simulator
* Author:	Matt Postiff, postiffm@umich.edu
* 
* Notices:	(C) Matt Postiff, 1995-1996. ALL RIGHTS RESERVED.
* 		    See the file NOTICE for a full copyright notice.
* 
* EECS 100 -- University of Michigan
* 
* Description:	Interface to LC-2 disassembler
* 
* History:	Date		Who	Version	Change
* 		--------	---	-------	-------------------------------
*               7/8/95          MAP     1       Created
* 
******************************************************************************/

#ifndef __UNASSEMBLE_H__
#define __UNASSEMBLE_H__

void unassemble(int instruction, char *buf, int address);

#endif




