/******************************************************************************
* File:		Dialog.h - LC-2 simulator
* Author:	Matt Postiff, postiffm@umich.edu
* 
* Notices:	(C) Matt Postiff, 1995-1996. ALL RIGHTS RESERVED.
* 		    See the file NOTICE for a full copyright notice.
* 
* EECS 100 -- University of Michigan
* 
* Description:	This file contains defines for dialog boxes and buttons.
* 
* History:	Date		Who	Version	Change
* 		--------	---	-------	-------------------------------
*               8/7/97          MAP     1       Created from newapp example.
* 
******************************************************************************/

#ifndef __DIALOG_H__
#define __DIALOG_H__

/* Define dialog buttons. */
#define DIALOG_Exit_OK            101
#define DIALOG_ScriptCommand_OK   102
#define DIALOG_File_LoadProgram   103
#define DIALOG_File_LoadScript    104
#define DIALOG_Cancel_LoadProgram 105
#define DIALOG_Cancel_LoadScript  106
#define DIALOG_Help_NoHelp        107

/* The Cancel and Help buttons are defined here for completeness.
   In this example, the Cancel button doesn't need any additional
   behavior because the Exit Dialog unmaps itself whenever any
   button is chosen.  Since there is no online help available (yet),
   the Help button is not used. 

   If you add your own dialogs, add similar button definitions. */

extern Widget ProgramSelDialog;
extern Widget ScriptSelDialog;

Widget CreateExitDialog(Widget parent);
void DialogCB (Widget w,                /*  widget id		*/
	       XtPointer client_data,   /*  data from application   */
	       XtPointer call_data);    /*  data from widget class  */
Widget CreateCommandDialog(Widget parent, char *initialstring);
Widget CreateFileSelDialog(Widget parent, int OKCallBackCode,
			   int CancelCallBackCode);

#endif
