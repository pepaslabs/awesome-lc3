/******************************************************************************
* File:		windows.c - LC-2 simulator
* Author:	Matt Postiff, postiffm@umich.edu
* 
* Notices:	(C) Matt Postiff, 1995-1996. ALL RIGHTS RESERVED.
* 		    See the file NOTICE for a full copyright notice.
* 
* EECS 100 -- University of Michigan
* 
* Description:	Window creation code
* 
* History:	Date		Who	Version	Change
* 		--------	---	-------	-------------------------------
*               8/28/96         MAP     3       Modified for Fall 1996
* 
* Additional properties for windows:
* XtNmin
* XtNmax
******************************************************************************/

#include "global.h"
#include "menu.h"
#include "buttons.h"
#include "xlc2sim.h"
#include "windows.h"
#include "dialog.h"

#include "cpu.h"
#include "memory.h"

#include <assert.h>

Widget reg_window, mem_window, info_window, console_window;
Widget reg_window_label, mem_window_label, 
       info_window_label, console_window_label;

port info_port, console_port;

void create_reg_window (Widget parent, Dimension app_width, Dimension reg_min_height,
			       Dimension reg_max_height)
{
  Arg al[20];
  int ac;

  ac = 0;
  XtSetArg (al[ac], XtNallowResize, False); ac++;
  XtSetArg (al[ac], XtNshowGrip, False); ac++;
  XtSetArg (al[ac], XtNresize, False); ac++;
  XtSetArg (al[ac], XtNmin, TEXTHEIGHT); ac++;
  XtSetArg (al[ac], XtNlabel, "CPU"); ac++;
  XtSetArg (al[ac], XtNborderWidth, 0); ac++;
  XtSetArg (al[ac], XtNuseStringInPlace, True); ac++;
  reg_window_label = XtCreateManagedWidget ("RegWindowLabel",
					    labelWidgetClass, parent, al, ac);

  ac = 0;
  XtSetArg (al[ac], XtNallowResize, False); ac++;
  XtSetArg (al[ac], XtNshowGrip, False); ac++;
  XtSetArg (al[ac], XtNresize, False); ac++;
  XtSetArg (al[ac], XtNtype, XawAsciiString); ac++;
  XtSetArg (al[ac], XtNeditType, XawtextRead); ac++;
  XtSetArg (al[ac], XtNpreferredPaneSize, reg_min_height); ac++;
  XtSetArg (al[ac], XtNheight, reg_min_height); ac++;
  XtSetArg (al[ac], XtNwidth, app_width); ac++;
  XtSetArg (al[ac], XtNresize, "width"); ac++;
  XtSetArg (al[ac], XtNwrap, "line"); ac++;
  XtSetArg (al[ac], XtNstring, ""); ac++;
  XtSetArg (al[ac], XtNlength, 0); ac++;
  XtSetArg (al[ac], XtNuseStringInPlace, True); ac++;
  XtSetArg (al[ac], XtNdisplayCaret, False); ac++;
  reg_window = XtCreateManagedWidget ("register", asciiTextWidgetClass,
				      parent, al, ac);
  
  /* To catch keystrokes */
  /*
    XtAddEventHandler(reg_window_label, KeyPressMask, False,
                     (XtEventHandler)HandleKeystroke, reg_window_label);
    XtAddEventHandler(reg_window, KeyPressMask, False,
                     (XtEventHandler)HandleKeystroke, reg_window);
  */
}

void create_mem_window (Widget parent, Dimension app_width, Dimension mem_height)
{
  Arg al[15];
  int ac;

  ac = 0;
  XtSetArg (al[ac], XtNallowResize, True); ac++;
  XtSetArg (al[ac], XtNshowGrip, False); ac++;
  XtSetArg (al[ac], XtNresize, False); ac++;
  XtSetArg (al[ac], XtNmin, TEXTHEIGHT); ac++;
  XtSetArg (al[ac], XtNlabel, "Memory"); ac++;
  XtSetArg (al[ac], XtNborderWidth, 0); ac++;
  XtSetArg (al[ac], XtNuseStringInPlace, True); ac++;
  XtSetArg (al[ac], XtNdisplayCaret, False); ac++;
  mem_window_label = XtCreateManagedWidget ("MemWatchLabel",
					    labelWidgetClass, parent, al, ac);

  ac = 0;
  XtSetArg (al[ac], XtNtype, XawAsciiString); ac++;
  XtSetArg (al[ac], XtNeditType, XawtextRead); ac++;
  XtSetArg (al[ac], XtNpreferredPaneSize, mem_height); ac++;
  XtSetArg (al[ac], XtNheight, mem_height); ac++;
  XtSetArg (al[ac], XtNwidth, app_width); ac++;
  XtSetArg (al[ac], XtNstring, ""); ac++;
  XtSetArg (al[ac], XtNborderWidth, 0); ac++;
  XtSetArg (al[ac], XtNdisplayCaret, False); ac++;
  XtSetArg (al[ac], XtNscrollVertical, XawtextScrollAlways); ac++;
  mem_window = XtCreateManagedWidget ("file", asciiTextWidgetClass, parent,
				       al, ac);

  /* To catch keystrokes */
  /*
   XtAddEventHandler(mem_window_label, KeyPressMask, False,
 		    (XtEventHandler)HandleKeystroke, mem_window_label);
   XtAddEventHandler(mem_window, KeyPressMask, False,
		    (XtEventHandler)HandleKeystroke, mem_window);
  */
}

void create_info_window (Widget parent, Dimension app_width, Dimension info_height)
{
  Arg al[15];
  int ac;

  ac = 0;
  XtSetArg (al[ac], XtNallowResize, True); ac++;
  XtSetArg (al[ac], XtNshowGrip, False); ac++;
  XtSetArg (al[ac], XtNresize, False); ac++;
  XtSetArg (al[ac], XtNmin, TEXTHEIGHT); ac++;
  XtSetArg (al[ac], XtNlabel, "Information"); ac++;
  XtSetArg (al[ac], XtNborderWidth, 0); ac++;
  XtSetArg (al[ac], XtNuseStringInPlace, True); ac++;
  XtSetArg (al[ac], XtNdisplayCaret, False); ac++;
  info_window_label = XtCreateManagedWidget ("DisplayLabel",
					     labelWidgetClass, parent, al, ac);

  ac = 0;
  XtSetArg (al[ac], XtNeditType, XawtextAppend); ac++;
  XtSetArg (al[ac], XtNpreferredPaneSize, info_height); ac++;
  XtSetArg (al[ac], XtNborderWidth, 0); ac++;
  XtSetArg (al[ac], XtNdisplayCaret, False); ac++;
  XtSetArg (al[ac], XtNdisplayNonprinting, False); ac++;
  XtSetArg (al[ac], XtNscrollVertical, XawtextScrollAlways); ac++;
  XtSetArg (al[ac], XtNwrap, "line"); ac++;
  XtSetArg (al[ac], XtNheight, info_height); ac++;
  XtSetArg (al[ac], XtNwidth, app_width); ac++;  
  /*
    XtSetArg (al[ac], XmNscrollingPolicy, XmAUTOMATIC); ac++;
    info_window = XmCreateScrolledWindow(parent, "info_window", al, ac);
    XtManageChild(info_window);
  */
  info_window = XtCreateManagedWidget ("display", asciiTextWidgetClass, parent,
				       al, ac);
  /*   XawTextEnableRedisplay (message);  */ /* what does this do? */
  info_port = (port) info_window;

  /* To catch keystrokes */
  /* 
   XtAddEventHandler(info_window_label, KeyPressMask, False,
 		    (XtEventHandler)HandleKeystroke, info_window_label);
   XtAddEventHandler(info_window, KeyPressMask, False,
 		    (XtEventHandler)HandleKeystroke, info_window);
   */
}

void create_console_window (Widget parent, Dimension console_height)
{
  Arg al[15];
  int ac = 0;
  Widget console_pane;

  console_shell = XtCreatePopupShell ("console_shell",
				      topLevelShellWidgetClass,
				      topLevel, NULL, ZERO);
  console_pane = XtCreateManagedWidget ("console_pane",
					panedWidgetClass, console_shell,
					NULL, ZERO);
  ac = 0;
  XtSetArg (al[ac], XtNeditType, XawtextAppend); ac++;
  XtSetArg (al[ac], XtNscrollVertical, XawtextScrollAlways); ac++;
  XtSetArg (al[ac], XtNpreferredPaneSize, 24 * TEXTHEIGHT); ac++;
  XtSetArg (al[ac], XtNwidth, TEXTWIDTH * 80); ac++;
  console_window = XtCreateManagedWidget ("console_window",
					  asciiTextWidgetClass,
					  console_pane, al, ac);
  XawTextEnableRedisplay (console_window);
  console_port = (port) console_window;

  /* do I want to catch keyboard events here? */
}

Widget create_sub_windows (Widget parent, Dimension app_width,
			   Dimension reg_min_height, Dimension reg_max_height,
			   Dimension button_height,
			   Dimension mem_watch_height,
			   Dimension display_height,
			   Dimension console_height)
{
  Widget paned_panel;
  Widget menuBar;
  Widget popupMenu;
  Arg al[10] = { };
  int ac;

  /* Create the paned "main" window */
  ac = 0;
  XtSetArg (al[ac], XmNtraversalOn, False); ac++;
  XtSetArg (al[ac], XmNmarginHeight, 3); ac++;
  XtSetArg (al[ac], XmNmarginWidth, 3); ac++;
  XtSetArg (al[ac], XmNsashWidth, 10); ac++;
  XtSetArg (al[ac], XmNsashHeight, 10); ac++;
  paned_panel = XmCreatePanedWindow(parent, "paned_panel", al, ac);
  XtManageChild(paned_panel);
  /*  paned_panel = XtCreateManagedWidget("paned_panel", xmPanedWindowWidgetClass, parent, al, ac);*/

  /* Need some consistency--do I do  */
  /* global, lifetime handles on dialog boxes, or create them anew each time? */
  /* probably LoadProgram is always kept, script command is not... */

  menuBar = CreateMenuBar(paned_panel);
  XtManageChild(menuBar);

  /* creating it here may mean I can't later position it? */
  ProgramSelDialog = CreateFileSelDialog(paned_panel, DIALOG_File_LoadProgram,
					 DIALOG_Cancel_LoadProgram);
  ScriptSelDialog  = CreateFileSelDialog(paned_panel, DIALOG_File_LoadScript,
					 DIALOG_Cancel_LoadScript);

  create_reg_window(paned_panel, app_width, reg_min_height, reg_max_height);
  create_mem_window(paned_panel, app_width, mem_watch_height);
  create_info_window(paned_panel, app_width, display_height);
  create_console_window (topLevel, console_height);

  /* must come after console_window is created */
  popupMenu = CreatePopupMenu(paned_panel);

  return paned_panel;
}

/* Center the text window at the instruction at the current PC and */
/* highlight the instruction. THIS IS A PROBLEMATIC FUNCTION!!! */
void center_mem_at_PC (void)
{
  char buf[8];
  XawTextBlock text;
  XawTextPosition start, finish;
  static int prev_PC = 0;
  XRectangle cursor_loc;
  Arg al[10];
  static Widget mem_window_sink = 0;
  static int highlight_x = -1, highlight_y;
  static XawTextPosition highlight_start, highlight_finish;

  if ((lc2_get_PC() > DISPLAY_HIGH) && (lc2_get_PC() < DISPLAY_LOW)) {
    return;
  }

  printf("center_mem_at_PC() called\n");

  if (mem_window_sink == 0) {
      XtSetArg (al[0], XtNtextSink, &mem_window_sink);
      XtGetValues (mem_window, al, ONE);
  }

  if (highlight_x != -1) {   /* unhighlight whatever we had highlighted */
      XawTextSinkDisplayText (mem_window_sink,
			      highlight_x, highlight_y,
			      highlight_start, highlight_finish, 0);
      highlight_x = -1;
  }

  mem_print(lc2_get_PC(), buf);  /* find out what the PC's line looks like */
  text.firstPos = 0;
  text.length = strlen (buf);
  text.ptr = buf;
  text.format = FMT8BIT;
  /* Find start of line at PC */
  start = XawTextSearch (mem_window,
			 ((prev_PC <= lc2_get_PC()) ? XawsdRight : XawsdLeft),
			 &text);
  if (start == XawTextSearchError) {  /* didn't find text in window */
    prev_PC = lc2_get_PC();
    return;
  }

  /* Find start of following line: */
  mem_print(lc2_get_PC()+1, buf);
  finish = XawTextSearch (mem_window, XawsdRight, &text);
  if (finish == XawTextSearchError) {  /* didn't find text in window */
    prev_PC = lc2_get_PC();
    return;
  }

  /* Find PC line's location in the window */
  XawTextSetInsertionPoint (mem_window, start);
  XawTextSinkGetCursorBounds (mem_window_sink, &cursor_loc);

  /* correct for scroll bar and a couple of pixels to the right */
  highlight_x = cursor_loc.x + cursor_loc.width*3 + 2;
  highlight_y = cursor_loc.y + cursor_loc.height;
  highlight_start = start;
  highlight_finish = finish;

  /* Highlight the line */
  XawTextSetInsertionPoint (mem_window, start);

  XawTextSinkDisplayText (mem_window_sink,
			  highlight_x, highlight_y,
			  highlight_start, highlight_finish, 1);
  XawTextSetInsertionPoint (mem_window, start);
  prev_PC = lc2_get_PC();          /* remember this PC for next go around */
}

