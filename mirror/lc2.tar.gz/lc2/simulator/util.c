/******************************************************************************
* File:		util.c - LC-2 simulator
* Author:	Matt Postiff, postiffm@umich.edu
* 
* Notices:	(C) Matt Postiff, 1995-1996. ALL RIGHTS RESERVED.
* 		    See the file NOTICE for a full copyright notice.
* 
* EECS 100 -- University of Michigan
* 
* Description:	Various utility/error-handling functions
* 
* History:	Date		Who	Version	Change
* 		--------	---	-------	-------------------------------
*               8/5/97          MAP     1       Create - took from xlc2sim.c
* To Do:
*
******************************************************************************/

#include "util.h"
#include "xlc2sim.h"
#include "cpu.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

/******************************************************************************
 strtoul - definition taken from Solaris 2.4 (SunOS 5.4)
 This is here for those rare (stupid) compilers that don't have this in their
 library. The paragraphs with leading -'s are those that I have implemented.

     strtoul()  returns  the  value  represented  by the character 
     string pointed to by str  as  an
     unsigned long integer If  the value represented by str
     would cause overflow, ULONG_MAX is returned,  and  errno  is
     set to the value, ERANGE.

     - The string is scanned up to the first character inconsistent  
       with  base.

     - Leading  ``white-space'' characters (as defined by isspace()
       in ctype(3C)) are ignored.

     - If the value of ptr is not (char **)NULL, a pointer  to  the
       character  terminating  the scan is returned in the location
       pointed to by ptr.  If no integer can be formed, that  loca-
       tion is set to str, and zero is returned.

     - If base is positive (and not greater than 36), it is used as
       the  base  for  conversion.  After an optional leading sign,
       leading zeros are ignored, and ``0x'' or ``0X''  is  ignored
       if base is 16.

     If base is zero, the string itself determines  the  base  as
     follows:  After  an  optional  leading  sign  a leading zero
     indicates octal conversion, and a leading ``0x''  or  ``0X''
     hexadecimal  conversion.   Otherwise,  decimal conversion is
     used.

     - Truncation from long to int can, of course, take place  upon
       assignment or by an explicit cast.

******************************************************************************/
unsigned long lc2strtoul(char *str, char **ptr, int base)
{
  unsigned long result = 0;         /* the (intermediate) final result */
  int atleastone0 = 0;
  char ch;
  int sign;                         /* if result should be made negative */

  /* printf("lc2strtoul called with str=%s, base=%d\n", str, base); */

  if ((base < 0) || (base > 36)) {
    error(FATAL, "The LC-2 strtoul function only works with bases 0-36, inclusive\n");
  }
  if (str == 0x0) {
    return result;
  }

  /* ignore leading whitespace */
  while (isspace(*str)) str++;

  /* ignore leading sign */
  if (*str == '+') {
    sign = +1;
    str++;
  }
  else if (*str == '-') {
    sign = -1;
    str++;
  }

  if (base == 0) {   /* I can't handle this right now :) */
    return result;
  }

  /* ignore leading 0's */
  while (*str == '0') {
    atleastone0 = 1;
    str++;
  }

  /* if base is 16, ignore leading 0[xX] */
  if (base == 16) {
    if (atleastone0) {
      str--;
      /* this may bust */
      if ((*str == '0') && ((*(str+1) == 'x') || (*(str+1) == 'X')))
        str += 2;
    }
  }

  /* printf("Got here, atleastone0 = %d, str=%s\n", atleastone0, str); */

  /* so here, we know the base for sure, go on */
  while ((ch = *(str++)) != 0) {
         if ((ch >= '0') && (ch <= '9')) ch -= '0';
    else if ((ch >= 'a') && (ch <= 'z')) ch = ch - 'a' + 10;
    else if ((ch >= 'A') && (ch <= 'Z')) ch = ch - 'A' + 10;
    else break;  /* we're done */
    result *= base;
    result += ch;
  }
  /* save pointer following last valid digit in this number */
  if (ptr != 0x0) *ptr = --str;

  /* return the result, 0 if cannot form the number */
  if (sign == -1) result *= -1;
  return result;
}

/******************************************************************************
* parse_val
* Parses up a location or value string. Takes into account that there might be
*   a $, x, or X (hex), # (decimal), % (binary), or 'R' in front of the 
*   constant, as well as the normal 0x or nothing (hex).
* Parameters: value_str - the string containing the value (like "$3000")
* Returns: integer value of value string, out-of-range value if error
******************************************************************************/
unsigned long parse_val(char *value_str)
{
  unsigned long temp = 0x00000000;

  if (value_str == 0x0) return temp;

  while (isspace(*value_str)) value_str++;    /* lose leading spaces, if any */
  if (*value_str == '%')
    temp = lc2strtoul (value_str+1, (char **)0x0, 2);
  else if (*value_str == '#')
    temp = lc2strtoul (value_str+1, (char **)0x0, 10);
  else if ( (*value_str == '$') || (*value_str == 'x') || (*value_str == 'X') )
    temp = lc2strtoul (value_str+1, (char **)0x0, 16);
  else if ((*value_str == 'R') || (*value_str == 'r')) {
    temp = lc2strtoul (value_str+1, (char **)0x0, 10);
    if ((temp < 0) || (temp >= NUM_REGS)) {
      error(NORMAL, "Illegal register specifier R%u\n", temp);
      temp = 0x00010000;
    }
  }
  else {
    temp = lc2strtoul (value_str, (char **)0x0, 16);  /* assume base 16 */
  }

  if ((temp < 0) || (temp > 0x0000FFFF)) {
      error(NORMAL, "Value $%08x doesn't fit in 16 bits. Setting to 0x0000.\n", temp);
      temp = 0x0;
  }
  return temp;
}

/******************************************************************************
*  texttoint
*    This function converts a string such as 1000110100001010 or 8D0A to
*  its corresponding integer value, given the base to convert from (2 or 16).
*  Parameters: pointer to the text to convert, and the base to convert it from
*  Returns: the integer value of the string, 32-bit -1 if no string is
*    found.
******************************************************************************/
int texttoint(char *text, int base)
{
  int result, temp;

  result = temp = 0xFFFFFFFF;

  while (*text) {
    if ((temp = valid_digit(*text, base)) != -1) {
      result *= base;
      result += temp;
    }
    else return result & 0x0000FFFF;
    text++;
  }
  return result & 0x0000FFFF;
}

/******************************************************************************
 * If there is a tilde at the front of a file name, resolve it; in either case,
 * copy at least the contents of filename into newfilename
 *****************************************************************************/
void process_tilde(char *filename, char *newfilename)
{
  char *homedir;

  while (*filename && isspace(*filename)) filename++;  /* drop whitespace */

  strcpy(newfilename, filename);                       /* the usual case */

  if (*filename == '~') {
    homedir = getenv("home");
    if (homedir == NULL) homedir = getenv ("HOME");
    if (homedir == NULL) {
      error(NORMAL, "Cannot resolve ~ in path to home directory; $home or $HOME environment variables may not be set properly\n");
      return;
    }
    strcpy(newfilename, homedir);
    strcat(newfilename, filename+1);  /* don't copy the ~ too */
  }
}

/* You can replace these functions with alternative implementations
   if you are not using X-windows with the cpu model. */

extern jmp_buf spim_top_level_env; /* For ^C */

int error (error_level how_serious, char *fmt, ...)
{
  va_list args;
  char io_buffer [IO_BUFFSIZE];

  va_start (args, fmt);
  vsprintf (io_buffer, fmt, args);
  va_end (args);

  if (info_port != 0) {
    put_str ((Widget)info_port, io_buffer);
  }
  else {
    fprintf (stderr, "%s", io_buffer);
  }

  if (how_serious == FATAL) {
    /* re-print message in shell window so that we can catch it */
    printf("%s", io_buffer);
    exit(3);
  }

  if ((how_serious == RUNTIME) && (RUNNING)) {
    longjmp (spim_top_level_env, 1);
  }

  return 0;
}

void printinfo(char *fmt, ...)
{
  va_list args;
  char io_buffer [IO_BUFFSIZE];

  va_start (args, fmt);
  vsprintf (io_buffer, fmt, args);
  va_end (args);

  write_output(info_port, io_buffer);
}

/* valid_digit stolen directly from ../assembler */

/******************************************************************************
*  valid_digit
*  Determines if a digit is legal in the base system given.  Handles bases 2
*    through 36.
*  Parameters: digit to test and base digit is to be tested in
*  Calls: none 
*  Returns: value of the digit in decimal if the digit is legal, -1 if illegal
*  Global usage: none
******************************************************************************/
int valid_digit(char _d, int base)
{
  int d = toupper(_d);

  if ( (d >= '0') && (d <= '9') )
    d = d - '0';      /* invariant: d is between 0 and 9, inclusive */
  else if ( ( d >= 'A') && (d <= 'Z') )
    d = d - 'A' + 10; /* invariant: d is between 10 and 35, inclusive */
  else return -1;

  /* invariant: d is between 0 and 35 */
  if (d < base)
    return d;
  else return -1;
}
