/******************************************************************************
* File:		unassemble.c - LC-2 simulator
* Author:	Matt Postiff, postiffm@umich.edu
* 
* Notices:	(C) Matt Postiff, 1995-1996. ALL RIGHTS RESERVED.
* 		    See the file NOTICE for a full copyright notice.
* 
* EECS 100 -- University of Michigan
* 
* Description:	LC-2 disassembler
* 
* History:	Date		Who	Version	Change
* 		--------	---	-------	-------------------------------
*               7/8/95          MAP     1       Created
*               1/1/96          MAP     2       Modified for Winter 1995
*               8/29/96         MAP     3       Modified for Fall 1996
*               12/29/98        MAP     5       BR and RTI change for W 1999
******************************************************************************/

#ifndef _unassemble_C
#define _unassemble_C

#include "unassemble.h"
#include "memory.h"

#include <stdio.h>
#include <string.h>

/******************************************************************************
*  unassemble
*  This function provides an unassemble functionality for the LC-2 instruction
*    set.  The unassembled instruction is put into the character buffer given
*    by buf.
*  Parameters:
*    integer representation of the instruction
*    pointer to buffer to stick resulting instruction into
*    the address the instruction is at -- for pageoffset calculations
*  Calls: none
*  Returns: pointer to the buffer parameter
******************************************************************************/
void unassemble(int instruction, char *buf, int address)
{
  static int opc, cond, dr, sr1, sr2, pgoffset9, page, imm5, offset6, imm8,
             imm_or_sr2, link_bit;
  static char *bufp, *temp;
  static char label[21];

  /* calculate all the possible fields in the instruction for later use */
  bufp = buf;
  opc = (instruction & 0x0000F000) >> 12;
  link_bit = (instruction & 0x00000800) >> 11;
  cond = (instruction & 0x00000E00) >> 9;
  dr = cond;
  sr1 = (instruction & 0x000001C0) >> 6;
  sr2 = (instruction & 0x00000007);
  imm_or_sr2 = (instruction & 0x00000020);  /* 1 if imm, 0 if sr2 */
  /* remember that the PC would be incremented first, then the page address */
  /* computed!!!! */
  page = ((address+1) & 0x0000FE00);  /* e.g. 0x3000 */
  pgoffset9 = (instruction & 0x000001FF);
  imm5 = (instruction & 0x0000001F);
    if (instruction & 0x00000010)       /* the immediate is negative... */
      imm5 |= (0x0000FFE0);             /* ...so sign extend it */
  offset6 = (instruction & 0x0000003F);
  imm8 = (instruction & 0x000000FF);

  if (labels[page+pgoffset9]) {
    sprintf(label, "%s", labels[page+pgoffset9]);
  }
  else {
    sprintf(label, "$%04X", page+pgoffset9);
  }

  switch (opc) {
  case 0x0: /* BR[n][z][p] */
    /* figure out what the branch condition is */
    switch (cond) {
      case 0:  temp = "nop"; break;
      case 1:  temp = "p";   break;
      case 2:  temp = "z";   break;
      case 3:  temp = "zp";  break;
      case 4:  temp = "n";   break;
      case 5:  temp = "np";  break;
      case 6:  temp = "nz";  break;
      case 7:  temp = "nzp"; break;
    }
    sprintf(buf, "br%s\t%s", temp, label);
    break;
  case 0x1: /* ADD */
    if (instruction & 0x00000020)  /* immediate version */
      sprintf(buf, "add\tR%d, R%d, $%04X", dr, sr1, imm5);
    else                           /* 3-register version */
      sprintf(buf, "add\tR%d, R%d, R%d", dr, sr1, sr2);
    break;
  case 0x2: /* LD */
    sprintf(buf, "ld\tR%d, %s", dr, label);
    break;
  case 0x3: /* ST */
    sprintf(buf, "st\tR%d, %s", dr, label);
    break;
  case 0x4: /* JSR */
    if (cond & 0x4) { /* link bit = 1 => link => JSR */
      sprintf(buf, "jsr\t%s", label);
    }
    else { /* link bit = 0 -> don't link => JMP */
      sprintf(buf, "jmp\t%s", label);
    }
    break;
  case 0x5: /* AND */
    if (instruction & 0x00000020)  /* immediate version */
      sprintf(buf, "and\tR%d, R%d, $%04X", dr, sr1, imm5);
    else                           /* 3-register version */
      sprintf(buf, "and\tR%d, R%d, R%d", dr, sr1, sr2);
    break;
  case 0x6: /* LDR */
    sprintf(buf, "ldr\tR%d, R%d, %d", dr, sr1, offset6);
    break;
  case 0x7: /* STR */
    sprintf(buf, "str\tR%d, R%d, %d", dr, sr1, offset6);
    break;
  case 0x8: /* RTI */
    sprintf(buf, "rti");
    break;
  case 0x9: /* NOT */
    /* this is really XOR, but we don't advertise this */
    sprintf(buf, "not\tR%d, R%d", dr, sr1);
    break;
  case 0xA: /* LDI */
    sprintf(buf, "ldi\tR%d, %s", dr, label);
    break;
  case 0xB: /* STI */
    sprintf(buf, "sti\tR%d, %s", dr, label);
    break;
  case 0xC: /* JSRR */
    if (cond & 0x4) { /* link bit = 1 => link => JSRR */
      sprintf(buf, "jsrr\tR%d, %d", sr1, offset6);
    }
    else { /* link bit = 0 -> don't link => JMPR */
      sprintf(buf, "jmpr\tR%d, %d", sr1, offset6);
    }
    break;
  case 0xD: /* RET */
    sprintf(buf, "ret");
    break;
  case 0xE: /* LEA */
    sprintf(buf, "lea\tR%d, %s", dr, label);
    break;
  case 0xF: /* TRAP */
    sprintf(buf, "trap\t$%02X", imm8);
    break;
  }
}

#endif
