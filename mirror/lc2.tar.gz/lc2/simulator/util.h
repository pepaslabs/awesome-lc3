/******************************************************************************
* File:		util.c - LC-2 simulator
* Author:	Matt Postiff, postiffm@umich.edu
* 
* Notices:	(C) Matt Postiff, 1995-1996. ALL RIGHTS RESERVED.
* 		    See the file NOTICE for a full copyright notice.
* 
* EECS 100 -- University of Michigan
* 
* Description:	Various utility/error-handling functions
* 
* History:	Date		Who	Version	Change
* 		--------	---	-------	-------------------------------
*               8/5/97          MAP     1       Create - took from xlc2sim.c
* To Do:
*
******************************************************************************/

#ifndef __UTIL_H__
#define __UTIL_H__

unsigned long lc2strtoul(char *str, char **ptr, int base);
unsigned long parse_val(char *value_str);
int texttoint(char *text, int base);
void process_tilde(char *filename, char *newfilename);

/* Error-handling constants */
enum error_level { NORMAL, RUNTIME, FATAL };
typedef enum error_level error_level;

#define IO_BUFFSIZE 	10000

int error(error_level how_serious, char *fmt, ...);
void printinfo(char *fmt, ...);
int valid_digit(char _d, int base);

#endif
