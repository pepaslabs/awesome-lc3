/******************************************************************************
* File:		buttons.h - LC-2 simulator
* Author:	Matt Postiff, postiffm@umich.edu
* 
* Notices:	(C) Matt Postiff, 1995-1996. ALL RIGHTS RESERVED.
* 		    See the file NOTICE for a full copyright notice.
* 
* EECS 100 -- University of Michigan
* 
* Description:	Interface to menu bar and button creation code
* 
* History:	Date		Who	Version	Change
* 		--------	---	-------	-------------------------------
*               7/8/95          MAP     1       Created
*
******************************************************************************/

#ifndef __BUTTONS_H__
#define __BUTTONS_H__

#include "global.h"

void confirm (Widget widget, XEvent *event, String *params,
	Cardinal *num_params);
void continue_prompt (int interrupt_seen);
void record_file_name_for_prompt (char *name);

void add_breakpoint_action (Widget w, XtPointer client_data,
	XtPointer call_data);
void breakpoint_prompt (Widget button);
void destroy_bkpt_prompt (Widget w, XtPointer client_data,
			     XtPointer call_data);
void continue_action (Widget w, XtPointer client_data,
			     XtPointer call_data);
void continue_prompt (int interrupt_seen);
void destroy_continue_prompt (Widget w, XtPointer client_data,
			     XtPointer call_data);
void delete_breakpoint_action (Widget w, XtPointer client_data,
				      XtPointer call_data);

void destroy_popup_prompt (Widget w, XtPointer client_data,
				  XtPointer call_data);

void load_prompt (Widget button);
void destroy_load_prompt (Widget w, XtPointer client_data,
			     XtPointer call_data);
void list_breakpoint_action (Widget w, XtPointer client_data,
				    XtPointer call_data);
void noop (Widget w, XtPointer client_data, XtPointer call_data);
void parse_print_value (Widget w, XtPointer client_data,
			       XtPointer call_data);
void parse_set_value (Widget w, XtPointer client_data,
			     XtPointer call_data);
 Widget popup_one_field_dialog (Widget button, String name,
				      String field1_label, String field1_value,
			              String action_name,     
				      void (*action) (Widget, XtPointer, XtPointer),
				      String action2_name,
				      void (*action2) (Widget, XtPointer, XtPointer),
				      String action3_name,
				      void (*action3) (Widget, XtPointer, XtPointer),
				      Widget *field1_text,
                                      unsigned field_widths);
 Widget popup_two_field_dialog (Widget button, String name,
				      String field1_label, String field1_value,
				      String field2_label, String field2_value,
				      String action_name,
				      void (*action) (Widget, XtPointer, XtPointer),
				      String action2_name,
				      void (*action2) (Widget, XtPointer, XtPointer),
				      Widget *field1_text,
				      Widget *field2_text);
void print_mem_prompt (Widget button);
void destroy_print_prompt (Widget w, XtPointer client_data,
			     XtPointer call_data);
void run_program_action (Widget w, XtPointer client_data,
				XtPointer call_data);
void run_prompt (Widget button);
void destroy_run_prompt (Widget w, XtPointer client_data,
				XtPointer call_data);
void set_value_prompt (Widget button);
void set_value_destroyed (Widget w, XtPointer client_data,
				 XtPointer call_data);
void step_continue_action (Widget w, XtPointer client_data,
				  XtPointer call_data);
void step_program_action (Widget w, XtPointer client_data,
				 XtPointer call_data);
void step_prompt (Widget button);
void destroy_step_prompt (Widget w, XtPointer client_data,
			     XtPointer call_data);
void warp_to_second_dialog (Widget widget, XEvent *event,
				   String *params, Cardinal *num_params);
void run_action (Widget menuitem, XtPointer client_data, XtPointer call_data);
void print_action (Widget menuitem);
void RemapDeleteKey(Widget w);
void SetDeleteRemap(int state);

#endif
