/******************************************************************************
* File:		cpu.h - LC-2 simulator
* Author:	Matt Postiff, postiffm@umich.edu
* 
* Notices:	(C) Matt Postiff, 1995-1998. ALL RIGHTS RESERVED.
* 		    See the file NOTICE for a full copyright notice.
* 
* EECS 100 -- University of Michigan
* 
* Description:	Interface to the LC-2 CPU core
* 
* History:	Date		Who	Version	Change
* 		--------	---	-------	-------------------------------
*               8/15/98         MAP     4.2     Moved from xlc2sim.[ch]
* 
******************************************************************************/

#ifndef __CPU_H__
#define __CPU_H__

#include "../lc2.h"

extern int INITIALIZING;
extern int spim_is_running;
extern int stepintotraps;  /* step into trap routines or no? */
extern int insttrace;      /* dump a trace of each instruction or no? */

extern char *opcode_list[];

/* LC-2 CPU State Variables */
#define LC2_ROM_BOOT_ADDR 0xFC00
#define LC2_USER_START_ADDRESS 0x3000

void lc2_init(void);
void lc2_init_regs(void);
int  lc2_run_program(int start_pc, int STEPS, int CONTINUE);
void lc2_step_instruction(void);
int  lc2_fetch(void);
void lc2_do_instruction(int instruction);
void lc2_set_condition_codes(int reg_num);
int  lc2_build_address(int pc, int page_offset);
int  lc2_load_code(char *filename);
void lc2_record_simulator_startup_path(char *progpath);
void lc2_set_reg(int regnum, int value);
int  lc2_get_reg(int regnum);
void lc2_set_PC(int _PC);
int  lc2_get_PC(void);
void lc2_set_IR(int _IR);
int  lc2_get_IR(void);
int  lc2_get_CCR(void);
int  lc2_get_CCRN(void);
int  lc2_get_CCRZ(void);
int  lc2_get_CCRP(void);
void lc2_set_CCR(int _CCR);
void lc2_halt(void);
void lc2_unhalt(void);
int  lc2_is_halted(void);

#endif
