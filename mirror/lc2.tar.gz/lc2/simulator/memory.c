/******************************************************************************
* File:		memory.c - LC-2 simulator
* Author:	Matt Postiff, postiffm@umich.edu
* 
* Notices:	(C) Matt Postiff, 1995-1996. ALL RIGHTS RESERVED.
* 		    See the file NOTICE for a full copyright notice.
* 
* EECS 100 -- University of Michigan
* 
* Description:	Impelmentation of LC-2 memory.
* 
* History:	Date		Who	Version	Change
* 		--------	---	-------	-------------------------------
* 		7/4/95		MAP	1	Created
*               1/4/96          MAP     2       Modified for Winter 1996
* 
* To Do:         Standardize error messages; include address and data,
*                if applicable, in message.
* 
******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "memory.h"
#include "util.h"
#include "unassemble.h"
#include "xlc2sim.h" /* would rather not put this dependency in here */
#include "cpu.h"

/* various locations in memory */
#define MEM_SIZE        0x00010000 /* 1 bigger than biggest address */
#define LOW_BOUND       0x00000000
#define HIGH_BOUND      0x0000FFFF
#define VRAM_LOW        0x0000F000
#define VIDEO_STAT_REG  0x0000F3FC
#define HPOS_REG        0x0000F3FD
#define VPOS_REG        0x0000F3FE
#define VRAM_HIGH       0x0000F3FF
#define VIDEO_DATA_REG  0x0000F3FF
#define KBD_STAT_REG    0x0000F400
#define KBD_DATA_REG    0x0000F401
#define ROM_LOW         0x0000FC00
#define ROM_HIGH        0x0000FFFE
#define MACHINE_REG     0x0000FFFF

/* other constants */
#define KBD_READY_MASK  0x00008000
#define VIDEO_READY_MASK 0x00008000

/* local variables */
static int memory[MEM_SIZE];
char *labels[MEM_SIZE]; /* a bit wasteful of space... */
int *mem_ptr = memory;
int mem_modified = 1;

/******************************************************************************
*  mem_clear
*    Write zeros to all memory locations.  A time-expensive routine.
*  Parameters: none
*  Calls: none
*  Returns: none
******************************************************************************/
void mem_clear(void)
{
  int i;
  printinfo("Memory cleared\n");
  for (i = 0; i < MEM_SIZE; i++) {
    memory[i] = 0x00000000;
    labels[i] = NULL;
  }
  mem_modified = 1;
  return;
}

/******************************************************************************
*  mem_read
*  Read the integer from the memory location given at address.  If address is
*   out of range, simply ignore the call.
*  Parameters: address to read from
*  Calls: none
*  Returns: the integer in the memory location if in bounds; exits if not
*   not.
******************************************************************************/
int mem_read(int address, int do_devices)
{
  int result;

  if ((address < LOW_BOUND) || (address > HIGH_BOUND)) {
    error(NORMAL, "Attempt to read from out-of-bounds memory location 0x%08X. Value returned is bogus.\n",
	  address);
    return 0xFFFF;
  }
  else {
    result = *(mem_ptr + address) & 0x0000FFFF;
  }

  if (do_devices) {
    /* handle special case of keyboard */
    if (address == KBD_STAT_REG) {
      /* hardware cheats and gets character when one is being looked for */
      *(mem_ptr + KBD_DATA_REG) = get_console_char();
      *(mem_ptr + KBD_STAT_REG) |= KBD_READY_MASK;   /* turn on ready bit */
      /* recompute result now that keyboard is ready */
      result = *(mem_ptr + KBD_STAT_REG) & 0x0000FFFF;
    }
    if (address == VIDEO_STAT_REG) {
      /* hardware cheats and always sets the video ready bit */
      *(mem_ptr + VIDEO_STAT_REG) |= VIDEO_READY_MASK; /* turn on ready bit */
      result = *(mem_ptr + VIDEO_STAT_REG) & 0x0000FFFF;
    }
    else if (address == KBD_DATA_REG) {
      /* don't get a new one; user should have checked ready bit, which */
      /* actually gets the new character; instead, just turn off the thing */
      *(mem_ptr + KBD_STAT_REG) &= !KBD_READY_MASK;
      result = *(mem_ptr + KBD_DATA_REG) & 0x0000FFFF;
    }
  }
  return result;
}

/******************************************************************************
*  mem_write
*  Write the integer data to the memory location given at address.
*   respond.
*  Parameters: address to write to
*  Calls: none
*  Returns: none; exits if address out of bounds
******************************************************************************/
void mem_write(int address, int data)
{
  /* how handle writes to ROM? */

  char ch1, ch2;
  int save, new_val;
  int was_bkpt = 0;

  if (mem_breakpoint(address)) was_bkpt = 1;

  if ((address < LOW_BOUND) || (address > HIGH_BOUND)) {
    error(FATAL, "Attempt to write to out-of-bounds memory location 0x%08X. Write ignored.\n",
	  address);
  }
  else if (address == VIDEO_DATA_REG) {
    /* for now, ignore position (horizontal at $F3FD, vertical at $F3FE) and */
    /*  writes directly to video RAM.  Only writes that will work are to the */
    /*  streaming register at $F3FF. */
    *(mem_ptr + VRAM_HIGH) = data & 0x0000FFFF;
    ch1 = data & 0x000000FF;
    ch2 = (data & 0x0000FF00) >> 8; /* packed strings have another byte here */
    if (ch1 != 0) { put_console_char(ch1); }
    if (ch2 != 0) { put_console_char(ch2); }
  }
  else if (address == KBD_DATA_REG) {
    error(FATAL, "Attempt to write keyboard data register at 0x%08X with data 0x%08X. Write ignored.\n", address, data);
  }
  else if (address == KBD_STAT_REG) {
    save = data;
    new_val = *(mem_ptr + address);
    data |= 0x0000BFFC;  /*  allow change to R, CL, NL      */
    new_val &= data;     /*  bits are cleared properly now  */
    save &= 0x00004003;
    new_val |= save;     /*  bits are set properly now      */
    *(mem_ptr + address) = new_val;
  }
  else if (address == MACHINE_REG) {
    /* write to the machine control register. If the high bit of the word
      being written is 0, this clears the clock-enable and the machine stops */
    *(mem_ptr + address) = data & 0x0000FFFF;
    if (!(data & 0x00008000)) {
      lc2_halt();
    }
  }
  else {
    *(mem_ptr + address) = data & 0x0000FFFF;
  }
  if (was_bkpt) mem_add_breakpoint(address);
  if ((address >= DISPLAY_LOW) && (address <= DISPLAY_HIGH)) {
    mem_modified = 1;
  }
}

/******************************************************************************
*  mem_print
*  Write the integer data at location address to the output.
*  Parameters: address to print
*  Calls: mem_read
*  Returns: none
******************************************************************************/
void mem_print(int address, char *result_buffer)
{
  static char buffer[120] = { "" };
  char *bufp = buffer;
  int i;
  int temp;
  int data = mem_read(address, 0);
  temp = data;

  /* indicate whether breakpoint or not */
  if (mem_breakpoint(address)) *bufp = 'B';
  else *bufp = ' ';
  bufp++;
  *bufp = ' '; bufp++;

  /* print the address of the current memory location */
  if (labels[address]) {
    sprintf(bufp, "....................");
    sprintf(bufp, "%s", labels[address]);
    *(bufp + strlen(bufp)) = '.';
  }
  else {
    sprintf(bufp, "%-20s", " ");
  }
  bufp += strlen(bufp);
  sprintf(bufp, " [%04x]:", address); bufp += strlen(bufp);

  /* print the binary of the current memory location */
  for (i = 15; i >= 0; i--) {
    if (temp & (1 << i)) {
      *bufp = '1';
    }
    else {
      *bufp = '0';
    }
    temp &= ~(1 << i);    /* bitwise complement */
    bufp++;
  }

  /* print the hex of the current memory location */
  sprintf(bufp, "\t%04x        ; ", data);
  bufp += strlen(bufp);

  unassemble(data, bufp, address);   bufp += strlen(bufp);
  sprintf(bufp, "\n");               bufp += strlen(bufp);
  if (result_buffer) {
    strcpy(result_buffer, buffer);
  }
  else {
    printinfo("%s", buffer);
  }
}

/******************************************************************************
*  mem_add_breakpoint
*  Add a breakpoint at the given address, using the number 16 bit (17th bit)
*    as a flag.  Remember that the memory is held in integers, low half being
*    the contents of LC-2 memory.  The upper 16-bits are available.
*  Parameters: address to set breakpoint at
*  Calls: none
*  Returns: none
******************************************************************************/
void mem_add_breakpoint(int address)
{
  if ((address < LOW_BOUND) || (address > HIGH_BOUND)) {
    error(NORMAL, "Attempt to set breakpoint at non-existent memory location 0x%08X. Request ignored.\n", address);
  }
  else {
    *(mem_ptr + address) |= 0x00010000;    /* set breakpoint bit */
    printinfo("Set breakpoint at address %04x\n", address);
    if ((address >= DISPLAY_LOW) && (address <= DISPLAY_HIGH)) {
      mem_modified = 1;
    }
    display_memory ();
  }
}

/******************************************************************************
*  mem_remove_breakpoint
*  Remove breakpoint at the given address.
*  Parameters: address to remove breakpoint from
*  Calls: none
*  Returns: none
******************************************************************************/
void mem_remove_breakpoint(int address)
{
  if ((address < LOW_BOUND) || (address > HIGH_BOUND)) {
    error(NORMAL, "Attempt to clear breakpoint at non-existent memory location 0x%08X. Request ignored.\n", address);
  }
  else if (mem_breakpoint(address)) {
    *(mem_ptr + address) &= 0xFFFEFFFF;    /* clear breakpoint bit */
    printinfo("Removed breakpoint from address %04x\n", address);

    if ((address >= DISPLAY_LOW) && (address <= DISPLAY_HIGH)) {
      mem_modified = 1;
    }
    display_memory();
  }
  else
    error (NORMAL, "No breakpoint to remove at %04x\n", address);
}


/******************************************************************************
*  mem_list_breakpoints
*  Print list of breakpoints currently set in memory
*  Parameters: none
*  Calls: sprintf
*  Returns: none
******************************************************************************/
void mem_list_breakpoints(void)
{
  static char buffer[4096];     /* hope I don't overrun this! */
  char *bufp = buffer;
  int i;

  sprintf(bufp, "\nListing breakpoints...\n\n"); bufp += strlen(bufp);
  sprintf(bufp, "Address\tMemory Value\n");      bufp += strlen(bufp);
  sprintf(bufp, "-------\t------------\n");      bufp += strlen(bufp);

  for (i = LOW_BOUND; i <= HIGH_BOUND; i++) {
    if (mem_breakpoint(i)) {
      sprintf(bufp, "[%04x]:\t%04x\n", i, 0x0000FFFF & *(mem_ptr + i));
      bufp += strlen(bufp);
    }
  }
  sprintf(bufp, "* End of List *\n\n");
  printinfo(buffer);
}

/******************************************************************************
*  mem_remove_all_breakpoints
*  Remove breakpoints from all memory locations.
*  Parameters: none
*  Calls: none
*  Returns: none
******************************************************************************/
void mem_remove_all_breakpoints(void)
{
  int i;

  for (i = LOW_BOUND; i <= HIGH_BOUND; i++) {
    *(mem_ptr + i) &= 0xFFFEFFFF;         /* clear breakpoint bit */
  }
  mem_modified = 1;
}

/******************************************************************************
*  mem_breakpoint
*  Determine if a breakpoint is set at a given memory location
*  Parameters: address to check
*  Calls: none
*  Returns: 1 if breakpoint is set, 0 if not
******************************************************************************/
int mem_breakpoint(int address)
{
  if ((address < LOW_BOUND) || (address > HIGH_BOUND)) {
    error(NORMAL, "Attempt to get breakpoint status of non-existent memory location. Request ignored.\n");
  }
  if (*(mem_ptr + address) & 0x00010000) return 1;
  else return 0;
}

/******************************************************************************
*  mem_in_bounds
*  Determine if a memory location is in bounds
*  Parameters: address to check
*  Returns: 1 if address is in bounds, 0 else
******************************************************************************/
int mem_in_bounds(int address)
{
  if ((address < LOW_BOUND) || (address > HIGH_BOUND)) {
    return 0;
  }
  return 1;
}

/******************************************************************************
 * mem_add_label
 * Add a label to a memory address if there is not already a label for that
 * address.
 *****************************************************************************/
void mem_add_label(char *label, int address)
{
  if (!labels[address]) {
    /* address doesn't have a mapping yet, make one */
    labels[address] = strdup(label);
    printinfo("Added label %s at address %04x\n", label, address);
  }
  else {
    printinfo("Already label %s at address %04x\n", labels[address], address);
  }
  if ((address >= DISPLAY_LOW) && (address <= DISPLAY_HIGH)) {
    mem_modified = 1;
  }
  return;
}

/******************************************************************************
 * mem_erase_label
 * Erase any label from the given address.
 *****************************************************************************/
void mem_erase_label(int address)
{
  if (labels[address]) {
    free(labels[address]);
  }
  labels[address] = NULL;
  mem_modified = 1;
  return;
}
