/******************************************************************************
* File:		Menu.h - LC-2 simulator
* Author:	Matt Postiff, postiffm@umich.edu
* 
* Notices:	(C) Matt Postiff, 1995-1996. ALL RIGHTS RESERVED.
* 		    See the file NOTICE for a full copyright notice.
* 
* EECS 100 -- University of Michigan
* 
* Description:	Definitions for menu items
* 
* History:	Date		Who	Version	Change
* 		--------	---	-------	-------------------------------
*               8/4/97          MAP     1       Created
* 
******************************************************************************/

#ifndef __MENU_H__
#define __MENU_H__

#include "global.h"

/* Functions for creating menus */
/* in Menu.c */
Widget CreateMenuBar (Widget parent);
Widget CreateMenuButton(Widget parent,
			char *name,
			int buttonID,           /* Values defined in Menu.h */
			char *buttonLabelStr,   /* Values defined in Menu.h */ 
			char buttonMnemonic, 
			int buttonType,
			char *buttonAccelerator,
			char *buttonAcceleratorTextStr);
void AddSeparator(Widget parent);
void MenuCB (Widget w,              /*  widget id		*/
	     XtPointer client_data, /*  data from application   */
	     XtPointer call_data);  /*  data from widget class  */

Widget CreatePopupMenu (Widget parent);
void PostPopup(Widget w, Widget popupPane, XButtonEvent *event);
void HandleKeystroke(Widget w, Widget popup, XKeyEvent *event);

/*
extern int    currentView;
extern Widget opt1Toggle, opt2Toggle, opt3Toggle;
extern int    currentOption;
*/
extern Widget  popupMenu;

/* Button Types */
#define PushButton    0
#define CheckBox      1
#define CheckBoxOn    2
#define RadioButton   3
#define RadioButtonOn 4
#define CascadeButton 5

/* Menu Commands */

#define MENU_File_LoadProgram   101
#define MENU_File_LoadScript    102
#define MENU_File_RunCommand    103
#define MENU_File_Exit          104

/*
#define MENU_Edit_Undo          201
#define MENU_Edit_Cut           202
#define MENU_Edit_Copy          203
#define MENU_Edit_Paste         204
#define MENU_Edit_Clear         205
#define MENU_Edit_Delete        206
*/

#define MENU_Run_RunProgram     201
#define MENU_Run_StepProgram    202
#define MENU_Run_Breakpoints    203

#define MENU_SetValues_ReinitializeMachine 301
#define MENU_SetValues_ClearRegisters      302
#define MENU_SetValues_SetRegorMemory      303

#define MENU_Display_Memory    401
#define MENU_Display_Registers 402
#define MENU_Display_Refresh   403

#define MENU_View_AsOne         1304
#define MENU_View_AsTwo         1305
#define MENU_View_AsThree       1306

#define MENU_Options_StepIntoTraps 501
#define MENU_Options_InstTrace  502
#define MENU_Options_OptA       503
#define MENU_Options_OptB       504
#define MENU_Options_OptC       505
#define MENU_Options_Opt1       506
#define MENU_Options_Opt2       507
#define MENU_Options_Opt3       508

#define MENU_Help_InstructionSet 901
#define MENU_Help_Commands       902
#define MENU_Help_Syntax         903
#define MENU_Help_ViewReadme     904
#define MENU_Help_Version        905

#endif
