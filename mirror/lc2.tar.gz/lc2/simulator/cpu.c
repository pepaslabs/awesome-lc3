/******************************************************************************
* File:		cpu.c - LC-2 simulator
* Author:	Matt Postiff, postiffm@umich.edu
* 
* Notices:	(C) Matt Postiff, 1995-1998. ALL RIGHTS RESERVED.
* 		    See the file NOTICE for a full copyright notice.
* 
* EECS 100 -- University of Michigan
* 
* Description:	Implementation of the LC-2 CPU core
* 
* History:	Date		Who	Version	Change
* 		--------	---	-------	-------------------------------
*               8/15/98         MAP     4.2     Moved from xlc2sim.c
* 
******************************************************************************/

#include "cpu.h"
#include "memory.h"
#include "global.h"
#include "util.h"
#include "xlc2sim.h" /* hate to sully it up like this */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

static char *simulator_startup_path;

/* Reverse lookup table opcode number to opcode name for easy translation. */
/* Index this table by the value of the 4-bit opcode. */
/* should use the stuff defined in lc2.h for this...*/
char *opcode_list[NUM_OPCODES] = {
  "br",                      /* need condition 'n', 'z', 'p' after */
  "add",
  "ld",
  "st",
  "jsr",                     /* variation without link bit = jmp */
  "and",
  "ldr",
  "str",
  "rti",
  "not",
  "ldi",
  "sti",
  "jsrr",                    /* variation without link bit = jmpr */
  "ret",
  "lea",
  "trap",
};

/******************************************************************************
 * LC-2 CPU State Variables
 *****************************************************************************/
static int R[NUM_REGS], PC, IR, CCR;
static int HALT = 0;
static int num_instructions_processed = 0;

/******************************************************************************
 * Initialize the state of the machine.
 *****************************************************************************/
void lc2_init(void)
{
  char *ptr = simulator_startup_path + strlen(simulator_startup_path);
  /* rely on fact that extra bytes were allocated for simulator_startup_path
     (see lc2_record_simulator_startup_path) */
  lc2_init_regs();
  INITIALIZING = 1;

  /* read operating system and ROM routines from startup directory */
  mem_write(0x0000FFFF, 0xFFFF);    /* set the clock enable bit */

  strcpy(ptr, "getc.obj");
  lc2_load_code(simulator_startup_path);
  strcpy(ptr, "promptgetc.obj");
  lc2_load_code(simulator_startup_path);
  strcpy(ptr, "putc.obj");
  lc2_load_code(simulator_startup_path);
  strcpy(ptr, "puts.obj");
  lc2_load_code(simulator_startup_path);
  strcpy(ptr, "putspacked.obj");
  lc2_load_code(simulator_startup_path);
  strcpy(ptr, "startup.obj");
  lc2_load_code(simulator_startup_path);
  strcpy(ptr, "undeftrap.obj");
  lc2_load_code(simulator_startup_path);
  strcpy(ptr, "halt.obj");
  lc2_load_code(simulator_startup_path);
  strcpy(ptr, "ivtable.obj");
  lc2_load_code(simulator_startup_path);
  *ptr = '\x0';                            /* clean up after myself */
  mem_remove_all_breakpoints ();
  INITIALIZING = 0;
}

/******************************************************************************
 * Put the registers into a known state
 *****************************************************************************/
void lc2_init_regs(void)
{
  int i;
  printinfo("Registers cleared\n");
  for (i = 0; i < NUM_REGS; i++) { R[i] = 0; }
  CCR = IR = HALT = 0;
  PC = LC2_USER_START_ADDRESS;
}

/******************************************************************************
*  lc2_run_program
*    Run the simulator starting at start_pc for STEPS steps. If CONTINUE is
*  non-zero, then step through a breakpoint.  Return non-zero if
*  breakpoint is encountered.
*  Parameters: starting PC, number of steps to run (<= 0 implies as many as
*    possible), and whether to continue upon hitting a breakpoint
*  Returns: non-zero if breakpoint is encountered
******************************************************************************/
int lc2_run_program(int start_pc, int STEPS, int CONTINUE)
{
  int num_steps = 0;
  PC = start_pc;

  HALT = 0;          /* make sure to turn halt off before running! */
  mem_write(0x0000FFFF, 0xFFFF);

  RUNNING = 1;
  while ((!HALT) && ((num_steps < STEPS) || (STEPS <= 0))) {
    /* step size of 0 or less means run 'forever' */
    if ((mem_breakpoint(PC)) && (CONTINUE == 0)) break;
    lc2_step_instruction();
    if (STEPS > 0) num_steps++;
  }
  RUNNING = 0;
  if (mem_breakpoint(PC)) return 1;
  else return 0;
}

/******************************************************************************
 * lc2_step_instruction
 *   Do the next instruction.
 * Parameters: none
 * Returns: none
 *****************************************************************************/
void lc2_step_instruction(void)
{
  int PCafterTrap = PC + 1;
  int instruction = lc2_fetch();

  lc2_do_instruction(instruction);
  num_instructions_processed++;

  /*  printf("PC=0x%04X stepintotraps=%d\n", PC, stepintotraps); */

  if ( ((instruction & 0x0000F000) == 0xF000) && (stepintotraps == 0)) {
    /* run the trap routine to completion, even if we are stepping */
    while ((!HALT) && (PC != PCafterTrap)) {   /* skip over the trap routine */
      instruction = lc2_fetch();
      lc2_do_instruction(instruction);
      num_instructions_processed++;
    }
  }
}

/******************************************************************************
*  lc2_fetch
*    Fetch the next instruction out of memory. Side-effects, are the obvious: 
*  change the instruction register (IR) and increment the PC.
*  Parameters: none
*  Calls: mem_read
*  Returns: integer version of the instruction
******************************************************************************/
int lc2_fetch(void)
{
  IR = mem_read(PC, 1);   /* devices are handled in memory code */
  if (insttrace) {        /* must dump trace BEFORE incrementing PC! */
    mem_print(PC, NULL);
  }
  PC++;
  return IR & 0x0000FFFF;
}

/******************************************************************************
*  lc2_do_instruction
*  This function modifies the current state of the LC-2 to what it would be
*    after executing the instruction given. Performs the decode, execute,
*    memory, and writeback stages that a pipelined implementation would
*    do.  Cycle-by-cycle simulation is for later.
*  Parameters:
*    integer representation of the instruction to perform
*  Calls: none
*  Returns: pointer to the buffer parameter
******************************************************************************/
void lc2_do_instruction(int instruction)
{
  /* same initial code as in unassemble.c */
  /* except that the page is computed with the PC here instead of a given
     address */
  static int opc, cond, dr, sr1, sr2, pgoffset9, imm5, offset6, imm8,
             imm_or_sr2, link_bit;
  int address;
  static int num_NOPS = 0;        /* count successive NOPS */

  /* calculate all the possible fields in the instruction for later use */
  opc = (instruction & 0x0000F000) >> 12;
  link_bit = (instruction & 0x00000800) >> 11;
  cond = (instruction & 0x00000E00) >> 9;
  dr = cond;
  sr1 = (instruction & 0x000001C0) >> 6;
  sr2 = (instruction & 0x00000007);
  imm_or_sr2 = (instruction & 0x00000020);  /* 1 if imm, 0 if sr2 */
  pgoffset9 = (instruction & 0x000001FF);
  imm5 = (instruction & 0x0000001F);
  if (instruction & 0x00000010)       /* the immediate is negative... */
    imm5 |= (0x0000FFE0);             /* ...so sign extend it */
  offset6 = (instruction & 0x0000003F);
  imm8 = (instruction & 0x000000FF);

  if (opc == 0x0) num_NOPS++;
  else num_NOPS = 0;

  if (((num_instructions_processed % 10000) == 0) &&
      (num_instructions_processed != 0)) {
    /* just do some system call to see if I can get some signals in; this
       must come somewhere so that all machine state is updated correctly  */
    printinfo("%u instructions executed\n", num_instructions_processed);
  }

  switch (opc) {
  case 0x0: /* BR, BRP, BRZ, BRZP, BRN, BRNP, BRNZ */
    /* if ((inst[11] & N) | (inst[10] & Z) | (inst[9] & P)) begin */
    /* simplify the code below by using logic above! */
    address = lc2_build_address(PC, pgoffset9);
    address &= 0x0000FFFF;  /* in case address wrapped */
    switch (cond) {
    case 0: /* NOP */
      break;
    case 1: /* BRP */
      if (CCR & 0x00000001) { PC = address; }
      break;
    case 2: /* BRZ */
      if (CCR & 0x00000002) { PC = address; }
      break;
    case 3: /* BRZP */
      if ((CCR & 0x00000002) || (CCR & 0x00000001)) { PC = address; }
      break;
    case 4: /* BRN */
      if (CCR & 0x00000004) { PC = address; }
      break;
    case 5: /* BRNP */
      if ((CCR & 0x00000004) || (CCR & 0x00000001)) { PC = address; }
      break;
    case 6: /* BRNZ */
      if ((CCR & 0x00000004) || (CCR & 0x00000002)) { PC = address; }
      break;
    case 7: /* BR or BRNZP - unconditional */
      PC = address;
      break;
    }
    if (insttrace) { printinfo("\t\t\tBranch result PC=%04X\n", PC); }

    if ((instruction & 0xFFFF) == 0x0) { /* NOP */
      if (num_NOPS > 100) {
	error (NORMAL, "The processor has executed 100 successive nops. Restart if required.\n");
	num_NOPS = 0;
	HALT = 1;
      }
    }

    break;
  case 0x1: /* ADD */
    if (imm_or_sr2) {
      R[dr] = (R[sr1] + imm5) & 0x0000FFFF;
    }
    else {
      R[dr] = (R[sr1] + R[sr2]) & 0x0000FFFF;
    }
    lc2_set_condition_codes(dr);
    if (insttrace) { printinfo("\t\t\tR%d=%04X CCR=%01X\n", dr, R[dr], CCR); }
    break;
  case 0x2: /* LD */
    address = lc2_build_address(PC, pgoffset9);
    address &= 0x0000FFFF;  /* in case address wrapped */
    R[dr] = mem_read(address, 1);
    lc2_set_condition_codes(dr);
    if (insttrace) { printinfo("\t\t\tR%d=%04X CCR=%01X\n", dr, R[dr], CCR); }
    break;
  case 0x3: /* ST */
    address = lc2_build_address(PC, pgoffset9);
    address &= 0x0000FFFF;  /* in case address wrapped */
    mem_write(address, R[dr]);
    if (insttrace) { printinfo("\t\t\tmem[%04X]=%04X\n", address, R[dr]); }
    break;
  case 0x4: /* JSR */
    if (link_bit == 1) R[7] = PC;         /* link (PC already bumped up) */
    address = lc2_build_address(PC, pgoffset9);
    address &= 0x0000FFFF;  /* in case address wrapped */
    PC = address;
    if (insttrace) { printinfo("\t\t\tJumped to PC=%04X\n", PC); }
    break;
  case 0x5: /* AND */
    if (imm_or_sr2) {
      R[dr] = (R[sr1] & imm5) & 0x0000FFFF;
    }
    else {
      R[dr] = (R[sr1] & R[sr2]) & 0x0000FFFF;
    }
    lc2_set_condition_codes(dr);
    if (insttrace) { printinfo("\t\t\tR%d=%04X CCR=%01X\n", dr, R[dr], CCR); }
    break;
  case 0x6: /* LDR */
    address = R[sr1] + offset6;
    address &= 0x0000FFFF;  /* in case address wrapped */
    R[dr] = mem_read(address, 1);
    lc2_set_condition_codes(dr);
    if (insttrace) { printinfo("\t\t\tR%d=%04X CCR=%01X\n", dr, R[dr], CCR); }
    break;
  case 0x7: /* STR */
    address = R[sr1] + offset6;
    address &= 0x0000FFFF;  /* in case address wrapped */
    mem_write(address, R[dr]);  /* dr field is actually src for store */
    if (insttrace) { printinfo("\t\t\tmem[%04X]=%04X\n", address, R[dr]); }
    break;
  case 0x8: /* RTI */
    /* First pop CCR */
    CCR = mem_read(R[6], 1);
    R[6] = (R[6] - 1) & 0x0000FFFF;
    /* Then pop PC */
    PC = mem_read(R[6], 1);
    R[6] = (R[6] - 1) & 0x0000FFFF;
    if (insttrace) {
      printinfo("\t\t\tRTI to PC=%04X, new NZP=%01X new SP=R6=%04X\n",
		PC, CCR, R[6]);
    }
    break;
  case 0x9: /* XOR */
    if (imm_or_sr2) {
      R[dr] = (R[sr1] ^ imm5) & 0x0000FFFF;
      /* printf("Doing not: R[sr1]=%04X, imm5=%04X\n", R[sr1], imm5); */
    }
    else {
      R[dr] = (R[sr1] ^ R[sr2]) & 0x0000FFFF;
    }
    lc2_set_condition_codes(dr);
    if (insttrace) { printinfo("\t\t\tR%d=%04X CCR=%01X\n", dr, R[dr], CCR); }
    break;
  case 0xA: /* LDI */
    address = lc2_build_address(PC, pgoffset9);
    address &= 0x0000FFFF;  /* in case address wrapped */
    address = mem_read(address, 1);
    address &= 0x0000FFFF;  /* in case address wrapped */
    R[dr] = mem_read(address, 1);
    lc2_set_condition_codes(dr);
    if (insttrace) { printinfo("\t\t\tR%d=%04X CCR=%01X\n", dr, R[dr], CCR); }
    break;
  case 0xB: /* STI */
    address = lc2_build_address(PC, pgoffset9);
    address &= 0x0000FFFF;  /* in case address wrapped */
    address = mem_read(address, 1);
    address &= 0x0000FFFF;  /* in case address wrapped */
    mem_write(address, R[dr]);
    if (insttrace) { printinfo("\t\t\tmem[%04X]=%04X\n", address, R[dr]); }
    break;
  case 0xC: /* JSRR */
    if (link_bit == 1) R[7] = PC;         /* link (PC already bumped up) */
    address = R[sr1] + offset6;
    address &= 0x0000FFFF;  /* in case address wrapped */
    PC = address;
    if (insttrace) { printinfo("\t\t\tJumped to PC=%04X\n", PC); }
    break;
  case 0xD: /* RET */
    PC = R[7];
    if (insttrace) { printinfo("\t\t\tReturned to PC=%04X\n", PC); }
    break;
  case 0xE: /* LEA */
    address = lc2_build_address(PC, pgoffset9);
    address &= 0x0000FFFF;  /* in case address wrapped */
    R[dr] = address;    
    lc2_set_condition_codes(dr);
    if (insttrace) { printinfo("\t\t\tR%d=%04X CCR=%01X\n", dr, R[dr], CCR); }
    break;
  case 0xF: /* trap */
    R[7] = PC;         /* interrupts link also so return is possible */
    address = lc2_build_address(0x00000000, imm8);
    address &= 0x0000FFFF;  /* in case address wrapped */
    PC = mem_read(address, 1);
    if (insttrace) { printinfo("\t\t\tTrapped to PC=%04X\n", PC); }
    /* see also the lc2_step_instruction function if you are changing opc for 
       trap */
    break;
  }
  return;
}

/******************************************************************************
*  lc2_set_condition_codes
*    This function modifies the condition codes N, Z, and P according to the
*  value in the result register. Recall that only values written into registers
*  cause the condition codes to change.  The condition code layout is as
*  follows, with X = unused: XXXXXXXXXXXXXNZP
*  Parameters:
*    integer number of the register that was modified
*  Calls: none
******************************************************************************/
void lc2_set_condition_codes(int reg_num)
{
  /* set the N flag */
  if (R[reg_num] & 0x00008000) CCR = 0x00000004;

  /* set the Z flag */
  else if (R[reg_num] == 0) CCR = 0x00000002;

  /* set the P flag */
  else CCR = 0x00000001;
}

/******************************************************************************
*  lc2_build_address
*    Given the program counter integer value and the up-to-9-bit page offset,
*  this function builds the memory address according to LC-2 specification. 
*  That is, it takes the page # bits (the high 6 of the program counter) and
*  the 10 bit page offset, and concatenates them together to form a full
*  16-bit memory address.
*  Parameters:
*    integer program counter and integer page offset
*  Calls: none
*  Returns: none
******************************************************************************/
int lc2_build_address(int pc, int page_offset)
{
  pc &= 0x0000FE00;
  page_offset &= 0x000001FF;
  pc |= page_offset;     /* combine 7 page-# bits with 9 page-offset bits */
  return pc;
}

/******************************************************************************
*  lc2_load_code
*    Reads the "object code" from the given filename.  The format is expected
*  to be one of the output formats of the LC-2 assembler, namely either:
*    1) one 16-bit word per line in "binary-text" notation
*        (e.g. 0011000000000000)
*    2) one 16-bit word per line in "hex-text" notation (e.g. 3000)
*    3) "true binary" format
*    This routine autodetects which type of code is present, assuming that
*      the file is formatted as expected. For example, try to read a C source
*      file in and things will get messed up!
*  Parameters: filename to read from
*  Calls: mem_write
*  Returns: 1 on success, 0 on failure
*  To Do: When return 0 or return 1, make sure to clean up after myself!
*  The following bugs are fixed (I think):
*         When a text file contains extra whitespace at the end of the line,
*           this routine doesn't work well because it is trying to autosense
*           what the file type is. The whitespace messes it up and makes it
*           think that it is true binary or something. Fix is that if we
*           hit whitespace, don't consider it when trying to figure out what
*           the type of file is.
******************************************************************************/
int lc2_load_code(char *filename)
{
  int i;
  int temp;
  int load_address;
  char ch;
  char *format_msg;
  int format = 0;        /* 1, 2, or 3 as described in the comment above */
  int base = 0;          /* 2, 16, or 0, respectively */

  static char load_file[MAXPATH] = { "" };
  static char sym_file[MAXPATH] = { "" };
  static char buffer[MAXPATH] = { "" };
  static char symname[MAXPATH] = { "" };
  unsigned int labeladdr = 0;
  int address = 0;
  int firstline = 1;     /* are we still looking for the load address? */
  FILE *objfile = NULL;
  FILE *symfile = NULL;

  process_tilde(filename, load_file);     /* if ~..., fully qualify it */

  if ((objfile = fopen(load_file, "r")) == NULL) {
    error (NORMAL, "Unable to load program code from file '%s'\n", load_file);
    return LC2_USER_START_ADDRESS;
  }

  /* read the first 20 bytes of the file to tell what type it is */
  for (i = 0; i < 20; i++) {
    if (feof(objfile)) break;   /* code is shorter than 20 bytes */
    ch = fgetc(objfile);
    /* The idea here is that if we see some character of format 2, we shouldn't
       ever go back to consider format 1 again. */
    if (isspace(ch)) {
	/* don't do anything; the file could be true binary, but the other two
	   files also could have whitespace in them */
    }
    else if ((ch == '0') || (ch == '1')) {
	if (format <= 1) format = 1;
    }
    else if ( ((ch >= '2') && (ch <= '9')) ||
	      ((ch >= 'a') && (ch <= 'f')) ||
              ((ch >= 'A') && (ch <= 'F')) ) {
	if (format <= 2) format = 2;
    }
    else format = 3;
  }
  switch (format) {
  case 1:  format_msg = "binary text";      base = 2;  break;
  case 2:  format_msg = "hexadecimal text"; base = 16; break;
  case 3:  format_msg = "true binary";      base = 0;  break;
  default: format_msg = "unknown";          base = 0;  break;
  }

  if (!INITIALIZING) {
    /* as a side effect of this, if the machine is initializing, it can
       read in any format of executable! */
    printinfo("Format for '%s' is %s\n", load_file, format_msg);
    if (format == 1) {
      error(NORMAL, "Cannot load: 'convert' must be run on the binary text to produce a true binary file\n");
      return LC2_USER_START_ADDRESS;
    }
    else if (format == 2) {
      error(NORMAL, "Cannot load: 'convert' must be run on the hex text to produce a true binary file\n");
      return LC2_USER_START_ADDRESS;
    }
    else if (format == 0) return LC2_USER_START_ADDRESS;
  }

  #ifndef SEEK_SET
  #define SEEK_SET 0
  #endif
  /* instead of doing this for some C compilers, should use a rewind or
     something */
  fseek(objfile, 0, SEEK_SET);

  while (!feof(objfile)) {
    if ((base == 2) || (base == 16)) {        /* binary or hexadecimal text */
      fgets(buffer, MAXPATH, objfile);
      if ((*buffer == '\0') || (feof(objfile))) break;
      temp = texttoint(buffer, base);
    }
    else if (base == 0) {                     /* true binary */
      temp = fgetc(objfile);
      if (feof(objfile)) break;               /* ignore odd byte at EOF */
      temp = temp << 8;                       /* leave space for low byte */
      temp += fgetc(objfile);
    }

    /* do I need special checks for end of file here? */
    if (temp == 0xFFFFFFFF) {
	error(NORMAL, "Can't process line %s in %s\n", buffer, load_file);
	return LC2_USER_START_ADDRESS;
    }
    else if (firstline) {
	if (feof(objfile)) {
	    error(NORMAL, "No code found in %s\n", load_file);
	    return LC2_USER_START_ADDRESS;
	}
	address = temp;  /* first 16-bit word is the load address */
	load_address = temp;
	if (!INITIALIZING) {
	  printinfo("Loading %s at address 0x%04X\n", load_file, address);
	  PC = address & 0x0000FFFF;
	  printinfo("Setting PC=%04X\n", PC);
	}
	firstline = 0;
    }
    else {
        mem_erase_label(address);
	mem_write(address, temp);
	address++;
    }
  }

  fclose(objfile);

  /* now process the symbol file, if there is one */

  /* get potential symbol file name */
  strcpy(sym_file, load_file);
  if (strlen(sym_file) > 4) {
    strcpy(sym_file+strlen(sym_file)-4, ".sym");
  }
  else {
    strcpy(sym_file, "unknown");
  }

  /* if we can open the symbol file, do it */
  if ((symfile = fopen(sym_file, "r")) == NULL) {
    if (!INITIALIZING) {
      error (NORMAL, "Unable to load program symbol table from file '%s'\n",
	     sym_file);
    }
  }
  else {
    printinfo("Loading symbols from file %s\n", sym_file);
    /* eat up the first 4 lines, which just have junk on them */
    fgets(symname, 100, symfile);
    fgets(symname, 100, symfile);
    fgets(symname, 100, symfile);
    fgets(symname, 100, symfile);

    while (fscanf(symfile, "//\t%s %04X\n", symname, &labeladdr)) {
      /*printf("Found symbol '%s' at labeladdr 0x%04X\n", symname, labeladdr); */
      if ((symname[0] != '\n') && (symname[0] != '\x0')) {  /* extra parsing */
	symname[20] = '\x0';  /* make sure labels aren't more than 20 chars long */
	/* make sure MAXPATH > 20 */
	mem_add_label(symname, labeladdr);
      }
      if (feof(symfile)) {
	break;
      }
    }
    fclose(symfile);
  }

  return load_address;
}

void lc2_record_simulator_startup_path(char *progpath)
{
  char *temp;

  /* allocates memory for global pointer; notice extra memory allocated */
  simulator_startup_path = (char *) calloc(strlen(progpath)+20, sizeof(char));
  if (!simulator_startup_path) {
    error(FATAL, "out of memory error");
  }
  strcpy(simulator_startup_path, progpath);

  /* chop off the xlc2sim executable filename and leave the path */
  temp = simulator_startup_path + strlen(simulator_startup_path);
  /* back temp up to the first front-slash */
  while ((*temp != '/') && (temp > simulator_startup_path)) temp--;

  if (*temp == '/') temp++;
  *temp = '\x0';
}

/* Simple accessor functions; these should be inlined but this is not */
/* a fast simulator, so we don't care for now. */

void lc2_set_reg(int regnum, int value)
{
  R[regnum] = (0x0000FFFF & value);
}

int  lc2_get_reg(int regnum)
{
  return (R[regnum] & 0x0000FFFF);
}

void lc2_set_PC(int _PC)
{
  PC = (0x0000FFFF & _PC);
}

int lc2_get_PC(void)
{
  return (0x0000FFFF & PC);
}

void lc2_set_IR(int _IR)
{
  IR = (0x0000FFFF & _IR);
}

int lc2_get_IR(void)
{
  return (0x0000FFFF & IR);
}

int lc2_get_CCR(void)
{
  return (CCR & 0x00000007);
}

int lc2_get_CCRN(void)
{
  return (CCR & 0x00000004);
}

int lc2_get_CCRZ(void)
{
  return (CCR & 0x00000002);
}

int lc2_get_CCRP(void)
{
  return (CCR & 0x00000001);
}

void lc2_set_CCR(int _CCR)
{
  CCR = (0x00000007 & _CCR);
}

void lc2_halt(void)
{
  HALT = 1;
}

void lc2_unhalt(void)
{
  HALT = 0;
}

int lc2_is_halted(void)
{
  return HALT;
}
