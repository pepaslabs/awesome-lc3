/******************************************************************************
* File:		xlc2sim.h - LC-2 simulator
* Author:	Matt Postiff, postiffm@umich.edu
* 
* Notices:	(C) Matt Postiff, 1995-1996. ALL RIGHTS RESERVED.
* 		    See the file NOTICE for a full copyright notice.
* 
* EECS 100 -- University of Michigan
* 
* Description:	Various definitions for the xlc2sim.c code
* 
* History:	Date		Who	Version	Change
* 		--------	---	-------	-------------------------------
*               8/28/96         MAP     3       Modified for Fall 1996
*               Fall 1998       MAP     4.2     Cleanup and move LC2 specific
*                                                code to cpu.[ch]
*
******************************************************************************/

#ifndef __XLC2SIM_H__
#define __XLC2SIM_H__

#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <signal.h>
#include <ctype.h>
#include <string.h>

#include "util.h"
#include "buttons.h"
#include "windows.h"
#include "unassemble.h"

#define DEFAULT_RUN_STEPS 1

extern int DISPLAY_LOW;
#define DEFAULT_DISPLAY_HEIGHT 0x0300;
extern int DISPLAY_HIGH;
extern int changed_display_size;

#define LINE_LEN 100

/* Various constants */
#define ON  1
#define OFF 0
#define BUFLEN 80

#define streq(s1, s2) !strcmp(s1, s2)
#define streqi(s1, s2) !strcasecmp(s1, s2)

#define TEXTHEIGHT \
	(text_font->max_bounds.ascent + text_font->max_bounds.descent)

#define TEXTWIDTH \
	(text_font->max_bounds.width)

     /* I don't get all this indirection in getting fonts */
typedef struct _AppResources
{
  String textFont;
} AppResources;

void execute_program (int pc, int steps, int cont_bkpt);
void do_command(char *command);
void redisplay_data (void);
void display_memory (void);
void display_registers (void);
void print_registers (void);
void control_c_seen (int arg);
void set_value_action (char *location_str, char *value_str);
char *alloc_string(char *strptr, char *init);
void list_breakpoints (void);
void print_version (void);
void print_opcodes(void);
void print_command_help (void);
void print_syntax (void);
void print_README (void);
char get_console_char (void);
void put_console_char (char c);
void write_output (port fp, char *string);
void record_xlc2sim_path(char *progpath);
void initialize (AppResources app_res);
void syntax (char *program_name);
void write_text_to_window (Widget w, char *s);
void signal_handler(int arg);
char get_console_char (void);
void put_console_char (char c);
void put_str (Widget w, char *s);
void put_char (Widget w, char c);
void read_input (char *str, int n);

extern XtAppContext app_context;
extern XFontStruct *text_font;

extern int RUNNING;

#endif
