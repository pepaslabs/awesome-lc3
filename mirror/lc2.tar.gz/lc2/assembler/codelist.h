/******************************************************************************
  codelist.h - LC-2 assembler

  Matt Postiff
  Created: 3/21/96
  Modified: 8/28/96

  Allows manipulation of machine code as a linked list of "tuples". The
  tuples consist of the machine code known to the current point (lacking
  offset resolution because of labels), as well as properties of that code,
  such as what fields yet need to be filled. See globals.h for the definition
  of the tuple structure.

******************************************************************************/

#ifndef __tuplelist_h
#define __tuplelist_h

#include "globals.h"
#include "string.h"
#include "symtable.h"
#include <assert.h>

tuple *CLremove(tuple **head, tuple *victim);
tuple *CLadd(tuple **head, int linenum, int locctr, int code, char *label);
tuple *CLjoin(tuple *head1, tuple *head2);
void CLdump(tuple *head, symtable *st, FILE *hex_fh, FILE *bin_fh, FILE *obj_fh, FILE *list_fh, FILE *sym_fh);
void print_bin(FILE *outfile, int code);
void print_obj(FILE *outfile, int code);
void print_listing(FILE *outfile, tuple *curr);
tuple *CLcleanup(tuple **head);

#endif
