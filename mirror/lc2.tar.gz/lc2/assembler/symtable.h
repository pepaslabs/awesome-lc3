/******************************************************************************
  symtable.h - LC-2 assembler

  Matt Postiff
  Created: 1/21/96
  Modified: 8/23/96

  Interface to symbol table manipulation routines. The function names are
  more or less implementation independent.

  Sequence of Use:
  ----------------
    The following explains the intended calling sequence for the functions
  provided:
    0) a symbol table structure should be created. Allocate these with calloc,
       or if statically allocated, zero out the headST and currST fields, or
       big problems will result.
    1) symtable_newscope should be called to create the first scope to be used
    2) symtable_add, symtable_remove, and symtable_lookup can be called to 
       add, remove, and lookup symbols at the current (first) scoping level.
    3) symtable_newscope can be called to create another symbol scope level.
    4) Symbols can be added and/or removed from the current scoping level only.
       Symbols can be looked up from the current or any previous scoping level.
       Thus, it is important that once a scoping level is closed in the source,
       it be removed.
     5) To remove a scoping level, call symtable_destroyscope. This will remove
	the current scoping level.
     6) To deallocate the whole symbol table structure (to get to a known start
	state, for example), call symtable_cleanup.
******************************************************************************/

#ifndef __symtable_h
#define __symtable_h

#include "globals.h"
#include "varlist.h"
#include <string.h>
#include <assert.h>

#ifndef NULL
#define NULL (0x0)
#endif

#define HASHSIZE 31          /* some prime number size for hash function */

/* Data-type description structure which represents a whole symbol table. A 
   linked list of these allows us to provide multiple scope levels for 
   symbols. The user of this ADT uses this structure to specify the
   symbol table desired. This is essentially the head node in a linked list
   of symbol tables, and it contains all the information about the symbol
   table, including the pointer to the head of the current symbol table (which
   may be several scope levels down) */

struct symtable {
  var_node *hashtable[HASHSIZE];  /* array of ptrs to symbol table entries */
  struct symtable *prev;          /* linked list pointers */
  struct symtable *next;
  /* keep track of the first symbol table in the list and top-of-stack*/
  struct symtable *headST;
  struct symtable *currST;        /* current scope */
  /* these are updated in the head node, which the user passes in when he wants
     to access the symbol table */
};
typedef struct symtable symtable;

      int symtable_remove(symtable *st, char *symname);
      int symtable_add(symtable *st, char *symname,
		       type_node *type, int offset);
     void symtable_newscope(symtable *st);
     void symtable_destroyscope(symtable *st);
var_node *symtable_lookup(symtable *st, char *symname);
     void symtable_dump(symtable *st, FILE *fh);
     void symtable_cleanup(symtable *st);

#endif
