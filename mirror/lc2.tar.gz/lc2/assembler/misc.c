/******************************************************************************
*    LC-2 Assembler - misc.C
*                                                 
*    EECS 100 -- Fall 1995           University of Michigan
* 
*    Matt Postiff	postiffm@engin.umich.edu           
*    Date created:	5/28/95
*    Date modified:     5/28/95
*    Description:	Miscellaneous string- and number-crunching routines
*                       that are used in the assembler.
******************************************************************************/

#ifndef _misc_C
#define _misc_C

#include "misc.h"

/******************************************************************************
*  strupr
*  Capitalizes a string (in-place) in an ANSI compatible way.  ANSI should have
*   defined this and strlwr so programmers wouldn't have to worry about which
*   kind of machine they are programming for (ASCII, EBCDIC).
*  Parameters: pointer to the first character of the string to capitalize
*  Calls: none
*  Returns: pointer the capitalized string (same as that passed in)
*  Global usage: none
******************************************************************************/
char *strupr(char *str)
{
  char *temp = str;          /* remember the start of the string */
  while (*str != 0x0) {
    if ((*str >= 'a') && (*str <= 'z')) *str = *str & 0xDF;
    str++;
  }
  return temp;
}

/******************************************************************************
* strlwr
*   Changes a string (in-place) to lower case in an ANSI compatible way. ANSI
*   should have defined this and strupr so programmers wouldn't have to worry
*   about which kind of machine they are programming for (ASCII, EBCDIC).
*  Parameters: pointer to the first character of the string to capitalize
*  Calls: none
*  Returns: pointer the capitalized string (same as that passed in)
*  Global usage: none
******************************************************************************/
char *strlwr(char *str)
{
  char *temp = str;              /* remember the start of the string */
  while (*str != 0x0) {
    if ((*str >= 'A') && (*str <= 'Z')) *str = *str | 0x20;
    str++;
  }
  return temp;
}

/******************************************************************************
*  strcmpi
*  The strcmpi function compares two strings in an ANSI-C++ compatible way. As
*    indicated by the name, the comparison is case insensitive.
*  Parameters: pointers to the strings to compare
*  Calls: strcpy, string_capitalize, strcmp
*  Returns:
*    < 0 if s1 < s2
*    = 0 is s1 = s2
*    > 0 if s1 > s2
*  Global usage: none
******************************************************************************/
int strcmpi(const char *s1, const char *s2)
{
  int res1, res2;
  while ((*s1 != 0x0) && (*s2 != 0x0)) {
    res1 = toupper(*s1), res2 = toupper(*s2);
    if (res1 != res2) return res1 - res2;  /* different, so quit early */
    s1++, s2++;
  }
  return toupper(*s1) - toupper(*s2);      /* same so far; return longer one */
}

/******************************************************************************
*  nextok
*    nextok extracts a substring from the string pointed to by ptr, which is
*   delimited by a character at the beginning (pointed to by ptr) and
*   a character at the end (token).
*  For example, if we have the string "This is a string", and ptr points
*   to 'T', then nextok will extract the string "This", and put it into
*   the buffer pointed to by substr.  This routine does not affecting the
*   string pointed to by ptr.
*  Note that if this routine runs into the end of a string (NULL) without
*   hitting the token it is looking for, it will return up to that point,
*   as if the last character in the string had been the token instead of a
*   NULL.  Note that the memory pointed to by substring is effectively cleared
*   at the start of this function.
*  Parameters:
*   *ptr : points to the start of a string to extract a token from
*   *substr : character pointer to a sufficiently long buffer
*   token : the end-of-substring-delimiting character; if token is 0x0, then
*     nextok stops at any whitespace (thus, there should be no whitespace at
*     the start of the string you pass in)
*  Calls: none
*  Returns: pointer (in the ptr string) to the character immediately following
*   the token, so that you can continue on extracting tokens, if you wish,
*   from the same string (using the returned pointer as the new starting spot)
*  Global usage: none
******************************************************************************/
char *nextok(char *ptr, char *substr, char token)
{
  char *tmp = ptr;        /* pointers to run through the strings */
  char *buf = substr;

  /* copy characters over to the temp. buffer space until you run into */
  /*  the token(s) (stop) or NULL */

  if (token != 0x0) {                /* normal lookup */
    while ( (*tmp != token) && (*tmp != 0x0) ) {
      *(buf++) = *(tmp++);
    }
  }
  else {                              /* stops at any whitespace */
    while ( (!isspace(*tmp)) && (*tmp != 0x0) ) {
      *(buf++) = *(tmp++);
    }
  }
    
  *buf = 0x0;        /* NULL terminate the buffer, just to be safe   */

  if (*tmp != 0x0)   /* we know if this is true, we've hit a token,  */
    tmp++;           /*  so we want to return a pointer one ahead of */
                     /*  where we are currently to prepare for next  */
  return tmp;
}

/******************************************************************************
*  skip
*  Produces a string pointer advanced beyond any occurences of a specific
*    character in the input string.  Useful for weeding out leading spaces
*    or 0's in input lines.
*  Parameters: pointer to the string to operate on; the character to skip
*  Calls: none
*  Returns: pointer to the string, past any of the skippable characters
*  Global usage: none
******************************************************************************/
char *skip(char *str, char to_skip)
{
  /* take care of possible leading sign */
  if ((*str == '-') || (*str == '+'))
    str++;
  while (*(str++) == to_skip);
  return str;
}

/******************************************************************************
*  eat_whitespace
*  Moves a string pointer forward or backward until it points to a character
*    that is not a whitespace character.  If direction is -1, it will start
*    at the end at work backwards.
*  Parameters: pointer to the string to operate on
*  Calls: isspace
*  Returns: (if forward) pointer to string, past any skippable whitespace
*           (if reverse) pointer to the last useable character in string
*  Global usage: none
******************************************************************************/
char *eat_whitespace(char *ptr, int direction)
{
  if (direction == -1) {           /* start at end and go in reverse */
    char *temp = ptr + strlen(ptr) - 1;
    while (isspace(*temp)) {
      temp--;
    }
    *(temp+1) = 0x0;             /* whack all the whitespace found */
    return temp;
  }
  else {
    while (isspace(*ptr)) {
      ptr++;
    }
    return ptr;
  }
}

/******************************************************************************
*  whack_char
*  Gets rid of a single occurence of the specified character at the end of 
*    the given string.  It the character is present as the last character
*    before the terminating NULL byte, it is replaced with a NULL byte, ending
*    the string one byte "early."
*  Parameters: pointer to the string to operate on; character of interest
*  Calls: none 
*  Returns: none
*  Global usage: none
******************************************************************************/
void whack_char(char *str, char to_whack)
{
  /* fast forward to the end of the string */
  while (*(str++) != 0x0)
  if (*(str - 1) == to_whack)
    *(str - 1) = 0x0;
}

/******************************************************************************
*  valid_digit
*  Determines if a digit is legal in the base system given.  Handles bases 2
*    through 36.
*  Parameters: digit to test and base digit is to be tested in
*  Calls: none 
*  Returns: value of the digit in decimal if the digit is legal, -1 if illegal
*  Global usage: none
******************************************************************************/
int valid_digit(char _d, int base)
{
  int d = toupper(_d);

  if ( (d >= '0') && (d <= '9') )
    d = d - '0';      /* invariant: d is between 0 and 9, inclusive */
  else if ( ( d >= 'A') && (d <= 'Z') )
    d = d - 'A' + 10; /* invariant: d is between 10 and 35, inclusive */
  else return -1;

  /* invariant: d is between 0 and 35 */
  if (d < base)
    return d;
  else return -1;
}

/******************************************************************************
*  check_num
*  Determines if the string representation of a number, given the base that
*    the number is supposed to be in, is valid for that base (checks digit by
*    digit to see if each is in range).
*  Parameters: pointer to the number in string format, base (2-36)
*  Calls: valid_digit
*  Returns: 1 if the number is legal, 0 if illegal
******************************************************************************/
int check_num(char *str, int base)
{
  while (*str) {
    if (valid_digit(*str, base) == -1)
      return 0;
    str++;
  }
  return 1;
}

/******************************************************************************
* readnum
*  Reads a number in the base given.  Assumes the dest has enough allocated
*    space to hold the string representation of the number.
*  Parameters: pointer to the number in string format, base (2-36)
*  Calls: valid_digit
*  Returns: pointer to the character after the last useful one; fills in the
*    numerical_val parameter with the decimal value of the number read in.
******************************************************************************/
char *readnum(char *src, char *dest, int base, int *numerical_val)
{
  int end_multiply,
      digit_val;

  *numerical_val = 0;
  end_multiply = 1;                    /* default to positive */
  if (*src == '-') {
    end_multiply = -1;                 /* remember signage of the original */
    *(dest++) = *(src++);              /* put minus sign in destination */
  }

  while ( (*src != 0x0) && ((digit_val = valid_digit(*src, base)) != -1) ) {
    *(dest++) = *(src++);
    *numerical_val *= base;            /* calculate integer format */
    *numerical_val += digit_val;
  }
  *dest = 0x0;                         /* null-terminate destination */
  *numerical_val *= end_multiply;      /* figure in sign */
  return src;
}

/******************************************************************************
*  hextobin
*  Converts a hexadecimal string of digits into its corresponding binary 
*    representation via a lookup table. The binary result will contain 
*    a multiple of 4 characters: precisely, it will contain 4 * strlen(hex)
*  Parameters:
*    hex: pointer to the number in hex string format
*    bin: pointer to a buffer to store the binary result into
*  Calls: none
*  Returns 1 on success, 0 else
******************************************************************************/
int hextobin(char *hex, char *bin)
{
  char *bintable[16] = {"0000", "0001", "0010", "0011",
                        "0100", "0101", "0110", "0111",
                        "1000", "1001", "1010", "1011",
                        "1100", "1101", "1110", "1111" };
  int index;
  char *binptr = bin;
  *binptr = 0x0;

  while (*hex != 0x0) {
    index = valid_digit(*hex, 16);
    if (index == -1) return 0;
    else {
      strcat(binptr, bintable[index]);
      binptr += 4;                       /* for quicker repetition since */
      hex++;                             /* strcat loops to end of dest each */
    }                                    /* time */
  }
  *binptr = 0x0;
  return 1;
}

/******************************************************************************
*  bintohex
*  Converts a binary string of digits into its corresponding hex 
*    representation via a lookup table. The hex result will be padded out so
*    that it represents a binary number length that is a multiple of 4 bits. 
*  Parameters:
*    bin: pointer to the number in hex string format
*    hex: pointer to a buffer to store the binary result into
*  Calls: none
*  Returns 1 on success, 0 else
******************************************************************************/
int bintohex(char *bin, char *hex)
{
  char hextable[16] = {'0','1','2','3','4','5','6','7',
                       '8','9','A','B','C','D','E','F'};
  int index = 0,
      i;
  char *binptr = bin;

  if (!check_num(bin, 2)) return 0;

  /* take care of stragglers at the front */
  for (i = 0; i < (strlen(bin) % 4); i++) {
    index *= 2;
    index += *(bin+i) - '0';
    binptr++;
  }
  if ((strlen(bin) % 4) > 0) *(hex++) = hextable[index];

  /* now do the "main body" 4 bits at a time; we are guaranteed an integral */
  /* number of 4-bit chunks to work with */
  index = 0;
  while (*binptr != 0x0) {
    for (i = 0; i < 4; i++) {
      index *= 2;
      index += *binptr - '0';
      binptr++;
    }
    *(hex++) = hextable[index];
    index = 0;
  }
  *hex = 0x0;
  return 1;
}

#endif
