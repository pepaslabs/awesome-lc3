/******************************************************************************
*    LC-2 Assembler - misc.h
*                                                
*    EECS 100 -- Fall 1995           University of Michigan
*
*    Matt Postiff	postiffm@engin.umich.edu           
*    Date created:	5/28/95
*    Date modified:     5/28/95
*    Description:	Interface for miscellaneous string- and number-
*                       crunching routines that are used in the assembler.
******************************************************************************/

#ifndef _misc_H
#define _misc_H

#include <ctype.h>
#include <string.h>

/* string-handling functions */
char *strupr(char *str);
char *strlwr(char *str);
int strcmpi(const char *s1, const char *s2);
char *nextok(char *ptr, char *substr, char token);
char *skip(char *str, char to_skip);
char *eat_whitespace(char *ptr, int direction);
void whack_char(char *str, char to_whack);

/* number-crunching functions */
int valid_digit(char _d, int base);
int check_num(char *str, int base);
char *readnum(char *src, char *dest, int base, int *numerical_val);
int hextobin(char *hex, char *bin);
int bintohex(char *bin, char *hex);

#endif
