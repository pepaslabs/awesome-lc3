/******************************************************************************
  globals.h - LC-2 assembler

  Matt Postiff
  Created 3/16/96
  Modified 8/28/96

  Global definitions accessible from all modules.

******************************************************************************/

#ifndef __globals_h
#define __globals_h

#include "../lc2.h"
#include <stdio.h>

#define MAXLINELEN 500          /* maximum input line length
				   (for error handling) */
#define MAXLEN     8192          /* maximum output length per emit call */
#define MAXPATH    8192
#define ERROR 0
#define OK    1

/* The basic identifier types that the language supports */
enum datatype { ERROR_T=0, INT_T, CHAR_T, STRING_T };
typedef enum datatype datatype;

/* LC-2 ISA definitions */
enum needed_fields { NONE=0, RR=0x18, RI=0x12, RRR=0x1C, RRI=0x1A, RP=0x11,
	P=0x1, I=0x02 };
typedef enum needed_fields needed_fields;

enum fields { R1=0x10, R2=0x08, R3=0x04, IMM=0x02, PAGEADDR=0x01 };
typedef enum fields fields;

/* Keep track of information about labels. This is the basic node in the
   symtable structure. I've retained the name 'var_node' even though the
   label names hardly qualify as variables. It should really be sym_name
   in this case. */
struct type_node {
  char *typename;              /* this structure just for varlist code */
};
typedef struct type_node type_node;

struct var_node {
  char *varname;               /* name of the variable, field, parameter */
  struct type_node *type;      /* pointer to the type of this node */
  int offset;                  /* stack offset, relative to base pointer */
  int initialized;             /* has this variable been used on a LHS yet? */

  struct var_node *next;       /* linked-list pointers */
  struct var_node *prev;
  struct var_node *last;       /* novel: last element in this list */
};
typedef struct var_node var_node;

struct constant {
  datatype type;
  union {
    int intval;
    char charval;
    char *stringval;
  } u;
};
typedef struct constant constant;

struct location {
  int pageaddr;
  char *label;
};
typedef struct location location;

struct tuple {
  int linenum;                         /* line number this code is on */
  int locctr;                          /* location counter for this inst */
  char *currlabel;                     /* label associated with this locctr */
  int code;                            /* low 16 bits are the code */
  char *label;                         /* a label needing resolution */

  /* the following fields are for printing listing files */
  int opc;                             /* indices into a string array */
  int fields_needed;                   /* what fields this instruction uses */
  int r1, r2, r3;
  int imm;                             /* immediate data */

  struct tuple *next;                  /* linked list pointers */
  struct tuple *prev;
  struct tuple *last;                  /* novel: last element in this list */
};
typedef struct tuple tuple;

/* these are defined in assemble.l */
extern char *yytext;                    /* current token string */

extern FILE *yyfh;                      /* current file handle */
extern int yylinenum;
extern char *yyfilename;                /* current filename */
extern char linebuf[MAXLINELEN];        /* save for error reporting */
extern char oldlinebuf[MAXLINELEN];        /* save for error reporting */
extern int tokenpos;                    /* current token position */

void yylexinit(FILE *someotherinput, char **argv);
int yylex(void);
int myyylex(void);

/* these are defined in assemble.g */
int error(char *errfmt, ...);
extern char *language[];

#endif
