/******************************************************************************
  codelist.c - LC-2 assembler

  Matt Postiff
  Created: 3/21/96
  Modified: 8/28/96

  Linked list of code in n-tuple form.

  See codelist.h for more information.

  Comments on the last pointer in the node: This is a neat idea which makes it
  easy to concatenate two lists together. A pointer to the last node is
  necessary to do such an operation efficiently, so I decided to stick a copy
  in each node. The idea is to keep each last pointer pointing to the last
  node in the list of which a node is part. Unfortunately, this is not 
  practical since when you delete the last node in the list, the last pointers
  are left hanging in most of the nodes. It is sufficient to guarantee that
  the last pointer in the head node is always correct, because this is the
  only one that you really need.

  Need to print labels in the listing file!

******************************************************************************/

#include <malloc.h>
#include "codelist.h"
#include "globals.h"

/*********************************************************************
  Remove the specified node from it's list.
*********************************************************************/
tuple *CLremove(tuple **head, tuple *victim)
{
  if ((!head) || (!*head) || !victim) return NULL;

  if (victim->prev) victim->prev->next = victim->next;
  if (victim->next) victim->next->prev = victim->prev;
  if (victim == (*head)->last) (*head)->last = victim->prev;
  if (victim == *head) {
    *head = victim->next;
    (*head)->last = victim->last;
  }
  free(victim);
  return *head;
}

/*********************************************************************
  Add a node to the end of the given list.
*********************************************************************/
tuple *addtoend(tuple *head, tuple *newnode)
{
  /* add the newnode to the end of the given list */
  newnode->next = NULL;
  newnode->prev = NULL;
  newnode->last = newnode;
  if (head) {
    head->last->next = newnode;
    newnode->prev = head->last;
    head->last = newnode;
  }
  return newnode;
}

/*********************************************************************
  Add the given machine code to the end of the list. Return a pointer
  to the node created.
*********************************************************************/
tuple *CLadd(tuple **head, int linenum, int locctr, int code, char *label)
{
  tuple *newnode;

  newnode = (tuple *) calloc(1, sizeof(tuple)); assert(newnode);
  newnode->linenum = linenum;
  newnode->locctr = locctr;
  newnode->code = code;
  newnode->label = label;

  addtoend(*head, newnode);
  if (*head == NULL) *head = newnode;  /* first time setup */
  return newnode;
}

/*********************************************************************
  Join two tuplelists together. Return a pointer to the new list, which
  is really a pointer to the list specified in head1 with the list
  specified by head2 attached at the end. Return NULL if the lists 
  could not be successfully joined (both were empty lists or the unique
  identifier would have been duplicated in the joined list).
*********************************************************************/
tuple *CLjoin(tuple *head1, tuple *head2)
{
  /* one list is empty, so just return the other unmodified */
       if (head1 == NULL) return head2;
  else if (head2 == NULL) return head1;

  /* add the second list to the end of the first */
  head1->last->next = head2;
  head2->prev = head1->last;
  head1->last = head2->last;
  return head1;
}

/*********************************************************************
  Print the contents of the entire list.
*********************************************************************/
void CLdump(tuple *head, symtable *st, FILE *hex_fh, FILE *bin_fh, FILE *obj_fh, FILE *list_fh, FILE *sym_fh)
{
  tuple *curr = head;
  var_node *sym;

  for (; curr; curr = curr->next) {
    /* resolve page address if necessary */
    if (curr->label != NULL) {
      sym = symtable_lookup(st, curr->label);
      if (!sym) {
	error("symbol '%s' referenced but not defined", curr->label);
	error("assembler output is invalid");
      }
      else if (curr->opc == LIDATA) {
	/* don't chop the label address in a .fill */
	curr->code = sym->offset;  // offset really contains full address
	curr->imm = sym->offset;  // offset really contains full address
      }
      else {
	/* normal case; chop the label address for these insts because they
	   only have 9-bits of storage for that */
	curr->code |= (0x000001FF & sym->offset);
	curr->imm = sym->offset;  // offset really contains full address
      }
    }

    /* print out the code in various formats */
    fprintf(hex_fh, "%04X\n", curr->code);
    print_bin(bin_fh, curr->code); fputc('\n', bin_fh);
    print_obj(obj_fh, curr->code);

    /* print out the listing file */
    print_listing(list_fh, curr);
  }

  /* print out the symbol table */
  symtable_dump(st, sym_fh);

  return;
}

/******************************************************************************
 print_bin
 Printing the binary text code to a file.  The simulator expects the
   code one word per line.
 Parameters:
   outfile : the output file to write to
   code : the code
******************************************************************************/
void print_bin(FILE *outfile, int code)
{
  int mask = 0x00010000;
  int i, temp;
  /*printf("code=%04X\n", code);*/
  for (i = 0; i < 16; i++) {
    mask = mask >> 1;   /* masks are 0x8000, 0x4000, ..., 0x0001 */
    temp = (code & mask) >> (15-i);
    /*printf("\tmask=%04X, temp=%c\n", mask, temp+'0');*/
    fputc(temp+'0', outfile);
  }
}

/******************************************************************************
 print_obj
 Print the REAL object code for the instruction. Takes the binary of the
   instruction and converts each 8 bits into its equivalent character,
   and writes the character to the file stream passed as a parameter.
 Notes: Because the string .FILLps are written every-other byte, (LC-2 is
        defined to be little-endian) this routine should work correctly in
        all cases.
******************************************************************************/
void print_obj(FILE *outfile, int code)
{
  char thebyte;

  thebyte = (code & 0xFF00) >> 8;     /* print the high byte first */
  fputc(thebyte, outfile);
  /*fwrite(&thebyte, 1, 1, outfile);*/
  /*write(outfile, &thebyte, 1);*/
  /*fprintf(stderr, "wrote byte=%08X\n", thebyte);*/

  thebyte = code & 0x00FF;            /* print the low byte second */
  fputc(thebyte, outfile);
  /*fwrite(&thebyte, 1, 1, outfile);*/
  /*write(outfile, &thebyte, 1);*/
  /*fprintf(stderr, "wrote byte=%08X\n", thebyte);*/

  return;
}

/******************************************************************************
  print_listing
  Print the listing file information for this instruction.
******************************************************************************/
void print_listing(FILE *outfile, tuple *curr)
{
  fprintf(outfile, "(%04X) %04X  ", curr->locctr, curr->code);
  print_bin(outfile, curr->code);
  fprintf(outfile, "  (%3d) ", curr->linenum);

  /* print the line label (blank for now) */
  fprintf(outfile, "%-16s", curr->currlabel ? curr->currlabel : "");

  /* print the instruction (the hard part) */
  fprintf(outfile, "%-6s ", language[curr->opc]);

  if (curr->fields_needed & R1) {
    fprintf(outfile, "r%d ", curr->r1);
  }
  if (curr->fields_needed & R2) {
    fprintf(outfile, "r%d ", curr->r2);
  }
  if (curr->fields_needed & R3) {
    fprintf(outfile, "r%d ", curr->r3);
  }
  if (curr->fields_needed & I) {
    fprintf(outfile, "0x%04X ", curr->imm);
  }
  if (curr->fields_needed & P) {
    if (curr->label != NULL) {
      fprintf(outfile, "%s ", curr->label);
    }
    else fprintf(outfile, "0x%04X ", curr->imm);
  }

  fprintf(outfile, "\n"); fflush(outfile);
}

/*********************************************************************
  Deallocate all storage associated with the list.
*********************************************************************/
tuple *CLcleanup(tuple **head)
{
  tuple *temp;
  for (temp = *head; *head; temp = *head) {
    *head = temp->next;
    free(temp);
  }
  *head = NULL;
  return NULL;
}



