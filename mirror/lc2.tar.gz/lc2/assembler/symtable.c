/******************************************************************************
  symtable5.c - LC-2 assembler

  Matt Postiff
  Created: 2/4/96
  Modified: 8/24/96

  Implementation of symbol table. This version supports multiple scoping
  levels by keeping a linked list stack of symbol tables. See symtable.h
  for usage details. The item being stored in the table is really not needed
  here, except that a pointer to it is returned from several of the
  functions.

  To get around the C vs. C++ problem, I require that a pointer to the symbol
  table to be passed in to each function. The pointer is to a structure which
  is the same as used internally. This is a little space inefficient (actually,
  a separate structure containing only headST and currST pointers should be
  created), but gets the job done. Two or more symbol tables are typically
  needed--one for types, one for variables.

  Calls to assert(st) are made at the start of each function to ensure that
  the user passed in a symbol table structure--but no error checking beyond
  this is performed. Of course, on first use, I initialize it, but that
  is all.

  Note that no identifier should have type number 0, as this is the value
  returned in the error cases.

******************************************************************************/

/* #define DEBUG */
#include <malloc.h>
#include "symtable.h"

/* internal functions */
int hash(symtable *st, char *symname);

/*********************************************************************
  Create a new scope, i.e. add a symbol table to the end of the list
  (top of the stack) and make it the current scope.
*********************************************************************/
void symtable_newscope(symtable* st)
{
  /* calloc zeroes out all fields, so no other initialization needed */
  symtable *temp = (symtable *)calloc(1, sizeof(symtable));
  assert(temp);
  assert(st);

  if (!st->currST) {
    st->currST = temp;
    st->headST = st->currST;
  }
  else {
    st->currST->next = temp;
    temp->prev = st->currST;
    st->currST = temp;
  }
}

/*********************************************************************
  Remove all symbol references in the current scoping level, i.e. remove
  the current symbol table and go back to the previous.
*********************************************************************/
void symtable_destroyscope(symtable* st)
{
  int i;
  symtable *STtemp;

  assert(st);
  if (!st->currST) return;  /* no scope to pop */

  /* change the current scope back one level */
  STtemp = st->currST;
  st->currST = st->currST->prev;

  /* for each hash bucket */
  for (i = 0; i < HASHSIZE; i++) {
    /* run down the list deleting symbols on the way */
    varlist_cleanup(&(STtemp->hashtable[i]));
  }
  free(STtemp);
  if (st->currST) st->currST->next = NULL;
  else st->headST = NULL;
}

/*********************************************************************
  Do some hashing function on the symbol name to index into the hash
  table.

  The first part of this function provides initialization. I figure
  that the hash function is always going to be called, so this is a good
  place to put it. For efficiency, on the other hand, the extra not-taken
  branch is not good, but...
*********************************************************************/
int hash (symtable *st, char *symname)
{
  int temp = 0;
  char *ch;

  assert(st);
  /* st->currST used as the initialization flag */
  if (!st->currST) symtable_newscope(st);

  /* a simple hashing function */
  for (ch = symname; *ch != 0x0; ch++) {
    temp += *ch;
  }
  return (temp % HASHSIZE);
}

/*********************************************************************
  Remove the symbol with the given name from the table. Return OK on
  success, ERROR else.
*********************************************************************/
int symtable_remove(symtable* st, char *symname)
{
  var_node **curr;
  if (symname == NULL) return ERROR;
  curr = &(st->currST->hashtable[hash(st, symname)]);
  varlist_remove(curr, symname);
  return OK;
}

/*********************************************************************
  Add the symbol to the symbol table. On success, return OK, else ERROR.

  In the latter case, the symbol is probably already in the table. 
  In a rare case, it may be that no more memory can be allocated. Symbol 
  addition is only allowed in the current scope.

  Symbols may have NULL types. This is handy for labels, which don't
  really have a type.
*********************************************************************/
int symtable_add(symtable* st, char *symname,
		       type_node *type, int offset)
{
  var_node **curr;
  if (symname == NULL) return ERROR;
  curr = &(st->currST->hashtable[hash(st, symname)]);
  if (varlist_add(curr, symname, type, offset))
    return OK;
  else return ERROR;
}

/*********************************************************************
  Return pointer to symbol structure, if it exists in the table. The
  algorithm for this has changed a bit since it's earlier versions: it
  first searches the current symbol table, then any previous ones. This
  allows processing of the multiple-scope declaration/usage patterns that 
  languages like C and Pascal provide.
*********************************************************************/
var_node *symtable_lookup(symtable* st, char *symname)
{
  int head;
  var_node *curr;
  var_node *result = NULL;
  symtable *iterator;

  if (symname == NULL) return ERROR;
  head = hash(st, symname);

  iterator = st->currST;

  do {
    curr = iterator->hashtable[head];
    /* search the linked list for the symbol */
    result = varlist_lookup(curr, symname);
    if (result) return result;
  } while ((iterator = iterator->prev));    /* walk the stack backwards */

  return NULL;
}

/*********************************************************************
  Dump the contents in a nice format onto the screen. Compared to the 
  linked list version, this is slightly complicated by the fact that 
  the hash table is not as easy to traverse end to end.
*********************************************************************/
void symtable_dump(symtable* st, FILE *fh)
{
  int i, level, needheader;
  symtable *iterator;

  assert(st);
  iterator = st->headST;

  if (!iterator) { 
    fprintf(fh, "//\n// Empty symbol table\n//\n");
    return;
  }

  fprintf(fh, "// Symbol table\n");

  for (level = 0; iterator; iterator = iterator->next, level++) {
    fprintf(fh, "// Scope level %d:\n", level);
    needheader = 1;
    for (i = 0; i < HASHSIZE; i++) {
      if (iterator->hashtable[i]) {
	varlist_dump(iterator->hashtable[i], needheader, fh);
	needheader = 0;
      }
    }
  }
  fprintf(fh, "\n");
  return;
}

/*********************************************************************
  Remove all symbols and deallocate all memory. Since this routine
  sets st->currST to NULL, another call to symtable_add, for example,
  will re-invoke the normal initialization sequence and a new symbol
  table will be created.
*********************************************************************/
void symtable_cleanup(symtable* st)
{
  int i;
  var_node **curr, *temp;
  symtable *iterator, *STtemp;
  curr = &temp;

  assert(st);

  /* for each symbol table scope level */
  for (iterator = st->headST; iterator; ) {
    /* for each hash bucket */
    for (i = 0; i < HASHSIZE; i++) {
      *curr = iterator->hashtable[i];
      /* run down the list deleting symbols on the way */
      varlist_cleanup(curr);
    }
    STtemp = iterator;
    iterator = iterator->next;
    free(STtemp);
  }
  st->currST = NULL;
  st->headST = NULL;
}

