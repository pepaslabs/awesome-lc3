typedef union {
  char *identifier;
  int binary;
  int value;
  int size;
  int packed_flag;
  constant constant;         /* see globals.h */
  location location;         /* see globals.h */
} YYSTYPE;
#define	LOR	258
#define	LAND	259
#define	EQ	260
#define	NE	261
#define	LE	262
#define	GE	263
#define	ADD	264
#define	AND	265
#define	XOR	266
#define	LDR	267
#define	STR	268
#define	LD	269
#define	ST	270
#define	LDI	271
#define	STI	272
#define	NOP	273
#define	JSR	274
#define	JMP	275
#define	JSRR	276
#define	JMPR	277
#define	TRAP	278
#define	RET	279
#define	RTI	280
#define	LEA	281
#define	BRNOP	282
#define	BR	283
#define	BRN	284
#define	BRZ	285
#define	BRP	286
#define	BRNZ	287
#define	BRNP	288
#define	BRZP	289
#define	BRNZP	290
#define	NOT	291
#define	HALT	292
#define	IN	293
#define	PUTC	294
#define	PUTS	295
#define	PUTSP	296
#define	GETC	297
#define	CODEDECL	298
#define	DATA	299
#define	DATAPACKED	300
#define	BLOCK	301
#define	END	302
#define	REG	303
#define	INTCONST	304
#define	CHARCONST	305
#define	STRINGCONST	306
#define	IDENTIFIER	307
#define	TKNERROR	308
#define	DUMPSYMBOLTABLE	309


extern YYSTYPE yylval;
