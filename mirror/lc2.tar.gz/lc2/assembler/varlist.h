/******************************************************************************
  varlist.h - LC-2 assembler

  Matt Postiff
  Created: 3/21/96
  Modified: 8/27/96

  Interface to var_node list structure. Provides linked-list capabilities for
  use by the symbol table and type table.

  Note that each scope-level of the symbol table is a hash table with 
  var_node linked list buckets. The type table has types, one of which may be
  a record, which references a linked list of var_nodes (its fields).

  Each var_node has a type, which is a pointer to a type_node.

  All node definitions are in globals.h.

  Because there are multiple instantiations of var_node linked lists in a
  program, each function requires a pointer to the head of the list as a
  parameter.

******************************************************************************/

#ifndef __varlist_h
#define __varlist_h

#include "globals.h"
#include "string.h"
#include <assert.h>

/* external data structures */
extern char *IR[];

/* No need for a data-type description structure (there would only be one
   field: the pointer to the head of the list */

/* Be careful about the return values. In _add, the return value needs to
   be a pointer to the newly-added node. In the current implementation, this
   happens to also be a pointer to the list with the new node in it since the
   new node is at the front of the list. In other cases, like _remove, the
   return is to the new list */

var_node *varlist_remove(var_node **head, char *varname);
var_node *varlist_add(var_node **head, char *varname,
		      type_node *type, int offset);
var_node *varlist_concatenate(var_node *head1, var_node *head2);
var_node *varlist_lookup(var_node *head, char *varname);
     void varlist_dump(var_node *head, int printheader, FILE *fh);
var_node *varlist_cleanup(var_node **head);

#endif

