/******************************************************************************
  varlist.c - LC-2 assembler

  Matt Postiff
  Created: 3/21/96
  Modified: 8/27/96

  Implements a linked list of var_node structures.

  See varlist.h for details.

  Comments on the last pointer in the node: This is a neat idea which makes it
  easy to concatenate two lists together. A pointer to the last node is
  necessary to do such an operation efficiently, so I decided to stick a copy
  in each node. The idea is to keep each last pointer pointing to the last
  node in the list of which a node is part. Unfortunately, this is not 
  practical since when you delete the last node in the list, the last pointers
  are left hanging in most of the nodes. It is sufficient to guarantee that
  the last pointer in the head node is always correct, because this is the
  only one that you really need.

******************************************************************************/

#include <malloc.h>
#include "varlist.h"

/*********************************************************************
  Remove the symbol with the given name from the list. Return pointer
  to new list, NULL on error.
*********************************************************************/
var_node *varlist_remove(var_node **head, char *symname)
{
  var_node *curr;
  if ((!head) || (!*head)) return NULL;
  curr = *head;
  /* search down the list looking for the symbol */
  for (; curr; curr = curr->next) {
    if (strcmp(curr->varname, symname) == 0) {
      /* found the variable, remove it and return */
      if (curr->prev) curr->prev->next = curr->next;
      if (curr->next) curr->next->prev = curr->prev;
      if (curr == (*head)->last) (*head)->last = curr->prev;
      if (curr == *head) {
	*head = curr->next;
	(*head)->last = curr->last;
      }
      free(curr), curr = NULL;
      return *head;
    }
  }
  return NULL;
}

/*********************************************************************
  Add a new symbol to the list. On success, return list head pointer,
  else NULL. If head is passed in as NULL, a new node is created which
  is the start of a new list. If head passed points to a legal list, then
  the new node is added at the front of the list and the new head pointer
  is returned (i.e. a pointer to the new node). Error cases include if the 
  symbol is already in the list or memory cannot be allocated for the new node.

  Symbols must have non-null names. Symbols may have NULL types, for example,
  if they are labels and don't really have types.
*********************************************************************/
var_node* varlist_add(var_node **head, char *varname, 
		      type_node *type, int offset)
{
  var_node *node, *first = NULL;

  if (varname == NULL) return NULL;
  if (head && *head) {
    if (varlist_lookup(*head, varname) != NULL) {
      return NULL;
    }
  }

  /* figure out the pointer to the front of the existing list, taking into 
     account that the given head pointer may be NULL */
  if (head)
    first = *head;

  /* add a new node to the front of the list */
  node = (var_node *) calloc(1, sizeof(var_node));
  assert(node);
  node->next = first;
  node->prev = NULL;
  if (first) {
    first->prev = node;
    node->last = first->last;
  }
  else node->last = node;
  if (head) *head = node;
  if (varname) node->varname = strdup(varname);
  else node->varname = NULL;
  node->type = type;
  node->offset = offset;
  node->initialized = 0;
  return node;
}

/*********************************************************************
  Concatenate two lists together. Return a pointer to the new list.
*********************************************************************/
var_node *varlist_concatenate(var_node *head1, var_node *head2)
{
  var_node *curr;
  /* should I really be doing this? */
  if ((head1 == NULL) || (head2 == NULL)) return NULL;

  /* do a name check to ensure that no nodes in the first list are in the
     second (duplicate record field names) */
  /* search down the list, looking for the symbol in the other list */
  for (curr = head1; curr; curr = curr->next) {
    if (varlist_lookup(head2, curr->varname)) return NULL;
  }

  /* add the second list to the end of the first */
  head1->last->next = head2;
  head2->prev = head1->last;
  head1->last = head2->last;
  return head1;
}

/*********************************************************************
  Return a pointer to the var_node structure, if it exists in the list.
*********************************************************************/
var_node *varlist_lookup(var_node *head, char *varname)
{
  var_node *curr = head;
  if (!varname) return NULL;
  /* search down the list looking for the symbol */
  for (; curr; curr = curr->next) {
    if (strcmp(curr->varname, varname) == 0) {
      /* found the variable, return */
      return curr;
    }
  }
  return NULL;
}

/*********************************************************************
  Print the contents of the entire list. If printheader is true, then
  the column headers are printed.
*********************************************************************/
void varlist_dump(var_node *head, int printheader, FILE *fh)
{
  var_node *curr = head;
  if (curr && printheader) {
    fprintf(fh, "//\tSymbol Name       Page Address\n");
    fprintf(fh, "//\t----------------  ------------\n");
  }
  for (; curr; curr = curr->next) {
    fprintf(fh, "//\t%-16s  %04X\n", curr->varname, curr->offset);
  }
  return;
}

/*********************************************************************
  Deallocate all storage associated with the list.
*********************************************************************/
var_node *varlist_cleanup(var_node **head)
{
  var_node *temp;
  for (temp = *head; *head; temp = *head) {
    *head = temp->next;
    free(temp);
  }
  *head = NULL;
  return NULL;
}
