/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman
  
  Convert reads a file containing ASCII strings of
  binary/hex numbers and outputs the string in true
  binary form.

  Return Values:
    0 - Success
    1 - Invalid command line
    2 - Unable to open input file
    3 - Unable to open output file
    4 - File parse error
*/

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define COMMENT          ';'
#define MAX_LINE_LENGTH 1000
#define SUCCESS            0
#define INVALID_CMD_LINE   1
#define BAD_INFILE         2
#define BAD_OUTFILE        3
#define PARSE_ERROR        4

/*Prototypes*/
void PrintUsage(void);
int ParseCmdLine(int argc, char *argv[],
                 int *base, char **infile, char **outfile);
int ProcessFile(FILE *fpin, FILE *fpout, int base);
int isValidChar(int base, char c);

int main(int argc, char *argv[])
{
  int base;
  char *infile, *outfile;
  FILE *fpin, *fpout;

  /*Read the command line*/
  if(!ParseCmdLine(argc, argv, &base, &infile, &outfile))
    {
    PrintUsage();
    return(INVALID_CMD_LINE);
    }

  /*Open input file*/
  if((fpin = fopen(infile, "r")) == NULL)
    {
    fprintf(stderr, "Unable to open %s\n", infile);
    return(BAD_INFILE);
    }

  /*Open output file*/
  if((fpout = fopen(outfile, "wb")) == NULL)
    {
    fprintf(stderr, "Unable to open %s\n", outfile);
    fclose(fpin);
    return(BAD_OUTFILE);
    }

  if(!ProcessFile(fpin, fpout, base))
    return(PARSE_ERROR);

  fclose(fpin);
  fclose(fpout);

  printf("Convert completed successfully\n");
  return(SUCCESS);
}

/*
  Parses the command line.  Returns 0 on error,
  otherwise returns non-zero
*/
int ParseCmdLine(int argc, char *argv[],
                 int *base, char **infile, char **outfile)
{
  int index;

  *base = 0;
  *infile = *outfile = NULL;

  if(argc <= 1)
    return(0);

  /*Parse the base*/
  if(argv[1][0] == '-' &&
     argv[1][1] == 'b')
    {
    sscanf(argv[1]+2, "%d", base);
    if(*base != 2 && *base != 16)
      return(0);
    index = 2;
    }
  else
    {
    *base = 2;
    index = 1;
    }
  
  /*Parse the files*/
  if(argc != index + 2)
    return(0);
  *infile = argv[index];
  *outfile = argv[index+1];

  return(1);
}

/*
  Prints the command line usage
*/
void PrintUsage(void)
{
  fprintf(stderr, "Usage: convert [-bBase] inputFile outputFile\n");
  fprintf(stderr, "       Base can be 2 or 16 for binary or hexadecimal\n");
  fprintf(stderr, "       inputFile is the file containing the ASCII strings\n");
  fprintf(stderr, "       outputFile is the object file to write\n");
}

/*
  ProcessFile reads each line of the input file,
  performs the conversion, and write the output.
  If a parse error occurs, an appropriate message
  is written to stderr and the function returns
  0, otherwise the return value is 1.
*/
int ProcessFile(FILE *fpin, FILE *fpout, int base)
{
  char buffer[MAX_LINE_LENGTH+1];  /*Line*/
  char reduced[MAX_LINE_LENGTH+1]; /*Parsed line*/
  int binary;
  char outbuffer[2];
  int line = 1;
  int i, len, offset;

  do
    {
    fgets(buffer, MAX_LINE_LENGTH+1, fpin);
    binary = 0;
    
    /*Remove all whitespace*/
    len = strlen(buffer);
    for(i=offset=0;i<len;i++)
      if(!isspace(buffer[i]))
        reduced[offset++] = (char)toupper(buffer[i]);
    reduced[offset] = '\0';

    /*Remove comments*/
    len = strlen(reduced);
    for(i=0;i<len;i++)
      if(reduced[i] == COMMENT)
        {
        reduced[i] = '\0';
        break;
        }
     
    /*Generate binary*/
    len = strlen(reduced);
    if(len)
      {
      /*Check for valid characters*/
      for(i=0;i<len;i++)
        if(!isValidChar(base,reduced[i]))
          {
          fprintf(stderr, "Unexpected character %c on line %d\n:%s\n",
                  reduced[i], line, buffer);
          return(0);
          }
      
      /*Check for correct number of characters*/
      if(len != ((base==2)?16:4))
        {
        fprintf(stderr, "Expected %d characters on line %d:\n%s\n",
                (base==2)?16:4,line, buffer);
        return(0);
        }

      if(base==2)
        for(i=0;i<len;i++)
          {
          binary <<= 1;
          binary += reduced[i] - '0';
          }
      else /*base 16*/
        for(i=0;i<len;i++)
          {
          binary <<= 4;
          if(isdigit(reduced[i]))
            binary += reduced[i] - '0';
          else
            binary += reduced[i] - 'A' + 10;
          }
      outbuffer[0] = (char)((binary & 0x0FF00)>>8);
      outbuffer[1] = (char)(binary & 0x00FF);
      fwrite(outbuffer, 1, 2, fpout); 
      }
    
    line++;
    } while(!feof(fpin));

  return(1);
}

int isValidChar(int base, char c)
{
  if(base == 2 && 
     (c == '0' || c == '1'))
      return(1);
  
  if(base == 16 && 
     (isdigit(c) || (c >= 'A' && c <= 'F')))
    return(1);
  
  return(0);
}