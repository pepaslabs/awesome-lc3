/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman

  This file implements the hardware of the LC2.
  It loads programs, executes them, and allows
  queries and direct modification of any register
  or memory address in the system.
*/

#include "lc2.h"
#include "lc2err.h"
#include "engine.h"
#include "bpman.h"
#include <stdio.h> //Using C I/O rather than c++

//Default Constructor initializes member variables
engine::engine(void)
{
  memory = registers = NULL;
}

//Destructor frees all memory associated with the engine
engine::~engine(void)
{
  delete [] memory;
  delete [] registers;
}

//Initialization must be called before using any
//other functions.  It allocates memory for simulated
//storage.
//Return Values
//  S_SUCCESS
//  E_INSUFFICIENT_MEMORY
RESULT engine::Init(void)
{
  RESULT r;

  if(memory)
    delete [] memory;
  if(registers)
    delete [] registers;

  if((memory = new BITS[MEMORY_SIZE]) == NULL)
    return(E_INSUFFICIENT_MEMORY);

  if((registers = new BITS[NUM_REGISTERS]) == NULL)
    return(E_INSUFFICIENT_MEMORY);

  SetValue(CRTSR_ADDRESS, NO_CHAR_TO_DISPLAY);
  SetValue(KBSR_ADDRESS, NO_KEYBOARD_PRESSED);

  if((r = console.Init()) != S_SUCCESS)
    return(r);

  //Set initial values
  StartUp();

  return(S_SUCCESS);
}

//StartUp sets the values of critical registers and locations
//Return Values
// S_SUCCESS
// E_UNINITALIZED_OBJECT
RESULT engine::StartUp(void)
{
  int i;

  if(!memory || !registers)
    return(E_UNINITIALIZED_OBJECT);

  //Zero everything out
  for(i=0;i<MEMORY_SIZE;i++)
    memory[i] = 0;
  for(i=0;i<NUM_REGISTERS;i++)
    registers[i] = 0;

  //Set critical locations
  SetValue(CC, ZCC);
  SetValue(PC, DEFAULT_START_LOC);
  SetValue(MCR_ADDRESS, NO_CLOCK);
  SetValue(CRTSR_ADDRESS, NO_CHAR_TO_DISPLAY);
  SetValue(KBSR_ADDRESS, NO_KEYBOARD_PRESSED);

  //Clear the console
  console.Clear();

  return(S_SUCCESS);
}


//GetValue returns the value at a given storage location.
//Return Values
//  S_SUCCESS
//  E_INVALID_ARG
//  E_UNITIALIZED_OBJECT
RESULT engine::GetValue(const STORAGE location, BITS *value, int update)
{
  if(!memory || !registers)
    return(E_UNINITIALIZED_OBJECT);

  if(!VALIDATE_LOCATION(location) || !value)
    return(E_INVALID_ARG);

  //Looking in Memory
  if(location >= 0 && location < MEMORY_SIZE)
    {
    *value = memory[location];
    /*OpSys assumes hardware resets status flag when accessed.*/
    if(location == KBDR_ADDRESS && update)
      SetValue(KBSR_ADDRESS, NO_KEYBOARD_PRESSED);
    }
  else  //Looking in registers
    *value = registers[RegisterConstantToIndex(location)];

  return(S_SUCCESS);
}

//SetValue allows asynchronous (from lc2 perspective) setting
//of any memory location or register.
//Return Values
//  S_SUCCESS
//  E_INVALID_ARG
//  E_UNINITIALIZED_OBJECT
RESULT engine::SetValue(const STORAGE location, BITS value, int update)
{
  if(!memory || !registers)
    return(E_UNINITIALIZED_OBJECT);

  if(!VALIDATE_LOCATION(location))
    return(E_INVALID_ARG);

  //Looking in Memory
  if(location >= 0 && location < MEMORY_SIZE)
    {
    memory[location] = value;
    /*OpSys assumes hardware resets status flag when accessed.*/
    if(location == CRTDR_ADDRESS && update)
      SetValue(CRTSR_ADDRESS, CHAR_TO_DISPLAY);
    }
  else  //Looking in registers
    registers[RegisterConstantToIndex(location)] = value;

  return(S_SUCCESS);
}

//LoadProgram will read a binary file into LC2 memory
//Return Values
//  S_SUCCESS
//  E_FILE_NOT_FOUND
//  E_FILE_IO
//  E_MEMORY_OVERRUN
//  E_UNINITIALIZED_OBJECT
RESULT engine::LoadProgram(const char *fname)
{
  unsigned char read1, read2;
  STORAGE address;
  BITS data;
  FILE *fp;

  if(!memory || !registers)
    return(E_UNINITIALIZED_OBJECT);

  fp = fopen(fname, "rb");
  if(!fp)
    return(E_FILE_NOT_FOUND);

  //Get Address
  if(fread(&read1, sizeof(char), 1, fp) &&
     fread(&read2, sizeof(char), 1, fp))
    address = (read1 << 8) + read2;
  else
    {
    fclose(fp);
    return(E_FILE_IO);
    }

  //Set PC
  SetValue(PC, (BITS)address);

  //Start reading data
  while(fread(&read1, sizeof(char), 1, fp) &&
        fread(&read2, sizeof(char), 1, fp))
    {
    data = (BITS)((read1 << 8) + read2);
    if(SetValue(address, data) == E_INVALID_ARG)
      {
      fclose(fp);
      return(E_MEMORY_OVERRUN);
      }
    address++;
    }

  if(!feof(fp))    //Something failed
    {
    fclose(fp);
    return(E_FILE_IO);
    }

  fclose(fp);
  return(S_SUCCESS);
}

//Execute will execute a specified number of instructions.
//If no value is given, the machine will execute until a
//hold condition is reached.
//Return Values
//  S_SUCCESS
//  S_HOLD (hit a breakpoint, halted, or clock stopped)
//  E_INVALID_INSTRUCTION (currently disabled)
//  E_UNINITIALIZED_OBJECT
RESULT engine::Execute(const unsigned int cycles)
{
  unsigned int i;
  BITS instruction;

  if(!memory || !registers)
    return(E_UNINITIALIZED_OBJECT);

  //Enable the clock
  SetValue(MCR_ADDRESS, CLOCK_ENABLE);

  for(i=0;!cycles || i<cycles;i++)
    {
    //Verify we still have a clock
    if(!ClockEnabled())
      return(S_HOLD_NOCLOCK);

    //Fetch Instruction
    instruction = registers[RegisterConstantToIndex(IR)] =
                       memory[registers[RegisterConstantToIndex(PC)]++];

#ifndef OLD_INSTRUCTION_SET
    //Verify Integrity of Instruction
    if(!IsValidInstruction(instruction))
      return(E_INVALID_INSTRUCTION);
#endif

    Execute_Instruction(instruction);

    //Stop execution on breakpoint or loss of clock
    if(bpm.OnActive(this, NULL, NULL))
      return(S_HOLD_BP);
    if(!ClockEnabled())
      return(S_HOLD_NOCLOCK);
    }

  return(S_SUCCESS);
}

//KeyboardUpdate will update the keyboard status and data registers
//with a key pressed on the keyboard.  If the keyboard is disabled by
//the status register, this function has no effect.  The new character
//is lost.
//Return Values:
//  S_SUCCESS
//  E_UNINITIALIZED_OBJECT
RESULT engine::KeyboardUpdate(const char value)
{
  BITS kbsr;

  if(!memory || !registers)
    return(E_UNINITIALIZED_OBJECT);

  GetValue(KBSR_ADDRESS, &kbsr);
  if((kbsr != KEYBOARD_PRESSED))
    {
    SetValue(KBDR_ADDRESS, value);
    SetValue(KBSR_ADDRESS, KEYBOARD_PRESSED);
    }

  return(S_SUCCESS);
}

//VideoUpdate will poll the Video Status Register for a character.
//If a new character is available, it is displayed to the simulated
//console.  Only one check is made to the status register.  This
//function does not wait for a character.
//Return Values
//  S_SUCCESS
//  S_NO_UPDATE
//  E_UNINITIALIZED_OBJECT
RESULT engine::VideoUpdate(void)
{
  BITS crtsr, data;

  if(!memory || !registers)
    return(E_UNINITIALIZED_OBJECT);

  GetValue(CRTSR_ADDRESS, &crtsr);
  if(crtsr == CHAR_TO_DISPLAY)
    {
    GetValue(CRTDR_ADDRESS, &data);
    console.Add((char)(data & 0x00FF));
    SetValue(CRTSR_ADDRESS, NO_CHAR_TO_DISPLAY);
    return(S_SUCCESS);
    }
  else
    return(S_NO_UPDATE);
}

//SetBreakPoint will set a breakpoint in execution
//Return Values
//  S_SUCCESS
//  E_INVALID_ARG
//  E_INSUFFICIENT_MEMORY
//  E_UNINITIALIZED_OBJECT
RESULT engine::SetBreakPoint(const STORAGE location, const BITS value)
{
  if(memory && registers)
    return(bpm.Add(location, value));
  else
    return(E_UNINITIALIZED_OBJECT);
}

//ListBreakPoints will list the current active breakpoints.
//The arrays must contain sufficient space to hold all
//the breakpoints.  If either parameter is NULL, its values
//are not written.
void engine::ListBreakPoints(STORAGE *locations, BITS *values) const
{
  bpm.List(locations, values);
}

//ActiveBreakPoint will return 1 if there is an active breakpoint,
//otherwise 0.  The parameters will contain the values for the
//breakpoint.  Only 1 is returned if more than 1 is active.
int engine::ActiveBreakPoint(STORAGE *loc, BITS *val)
{
  int index;

  index = bpm.OnActive(this, loc, val);
  if(index == -1)
    return(0);
  else
    return(1);
}

//NumBreakPoints will return the number of active breakpoints.
//This function is intended to be used for memory allocation
//for a ListBreakPoints call.
int engine::NumBreakPoints(void) const
{
  return(bpm.Number());
}

//ClearBreakPoint will remove a specific breakpoint
//Return Values
//  S_SUCCESS
//  E_INVALID_ARG
//  E_ENTRY_NOT_FOUND
//  E_UNINITIALIZED_OBJECT
RESULT engine::ClearBreakPoint(const STORAGE location, const BITS value)
{
  if(memory && registers)
    return(bpm.Remove(location, value));
  else
    return(E_UNINITIALIZED_OBJECT);
}

//ConsoleLine will copy a line from the console to a given string.
//The string must contain sufficient space to hold the characters.
//Return Values:
//  S_SUCCESS
//  E_INVALID_ARG
//  E_UNINITIALIZED_OBJECT
RESULT engine::ConsoleLine(const unsigned int index, char *line) const
{
  if(memory && registers)
    return(console.Line(index, line));
  else
    return(E_UNINITIALIZED_OBJECT);
}

//GetCursorPos will return the position of the cursor on the screen.
//The value returned indicates the position of the next character to
//be typed.
//Return Values:
//  S_SUCCESS
//  E_UNINITIALIZED_OBJECT
RESULT engine::GetCursorPos(unsigned int *x, unsigned int *y) const
{
  if(memory && registers)
    return(console.GetCursorPos(x, y));
  else
    return(E_UNINITIALIZED_OBJECT);
}

//ClearConsole will clear all characters on the output screen and
//move the cursor to the upper left corner.
//Return Values:
//  S_SUCCESS
//  E_UNINITIALIZED_OBJECT
RESULT engine::ClearConsole(void)
{
  if(memory && registers)
    return(console.Clear());
  else
    return(E_UNINITIALIZED_OBJECT);
}

//ClearAllBreakPoints will remove all active breakpoints.
//Return Values:
//  S_SUCCESS
//  E_UNINITIALIZED_OBJECT
RESULT engine::ClearAllBreakPoints(void)
{
  if(memory && registers)
    {
    bpm.Clear();
    return(S_SUCCESS);
    }
  else
    return(E_UNINITIALIZED_OBJECT);
}

//RegisterConstantToIndex converts the global registers constants
//to indecies into the register array maintained in the engine.
unsigned int engine::RegisterConstantToIndex(const STORAGE constant) const
{
  switch(constant)
    {
    case R0:
      return(0);
    case R1:
      return(1);
    case R2:
      return(2);
    case R3:
      return(3);
    case R4:
      return(4);
    case R5:
      return(5);
    case R6:
      return(6);
    case R7:
      return(7);
    case PC:
      return(8);
    case IR:
      return(9);
    case CC:
      return(10);
    default: //Should never occur
      return(0);
    }
}

//RegisterNumberToIndex converts the number of a general
//purpose register to its index as stored in the engine.
STORAGE engine::RegisterNumberToConstant(unsigned int num) const
{
  switch(num)
    {
    case 0:
      return(R0);
    case 1:
      return(R1);
    case 2:
      return(R2);
    case 3:
      return(R3);
    case 4:
      return(R4);
    case 5:
      return(R5);
    case 6:
      return(R6);
    case 7:
      return(R7);
    default:  //Should never happen
      return(0);
    }
}

//SetCC will set the condition codes based on the data given.
void engine::SetCC(const BITS data)
{
  BITS newCC;

  if(!data)
    newCC = ZCC;
  else if(data & MSB_MASK)
    newCC = NCC;
  else
    newCC = PCC;

  SetValue(CC, newCC);
}

//IsValidInstruction will return 1 is the given instruction conforms to
//an LC2 instruction, otherwise 0.
int engine::IsValidInstruction(BITS instr) const
{
#ifndef OLD_INSTRUCTION_SET
  if(OPCODE(instr) == RTI)
    return(0);
#endif
  return(1);
}

//Execute_Instruction will execute a single instruction.  It does not
//alter the PC, IR or other instruction cycle operations unless that
//operation is specified by the instruction (i.e. branch).
void engine::Execute_Instruction(BITS instr)
{
  BITS pc, op1, op2, result;

  switch(OPCODE(instr))
    {
    case ADD:
      GetValue(RegisterNumberToConstant(SR1(instr)), &op1);
      if(IMMVAL(instr))
        result = (BITS)(op1 + IMM5(instr));
      else
        {
        GetValue(RegisterNumberToConstant(SR2(instr)), &op2);
        result = (BITS)(op1 + op2);
        }
      SetCC(result);
      SetValue(RegisterNumberToConstant(DR(instr)), result);
      break;

    case AND:
      GetValue(RegisterNumberToConstant(SR1(instr)), &op1);
      if(IMMVAL(instr))
        result = (BITS)(op1 & IMM5(instr));
      else
        {
        GetValue(RegisterNumberToConstant(SR2(instr)), &op2);
        result = (BITS)(op1 & op2);
        }
      SetCC(result);
      SetValue(RegisterNumberToConstant(DR(instr)), result);
      break;

    case BR:
      GetValue(CC, &op1);
      if(CONDCODES(instr) & op1)    //take branch
        {
        GetValue(PC, &pc);
        SetValue(PC, (BITS)(PC6(pc) + PGOFFSET9(instr)));
        }
      break;

    case JSR:
      GetValue(PC, &pc);
      if(LINK(instr))
        SetValue(R7, pc);
      SetValue(PC, (BITS)(PC6(pc) + PGOFFSET9(instr)));
      break;

    case JSRR:
      if(LINK(instr))
        {
        GetValue(PC, &pc);
        SetValue(R7, pc);
        }
      GetValue(RegisterNumberToConstant(BASER(instr)), &op1);
      SetValue(PC, (BITS)(op1 + INDEX6(instr)));
      break;

    case LD:
      GetValue(PC, &pc);
      op1 = (BITS)(PC6(pc) + PGOFFSET9(instr)); //address
      GetValue(op1, &op2), 1;
      SetCC(op2);
      SetValue(RegisterNumberToConstant(DR(instr)), op2);
      break;

    case LDI:
      GetValue(PC, &pc);
      op1 = (BITS)(PC6(pc) + PGOFFSET9(instr)); //address
      GetValue(op1, &op2);
      GetValue(op2, &result, 1);
      SetCC(result);
      SetValue(RegisterNumberToConstant(DR(instr)), result);
      break;

    case LDR:
      GetValue(RegisterNumberToConstant(BASER(instr)), &op1);
      op2 = (BITS)(op1 + INDEX6(instr));
      GetValue(op2, &result, 1);
      SetCC(result);
      SetValue(RegisterNumberToConstant(DR(instr)), result);
      break;

    case LEA:
      GetValue(PC, &pc);
      op1 = (BITS)(PC6(pc) + PGOFFSET9(instr));
      SetCC(op1);
      SetValue(RegisterNumberToConstant(DR(instr)), op1);
      break;

#ifdef OLD_INSTRUCTION_SET
    case NOP:
      break;
#else
    case RTI:  //RTI not currently implemented
      break;
#endif

    case NOT:
      GetValue(RegisterNumberToConstant(SR1(instr)), &op1);
      op2 = (BITS)(~op1);
      SetCC(op2);
      SetValue(RegisterNumberToConstant(DR(instr)), op2);
      break;

    case RET:
      GetValue(R7, &op1);
      SetValue(PC, op1);
      break;
      
    case ST:
      GetValue(PC, &pc);
      op1 = (BITS)(PC6(pc) + PGOFFSET9(instr)); //address
      GetValue(RegisterNumberToConstant(SR(instr)), &op2);
      SetValue(op1, op2, 1);
      break;

    case STI:
      GetValue(PC, &pc);
      GetValue(RegisterNumberToConstant(SR(instr)), &result);
      op1 = (BITS)(PC6(pc) + PGOFFSET9(instr)); //address
      GetValue(op1, &op2);
      SetValue(op2, result, 1);
      break;

    case STR:
      GetValue(RegisterNumberToConstant(BASER(instr)), &op1);
      op2 = (BITS)(op1 + INDEX6(instr));
      GetValue(RegisterNumberToConstant(SR(instr)), &result);
      SetValue(op2, result, 1);
      break;

    case TRAP:
      GetValue(PC, &pc);
      SetValue(R7, pc);
      GetValue(TRAPVECT8(instr), &op1);
      SetValue(PC, op1);
      break;
    }
}

//ClockEnabled will return one if the clock is currently active,
//otherwise 0.  This is determined by looking at the high bit in
//the MCR.
int engine::ClockEnabled(void) const
{
  //Doesn't use getval because getval is non-const
  if(memory[MCR_ADDRESS] & MSB_MASK)
    return(1);
  else
    return(0);
}
