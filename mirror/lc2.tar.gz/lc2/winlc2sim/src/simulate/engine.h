/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman

  This file declares the LC2 engine.  It must be
  included in any file that requires execution of
  an LC2 program.
*/

#ifndef _engine_h_
#define _engine_h_

#include "lc2.h"
#include "lc2err.h"
#include "bpman.h"
#include "console.h"

class engine
{
  public:
    //Default Constructor initializes member variables
    engine(void);

    //Destructor frees all memory associated with the engine
    ~engine(void);

    //Initialization must be called before using any
    //other functions.  It allocates memory for simulated
    //storage.
    //Return Values
    //  S_OK
    //  E_INSUFFICIENT_MEMORY
    RESULT Init(void);

    //StartUp sets the values of critical registers and locations
    //Return Values
    // S_OK
    // E_UNINITALIZED_OBJECT
    RESULT StartUp(void);

    //GetValue returns the value at a given storage location.
    //Return Values
    //  S_OK
    //  E_INVALID_ARG
    //  E_UNINITIALIZED_OBJECT
    RESULT GetValue(const STORAGE location, BITS *value, int update=0);

    //SetValue allows asynchronous (from lc2 perspective) setting
    //of any memory location or register.
    //Return Values
    //  S_OK
    //  E_INVALID_ARG
    //  E_UNINITIALIZED_OBJECT
    RESULT SetValue(const STORAGE location, BITS value, int update=0);

    //LoadProgram will read a binary file into LC2 memory
    //Return Values
    //  S_OK
    //  E_FILE_NOT_FOUND
    //  E_MEMORY_OVERRUN
    //  E_UNINITIALIZED_OBJECT
    //  E_FILE_IO
    RESULT LoadProgram(const char *fname);

    //Execute will execute a specified number of instructions.
    //If no value is given, the machine will execute until a
    //hold condition is reached.
    //Return Values
    //  S_OK
    //  S_HOLD (hit a breakpoint, halted, or clock stopped)
    //  E_INVALID_INSTRUCTION
    //  E_UNINITIALIZED_OBJECT
    RESULT Execute(const unsigned int cycles = 0);

    //KeyboardUpdate will update the keyboard status and data registers
    //with a key pressed on the keyboard.  If the keyboard is disabled by
    //the status register, this function has no effect.  The new character
    //is lost.
    //Return Values:
    //  S_OK
    //  E_UNINITIALIZED_OBJECT
    RESULT KeyboardUpdate(const char value);

    //VideoUpdate will poll the Video Status Register for a character.
    //If a new character is available, it is displayed to the simulated
    //console.  Only one check is made to the status register.  This
    //function does not wait for a character.
    //Return Values
    //  S_SUCCESS
    //  S_NO_UPDATE
    //  E_UNINITIALIZED_OBJECT
    RESULT VideoUpdate(void);

    /*Exposing BPManager functions*/

    //SetBreakPoint will set a breakpoint in execution
    //Return Values
    //  S_OK
    //  E_INVALID_ARG
    //  E_INSUFFICIENT_MEMORY
    //  E_UNINITIALIZED_OBJECT
    RESULT SetBreakPoint(const STORAGE location, const BITS value);

    //ListBreakPoints will list the current active breakpoints.
    //The arrays must contain sufficient space to hold all
    //the breakpoints.  If either parameter is NULL, its values
    //are not written.
    void ListBreakPoints(STORAGE *locations, BITS *values) const;

    //ActiveBreakPoint will return 1 if there is an active breakpoint,
    //otherwise 0.  The parameters will contain the values for the
    //breakpoint.  Only 1 is returned if more than 1 is active.
    int ActiveBreakPoint(STORAGE *loc, BITS *val);

    //NumBreakPoints will return the number of active breakpoints.
    //This function is intended to be used for memory allocation
    //for a ListBreakPoints call.
    int NumBreakPoints(void) const; 

    //ClearBreakPoint will remove a specific breakpoint
    //Return Values
    //  S_OK
    //  E_INVALID_ARG
    //  E_ENTRY_NOT_FOUND
    //  E_UNINITIALIZED_OBJECT
    RESULT ClearBreakPoint(const STORAGE location, const BITS value);

    //ClearAllBreakPoints will remove all active breakpoints.
    //Return Values:
    //  S_OK
    //  E_UNINITIALIZED_OBJECT
    RESULT ClearAllBreakPoints(void);

    /*Exposing Console functions*/

    //ConsoleLine will copy a line from the console to a given string.
    //The string must contain sufficient space to hold the characters.
    //Return Values:
    //  S_OK
    //  E_INVALID_ARG
    //  E_UNINITIALIZED_OBJECT
    RESULT ConsoleLine(const unsigned int index, char *line) const;

    //GetCursorPos will return the position of the cursor on the screen.
    //The value returned indicates the position of the next character to
    //be typed.
    //Return Values:
    //  S_OK
    //  E_UNINITIALIZED_OBJECT
    RESULT GetCursorPos(unsigned int *x, unsigned int *y) const;

    //ClearConsole will clear all characters on the output screen and
    //move the cursor to the upper left corner.
    //Return Values:
    //  S_SUCCESS
    //  E_UNINITIALIZED_OBJECT
    RESULT ClearConsole(void);

  protected:
    //RegisterConstantToIndex converts the global registers constants
    //to indecies into the register array maintained in the engine.
    unsigned int RegisterConstantToIndex(const STORAGE constant) const;

    //RegisterNumberToIndex converts the number of a general
    //purpose register to its index as stored in the engine.
    STORAGE engine::RegisterNumberToConstant(unsigned int num) const;

    //SetCC will set the condition codes based on the data given.
    void SetCC(const BITS data);

    //IsValidInstruction will return 1 is the given instruction conforms to
    //an LC2 instruction, otherwise 0.
    int IsValidInstruction(BITS instr) const;

    //Execute_Instruction will execute a single instruction.  It does not
    //alter the PC, IR or other instruction cycle operations unless that
    //operation is specified by the instruction (i.e. branch).
    void Execute_Instruction(BITS instr);

  private:
    //All storage in the LC2 is represented in the following
    //two dyanmic arrays.
    BITS *memory;
    BITS *registers;

    //The breakpoint manager
    BPManager bpm;

    //The memory console.  This is only an interface to the actual
    //display device.  It does not perform output.
    Console console;

    //ClockEnabled will return one if the clock is currently active,
    //otherwise 0.  This is determined by looking at the high bit in
    //the MCR.
    int ClockEnabled(void) const;

    //The copy constructor and operator= are disabled.  The engine
    //should not be copied: it is too large.  No definition is provided
    //for these functions.
    engine(const &engine);
    engine operator=(const &engine);
};

#endif