/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman

  This file implements the breakpoint manager.
  It maintains the list of breakpoints and
  can determine when one has been reached.
*/

#include "bpman.h"
#include "engine.h"

//Default Constructor.  The BreakPoint manager must
//be initialized to an engine.
BPManager::BPManager(void)
{
  breakpoints = NULL;
  cntBP = allocatedBP = 0;
}

//Destructor frees memory associated with the manager
BPManager::~BPManager(void)
{
  delete [] breakpoints;
}

//Add will add a breakpoint to the LC2
//Return Values
//  S_SUCCESS
//  E_INSUFFICIENT_MEMORY
//  E_INVALID_ARG
RESULT BPManager::Add(const STORAGE location, const BITS value)
{
  unsigned int index=0, i;

  //Verify that the storage location exists
  if(!VALIDATE_LOCATION(location))
    return(E_INVALID_ARG);

  //Check to see if the breakpoint already exists.
  for(i=0;i<allocatedBP;i++)
    if(breakpoints[i].valid &&
       breakpoints[i].location == location &&
       breakpoints[i].value == value)
      return(S_SUCCESS);

  //Find a place to insert the entry.  Make one if necessary.
  if(cntBP == allocatedBP)
    {
    if(Grow() == E_INSUFFICIENT_MEMORY)
      return(E_INSUFFICIENT_MEMORY);
    index = cntBP;
    }
  else
    for(i=0;i<allocatedBP;i++)
      if(!breakpoints[i].valid)
        {
        index = i;
        break;
        }

  //Insert it
  breakpoints[index].location = location;
  breakpoints[index].value = value;
  breakpoints[index].valid = 1;
  cntBP++;

  return(S_SUCCESS);
}

//Remove will remove a specific breakpoint
//Return Values
//  S_SUCCESS
//  E_ENTRY_NOT_FOUND
//  E_INVALID_ARG
RESULT BPManager::Remove(const STORAGE location, const BITS value)
{
  unsigned int i;

  //Verify that the storage location exists
  if(!VALIDATE_LOCATION(location))
    return(E_INVALID_ARG);

  for(i=0;i<allocatedBP;i++)
    if(breakpoints[i].valid &&
       breakpoints[i].location == location &&
       breakpoints[i].value == value)
      {
      breakpoints[i].valid = 0;
      cntBP--;
      return(S_SUCCESS);
      }

  return(E_ENTRY_NOT_FOUND);
}

//Clear will remove all breakpoints
void BPManager::Clear(void)
{
  unsigned int i;

  for(i=0;i<allocatedBP;i++)
    breakpoints[i].valid = 0;
  cntBP = 0;
}

//List will output all the breakpoints.  The pointers passed in
//must point to sufficient memory to hold all the breakpoint
//values.  If a parameter is NULL, that value is skipped.
void BPManager::List(STORAGE *locations, BITS *values) const
{
  unsigned int i;
  unsigned int written = 0;

  for(i=0;i<allocatedBP;i++)
    if(breakpoints[i].valid)
      {
      if(locations)
        locations[written] = breakpoints[i].location;
      if(values)
        values[written] = breakpoints[i].value;
      written++;
      }
}

//Number will return the number of active breakpoints.
int BPManager::Number(void) const
{
  return(cntBP);
}

//OnActive will return 1 if the engine is on an active breakpoint,
//otherwise 0.  The breakpoint values are stored in loc and val
//if they are non NULL.
int BPManager::OnActive(engine *lc2, STORAGE *loc, BITS *val)
{
  unsigned int i;
  BITS value;

  for(i=0;i<allocatedBP;i++)
    if(breakpoints[i].valid)
      {
      lc2->GetValue(breakpoints[i].location, &value);
      if(value == breakpoints[i].value)
        {
        if(loc)
          *loc = breakpoints[i].location;
        if(val)
          *val = breakpoints[i].value;
        return(1);
        }
      }
  return(0);
}

//Grow will double the size of the breakpoint structure.
//Return Values:
//  S_SUCCESS
//  E_INSUFFICIENT_MEMORY
RESULT BPManager::Grow(void)
{
  BPnode_t *newarr;
  unsigned int size, i;

  //Determine size to alloc
  if(!allocatedBP)
    size = INITIAL_ALLOC;
  else
    size = allocatedBP * 2;

  //Perform the allocation
  if((newarr = new BPnode_t[size]) == NULL)
    return(E_INSUFFICIENT_MEMORY);

  //Copy old stuff if necessary
  for(i=0;i<allocatedBP;i++)
    newarr[i] = breakpoints[i];

  //Initialize new stuff
  for(;i<size;i++)
    newarr[i].valid = 0;

  delete [] breakpoints;
  breakpoints = newarr;
  allocatedBP = size;

  return(S_SUCCESS);
}
