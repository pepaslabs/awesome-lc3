/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman

  Declarations required for GUI aware files.
*/

#ifndef _main_h_
#define _main_h_

#include "lc2.h"
#include "engine.h"
#include "symtable.h"

#define SIM_VER "1.00"
#define SIM_DATE "January 8, 1999"
#define COPYRIGHT_YEAR 1999

#define ENGINE_IDLE 0L
#define ENGINE_RUNNING 1L
#define ENGINE_TRAP 2L
#define ENGINE_GOIDLE 3L
#define ENGINE_OFF 4L
#define ENGINE_EXIT 5L
#define EXECUTE_CONTINUOUS -1L

#define WM_MEMRANGE  (WM_USER)
  //WPARAM: Start address
  //LPARAM: 0, not used

#define WM_MEMREFRESH (WM_USER + 1)
  //WPARAM: address
  //HIWORD LPARAM: 0 - update startAddress if necessary
  //               1 - don't adjust display range
  //LOWORD LPARAM: 0 - update everything, 1 - wparam contains address

#define LC2_HOLD (WM_USER + 2)
  //WPARAM: 0 - breakpoint
  //        1 - loss of clock
  //        2 - Engine is suspending (instruction count to 0, user idled, etc)

#define CONSOLE_CARET_POSITION (WM_USER + 3)
  //WPARAM, LPARAM not used

extern engine lc2;
extern symtable symtble;
extern HWND hwndConsole;
extern HWND hwndSim;
extern HANDLE hEngineThread;
extern long gEngineStatus;
extern long gEngineInstructions;
extern long gExecuted;
extern BITS gLastUserPC;

extern HFONT ghFont;
extern int gfontWidth, gfontHeight;
extern int gfontPT;

void SetFont(int pointsize);
int LoadOS(HWND hwnd);

#endif