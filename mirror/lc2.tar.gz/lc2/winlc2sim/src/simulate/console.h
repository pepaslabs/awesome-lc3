/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman

  This file declares a simulated console.  It is designed to act as
  an interface between the engines output and a graphical display.
*/

#ifndef _console_h_
#define _console_h_

#include "lc2err.h"

class Console
{
  public:
    //Default Constructor initializes member variables.
    Console(void);

    //Destructor releases all memory associated with the console.
    ~Console(void);

    //Init will initialize the memory used in the console.
    //It must be called prior to any other function.
    //Return Values:
    //  S_SUCCESS
    //  E_INSUFFICIENT_MEMORY
    RESULT Init(void);

    //Add will add a character to the end of the display.
    //Return Values:
    //  S_SUCCESS
    //  E_UNINITIALIZED_OBJECT
    RESULT Add(const char ascii);

    //Line will copy a line from the console to a given string.
    //The string must contain sufficient space to hold the characters.
    //Return Values:
    //  S_SUCCESS
    //  E_INVALID_ARG
    //  E_UNINITIALIZED_OBJECT
    RESULT Line(const unsigned int index, char *line) const;

    //GetCursorPos will return the position of the cursor on the screen.
    //The value returned indicates the position of the next character to
    //be typed.
    //Return Values:
    //  S_SUCCESS
    //  E_UNINITIALIZED_OBJECT
    RESULT GetCursorPos(unsigned int *x, unsigned int *y) const;

    //Clear will clear the console and set the cursor to the upper left pos.
    //Return Values:
    //  S_SUCCESS
    //  E_UNITIALIZED_OBJECT
    RESULT Clear(void);

  protected:
    //MoveUp will move the entire console up one line.  This will destroy the
    //data currently on the top line of the screen.  The cursor is not moved.
    void MoveUp(void);

    //The copy constructor and operator= are disabled.  The console
    //should not be copied: it is too large.  No definition is provided
    //for these functions.
    Console(const &Console);
    Console operator=(const &Console);

  private:
    char **lines;
    unsigned int posx, posy;
};

#endif

