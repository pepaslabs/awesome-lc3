/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman

  This file declares the functions necessary to run the
  GUI console.  The console should not be created until
  the LC2 engine has been initialized.

*/

#ifndef _gui_cons_h_
#define _gui_cons_h_

#include <windows.h>

#define CONSOLE_NAME "LC2 Console"
#define CONSOLE_TITLE CONSOLE_NAME

#define CONSOLE_HEIGHT (gfontHeight * CONSOLE_HEIGHT_CHAR + 2 * GetSystemMetrics(SM_CYFIXEDFRAME) + GetSystemMetrics(SM_CYCAPTION))
#define CONSOLE_WIDTH (gfontWidth * CONSOLE_WIDTH_CHAR + 2 * GetSystemMetrics(SM_CXFIXEDFRAME))

extern CRITICAL_SECTION ConsoleUpdateCS;

LRESULT CALLBACK ConsoleProc(HWND hwnd,
                             UINT iMsg,
                             WPARAM wParam,
                             LPARAM lParam);

void CALLBACK GuiConsoleUpdate(HWND hwnd,
                               UINT iMsg,
                               UINT iTimerID,
                               DWORD dwTime);
#endif