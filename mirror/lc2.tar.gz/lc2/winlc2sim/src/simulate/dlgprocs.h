/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman

  This file declares the dialog procedures for all dialog boxes.
*/

#ifndef _dlgproc_h_
#define _dlgproc_h_

#include <windows.h>

BOOL CALLBACK AddBPDlgProc(HWND hwnd,
                           UINT iMsg,
                           WPARAM wParam,
                           LPARAM lParam);
BOOL CALLBACK RemoveBPDlgProc(HWND hwnd,
                              UINT iMsg,
                              WPARAM wParam,
                              LPARAM lParam);
BOOL CALLBACK SetValueDlgProc(HWND hwnd,
                              UINT iMsg,
                              WPARAM wParam,
                              LPARAM lParam);
BOOL CALLBACK FontSizeDlgProc(HWND hwnd,
                              UINT iMsg,
                              WPARAM wParam,
                              LPARAM lParam);
BOOL CALLBACK RunDlgProc(HWND hwnd,
                         UINT iMsg,
                         WPARAM wParam,
                         LPARAM lParam);
BOOL CALLBACK StepDlgProc(HWND hwnd,
                          UINT iMsg,
                          WPARAM wParam,
                          LPARAM lParam);
BOOL CALLBACK JumpDlgProc(HWND hwnd,
                          UINT iMsg,
                          WPARAM wParam,
                          LPARAM lParam);
BOOL CALLBACK InfiniteLoopDlgProc(HWND hwnd,
                                  UINT iMsg,
                                  WPARAM wParam,
                                  LPARAM lParam);
#endif