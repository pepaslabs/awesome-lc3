/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman

  This file contains the constants used in running
  the graphical simulator.
*/

#ifndef _simulate_h_
#define _simulate_h_

#include <windows.h>

#define SIM_NAME "LC2 Simulator"
#define SIM_TITLE SIM_NAME
#define MEM_NAME "Memory"
#define MEM_TITLE MEM_NAME

#define DEFAULT_MEMLINES 26
#define MEM_STRLEN 64

#define TBHEIGHT 30 //16 for height 7 for border on each side
#define REGISTER_DISPLAY_HEIGHT 4.75 * gfontHeight
#define SIM_WINDOW_WIDTH (MEM_STRLEN * gfontWidth + GetSystemMetrics(SM_CXVSCROLL) + 2 * GetSystemMetrics(SM_CXSIZEFRAME) + 2 * GetSystemMetrics(SM_CXBORDER) + gfontHeight)

/*Toolbar + register display + Sim window border + caption*/
#define MIN_SIM_WINDOW_HEIGHT (TBHEIGHT + REGISTER_DISPLAY_HEIGHT + 2*GetSystemMetrics(SM_CYSIZEFRAME) + GetSystemMetrics(SM_CYMENUSIZE) + GetSystemMetrics(SM_CYCAPTION)) //0 memory display lines

//8 customs image buttons
//+1 for LoadProgram (comes with comm.controls)
//+5 for separator
#define NUM_TB_BTNS (8 + 1 + 5)

LRESULT CALLBACK SimProc(HWND hwnd,
                         UINT iMsg,
                         WPARAM wParam,
                         LPARAM lParam);

void RegisterConstToStr(STORAGE loc, LPTSTR str);
int isValidLoc(LPTSTR str, STORAGE *pconst);
int isValidVal(LPTSTR str, BITS *val);
int ValidateValues(LPTSTR locstr, LPTSTR valstr, STORAGE *loc, BITS *val);

extern HWND hwndMemScroll, hwndMemBP, hwndLB[4], hwndTB;
extern HWND hRunDlg, hStepDlg;
extern char gFollowPC;
extern char gWarnLargeExecution;
extern char gStepOverTraps;

#endif
