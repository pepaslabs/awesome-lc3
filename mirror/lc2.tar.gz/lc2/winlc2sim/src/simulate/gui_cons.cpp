/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman
                                                
  This file contains the functions necessary to run the
  GUI console.  The message loop appears in the main file.
  The console should not be created until the LC2 engine
  has been initialized.

  The preprocessor definition REALISTIC_CONSOLE_REFRESH can
  be defined to allow a more realistic output algorithm.  This
  includes a timer that will periodically get character from the
  approrpiate LC2 memory locations and refresh the display.  Not
  defining it allows a faster refresh by checking for updates
  after each instruction.
*/

#include "gui_cons.h"
#include "create.h"
#include "lc2.h"
#include "main.h"

CRITICAL_SECTION ConsoleUpdateCS;

#ifdef REALISTIC_CONSOLE_REFRESH
#define TIMER_ID_GUI_CONSOLE_UPDATE 1
#define GUI_CONSOLE_UPDATE_INTERVAL 10 //time is milliseconds
#endif

//Windows Procedure for GUI console
LRESULT CALLBACK ConsoleProc(HWND hwnd,
                             UINT iMsg,
                             WPARAM wParam,
                             LPARAM lParam)
{
#ifdef REALISTIC_CONSOLE_REFRESH
  static UINT timer;
#endif

  switch(iMsg)
    {
    case WM_CREATE:
      //Set window size
      ResizeConsoleWindow(hwnd);

#ifdef REALISTIC_CONSOLE_REFRESH
      //Set the Display Timer
      SetTimer(hwnd,
               TIMER_ID_GUI_CONSOLE_UPDATE,
               GUI_CONSOLE_UPDATE_INTERVAL,
               (TIMERPROC)GuiConsoleUpdate);
#endif
      return(0);

    case WM_CHAR:
      {
        if((char)wParam == '\r')
          lc2.KeyboardUpdate('\n');
        else
          lc2.KeyboardUpdate((char)wParam);
        return(0);
      }

    case WM_PAINT:
      {
      HDC hDC, hDCMem;
      PAINTSTRUCT ps;
      unsigned int i, len;
      unsigned int starty, endy;
      RECT rect;
      char line[CONSOLE_WIDTH_CHAR + 1];
      HBITMAP hbmp, hBmpOld;

      hDC = BeginPaint(hwnd, &ps);

      //Create the MemDC
      hDCMem = CreateCompatibleDC(hDC);
      hbmp = CreateCompatibleBitmap(hDC,
                                    CONSOLE_WIDTH_CHAR * gfontWidth,
                                    CONSOLE_HEIGHT_CHAR * gfontHeight);
      hBmpOld = (HBITMAP)SelectObject(hDCMem, hbmp);
      SetTextColor(hDCMem, RGB(0,0,0));          //white
      SetBkColor(hDCMem, RGB(255,255,255));      //black

      //Erase the background
      SelectObject(hDCMem, GetStockObject(WHITE_PEN));
      SelectObject(hDCMem, GetStockObject(WHITE_BRUSH));
      Rectangle(hDCMem, 0, 0,
                CONSOLE_WIDTH_CHAR * gfontWidth,
                CONSOLE_HEIGHT_CHAR * gfontHeight);
      SelectObject(hDCMem, ghFont);

      //Perform display
      GetClipBox(hDC, &rect);
      starty = rect.top / gfontHeight;
      endy = rect.bottom / gfontHeight +
             ((rect.bottom % gfontHeight)?1:0);
      for(i=starty;i<=endy;i++)
        {
        lc2.ConsoleLine(i+1, line);
        len = strlen(line);
        if(len)
          TextOut(hDCMem, 0, i*gfontHeight, line, len);
        }


      BitBlt(hDC, 0, 0,
             CONSOLE_WIDTH_CHAR * gfontWidth,
             CONSOLE_HEIGHT_CHAR * gfontHeight,
             hDCMem, 0, 0, SRCCOPY);

      SelectObject(hDCMem, hBmpOld);
      DeleteObject(hbmp);
      DeleteDC(hDCMem);

      EndPaint(hwnd, &ps);
      return(0);
      }

    case WM_SETFOCUS:
      {
      unsigned int x, y;

      CreateCaret(hwnd, NULL,  gfontWidth, gfontHeight);
      lc2.GetCursorPos(&x, &y);
      SetCaretPos((x-1) * gfontWidth, (y-1) * gfontHeight);
      ShowCaret(hwnd);
      return(0);
      }

    case WM_KILLFOCUS:
      HideCaret(hwnd);
      DestroyCaret();
      return(0);

    case WM_CLOSE:
      {
      //Only close from simulator window
      return(0);
      }

    case WM_DESTROY:
      {
#ifdef REALISTIC_CONSOLE_REFRESH
      KillTimer(hwnd, timer);
#endif
      return(0);
      }

    default:
      return(DefWindowProc(hwnd, iMsg, wParam, lParam));
    }
}

//Updates the GUI console.  This function simulates the effect
//of a video card polling the video status register and updating
//the display.  
void CALLBACK GuiConsoleUpdate(HWND hwnd,
                               UINT iMsg,
                               UINT iTimerID,
                               DWORD dwTime)
{
  unsigned int x, y;
  RECT r;
  RESULT result;

  EnterCriticalSection(&ConsoleUpdateCS);
  result = lc2.VideoUpdate();

  //Redraw the needed portions of the display
  if(result == S_SUCCESS)
    {
    //Get the cursor position
    lc2.GetCursorPos(&x, &y);
    if(!SetCaretPos((x-1) * gfontWidth, (y-1) * gfontHeight))
      //This is a workaround because the engine thread can't
      //seem to set the caret position.
      PostMessage(hwndSim, CONSOLE_CARET_POSITION, 0, 0);

    //Easy cases.  If we are at the beginning of the
    //last row, we may have just scrolled up... so
    //redraw everything.  If at char 1, row 1, do nothing
    if(x == 1 && y == 1)
      return;
    else if(x == 1 && y == CONSOLE_HEIGHT_CHAR)
      {
      InvalidateRect(hwnd, NULL, FALSE);
      return;
      }

    //do the last char only
    if(x == 1) //last char was on prev row
      {
      r.left = 0;
      r.right = CONSOLE_WIDTH_CHAR * gfontWidth;
      r.top = gfontHeight * (y - 2);
      r.bottom = gfontHeight * (y - 1);
      }
    else
      {
      r.left = gfontWidth * (x - 2);
      r.right = gfontWidth * (x - 1);
      r.top = gfontHeight * (y - 1);
      r.bottom = gfontHeight * (y);
      }

    InvalidateRect(hwnd, &r, FALSE);
    }

  LeaveCriticalSection(&ConsoleUpdateCS);
}
