/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman

  This program will store the characters on a standard console.
  It does not actually perform output.  It acts only as a buffer.
  All necessary line scrolling and cursor movement is taken care of.
*/

#include "console.h"
#include "lc2.h"
#include <stddef.h>
#include <string.h>

//Default Constructor initializes member variables.
Console::Console(void)
{
  lines = NULL;
  posx = posy = 1;
}

//Destructor releases all memory associated with the console.
Console::~Console(void)
{
  unsigned int i;

  if(lines)
    for(i=0;i<CONSOLE_HEIGHT_CHAR;i++)
      delete [] lines[i];
  delete [] lines;
}

//Init will initialize the memory used in the console.
//It must be called prior to any other function.
//Return Values:
//  S_SUCCESS
//  E_INSUFFICIENT_MEMORY
RESULT Console::Init(void)
{
  unsigned int i, j;

  //Allocate pointers for the lines
  if((lines = new char *[CONSOLE_HEIGHT_CHAR]) == NULL)
    return(E_INSUFFICIENT_MEMORY);

  //Allocate each line
  for(i=0;i<CONSOLE_HEIGHT_CHAR;i++)
    if((lines[i] = new char[CONSOLE_WIDTH_CHAR+1]) == NULL)
      {
      //erase existing lines
      for(j=0;j<i;j++)
        delete [] lines[j];
      delete [] lines;
      lines = NULL;
      return(E_INSUFFICIENT_MEMORY);
      }

  Clear();
  return(S_SUCCESS);
}

//Add will add a character to the end of the display.
//It handles all line and cursor movement associated
//with the addition.  Tabs are expanded to the required
//number of spaces.
//Return Values:
//  S_SUCCESS
//  E_UNINITIALIZED_OBJECT
RESULT Console::Add(const char ascii)
{
  unsigned int num, i;

  if(!lines)
    return(E_UNINITIALIZED_OBJECT);

  if(ascii != '\n' && ascii != '\t' && ascii != '\r')
    {
    if(ascii != '\0')
      lines[posy-1][posx-1] = ascii;
    else
      lines[posy-1][posx-1] = ' ';
    posx++;
    }
  else if(ascii == '\t')
    {
    num = 5 - ((posx - 1) % 5);
    if(CONSOLE_WIDTH_CHAR - posx + 1 < num)
      num = CONSOLE_WIDTH_CHAR - posx + 1;
    for(i=0;i<num;i++)
      Add(' ');
    }

  lines[posy-1][posx-1] = '\0';

  //update cursor
  if(posx > CONSOLE_WIDTH_CHAR || ascii == '\n' || ascii == '\r')
    {
    posx = 1;
    posy++;
    if(posy > CONSOLE_HEIGHT_CHAR)
      {
      MoveUp();
      posy--;
      }
    }

  return(S_SUCCESS);
}

//Line will copy a line from the console to a given string.
//The string must contain sufficient space to hold the characters.
//Return Values:
//  S_SUCCESS
//  E_INVALID_ARG
//  E_UNINITIALIZED_OBJECT
RESULT Console::Line(const unsigned int index, char *line) const
{
  if(!lines)
    return(E_UNINITIALIZED_OBJECT);

  if(!line || index > CONSOLE_HEIGHT_CHAR)
    return(E_INVALID_ARG);

  strcpy(line, lines[index - 1]);
  return(S_SUCCESS);
}

//GetCursorPos will return the position of the cursor on the screen.
//The value returned indicates the position of the next character to
//be typed.
//Return Values:
//  S_SUCCESS
//  E_UNINITIALIZED_OBJECT
RESULT Console::GetCursorPos(unsigned int *x, unsigned int *y) const
{
  if(!lines)
    return(E_UNINITIALIZED_OBJECT);

  if(x)
    *x = posx;
  if(y)
    *y = posy;

  return(S_SUCCESS);
}

//Clear will clear the console and set the cursor to the upper left pos.
//Return Values:
//  S_SUCCESS
//  E_UNITIALIZED_OBJECT
RESULT Console::Clear(void)
{
  int i;

  if(!lines)
    return(E_UNINITIALIZED_OBJECT);

  for(i=0;i<CONSOLE_HEIGHT_CHAR;i++)
    lines[i][0] = '\0';

  posx = posy = 1;
  return(S_SUCCESS);
}

//MoveUp will move the entire console up one line.  This will destroy the
//data currently on the top line of the screen.  The cursor is not moved.
void Console::MoveUp(void)
{
  char *top;
  unsigned int i;

  //Move the pointers around
  top = lines[0];
  for(i=0;i<CONSOLE_HEIGHT_CHAR - 1; i++)
    lines[i] = lines[i+1];
  lines[CONSOLE_HEIGHT_CHAR - 1] = top;

  //Blank out the new line
  for(i=0;i<CONSOLE_WIDTH_CHAR+1;i++)
    lines[CONSOLE_HEIGHT_CHAR - 1][i] = 0;
}
