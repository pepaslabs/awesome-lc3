/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman

  This file contains all the error codes used in the LC2 engine.
*/

#ifndef _lc2err_h_
#define _lc2err_h_

//RESULT must be large enough to hold all the error codes
//defined in this file.
typedef int RESULT;

#define S_SUCCESS               0
#define E_INVALID_ARG           1
#define E_INSUFFICIENT_MEMORY   2
#define E_ENTRY_NOT_FOUND       3
#define E_ENTRY_EXISTS          4
#define E_UNINITIALIZED_OBJECT  5
#define S_HOLD_NOCLOCK          6
#define E_INVALID_INSTRUCTION   7
#define E_FILE_NOT_FOUND        8
#define E_MEMORY_OVERRUN        9
#define E_FILE_IO              10
#define S_NO_UPDATE            11
#define S_HOLD_BP              12

#endif