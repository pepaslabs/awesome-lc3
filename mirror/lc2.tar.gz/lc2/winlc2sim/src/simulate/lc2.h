/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman

  This file contains various definitions used throughout the
  LC2 engine.
*/

#ifndef _lc2_h_
#define _lc2_h_

#include <stddef.h>

//The number of bits in the BITS type must be exactly
//equal to the addressibility of the LC2.  It must also
//be an unsigned data type.
typedef unsigned short BITS;

//The STORAGE data type must contain sufficient bits to
//represent each memory location and all the registers.
typedef int STORAGE;

//MEMORY_SIZE is the number of addresses in the LC2 main memory
//65536 = 2^16
#define MEMORY_SIZE 65536

#define MAX_SIGNED_MAG 32767
#define MIN_SIGNED_MAG -32768

//The register identifiers
#define PC -1
#define IR -2
#define CC -3
#define R0 -4
#define R1 -5
#define R2 -6
#define R3 -7
#define R4 -8
#define R5 -9
#define R6 -10
#define R7 -11

#define NUM_REGISTERS 11
#define NUM_GENERAL_REGISTERS 8

#define VALIDATE_LOCATION(x) ((x >= -NUM_REGISTERS)?1:0)

//Condition Code definitions
#define PCC 1
#define ZCC 2
#define NCC 4
#define PBIT(x) ((x) & PCC)
#define ZBIT(x) ((x) & ZCC)
#define NBIT(x) ((x) & NCC)

//Special Address
#define CRTSR_ADDRESS  0xF3FC
#define CRTDR_ADDRESS  0xF3FF
#define KBSR_ADDRESS   0xF400
#define KBDR_ADDRESS   0xF401
#define MCR_ADDRESS    0xFFFF

//Special Register Values
#define CLOCK_ENABLE        0xFFFF
#define NO_CLOCK            0x7FFF
#define KEYBOARD_PRESSED    0xFFFF
#define NO_KEYBOARD_PRESSED 0x7FFF
#define CHAR_TO_DISPLAY     0x7FFF
#define NO_CHAR_TO_DISPLAY  0xFFFF


//OpCodes
#define ADD    1
#define AND    5
#define JSR    4
#define JMP    4
#define JSRR  12
#define JMPR  12
#define LD     2
#define LDI   10
#define LDR    6
#define LEA   14
#define NOT    9
#define RET   13
#define ST     3
#define STI   11
#define STR    7
#define TRAP  15

#ifdef OLD_INSTRUCTION_SET
  #define NOP    0
  #define BR     8
#else
  #define RTI    8
  #define BR     0
#endif


//Macros to help in instruction parsing
#define OPCODE(x) ((x & 0xF000) >> 12)
#define DR(x) ((x & 0x0E00) >> 9)
#define SR(x) DR(x)
#define SR1(x) ((x & 0x01C0) >> 6)
#define BASER(x) SR1(x)
#define SR2(x) (x & 0x0007)
#define IMM5(x) ((x & 0x001F) | ((x & 0x0010)?0xFFE0:0)) //sign extension
#define PGOFFSET9(x) (x & 0x01FF)
#define INDEX6(x) (x & 0x003F)
#define TRAPVECT8(x) (x & 0x00FF)
#define IMMVAL(x) ((x & 0x0020) >> 5)
#define CONDCODES(x) ((x & 0x0E00) >> 9)
#define LINK(x) ((x & 0x0800) >> 11)
#define PC6(x) (x & 0xFE00)

//Console Constants
#define CONSOLE_HEIGHT_CHAR 24
#define CONSOLE_WIDTH_CHAR  80

//Other useful constants
#define MSB_MASK 0x8000

#define DEFAULT_START_LOC 0x3000
#define MIN_USER_MEM_LOC 0x3000
#define MAX_USER_MEM_LOC 0xCFFF

#endif
