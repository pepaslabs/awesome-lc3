/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman

  This file contains the declarations for window creation and resizing.
*/

#ifndef _create_h_
#define _create_h_

#include <windows.h>

void RegisterClasses(HINSTANCE hInstance,
                     WNDPROC SimProc,
                     WNDPROC ConsoleProc);

void CreateWindows(HINSTANCE hInstance, int iCmdShow);
HWND CreateMemoryBox(HWND hwnd,
                     HINSTANCE hInstance);
HWND CreateMemoryScroll(HWND hwnd,
                        HINSTANCE hInstance,
                        int lines);
HWND CreateMemoryBP(HWND hwnd,
                    HINSTANCE hInstance);
HWND CreateRegisterBox(HWND hwnd,
                       HINSTANCE hInstance);
HWND CreateButtonBar(HWND parent, HINSTANCE hInst);


void ResizeConsoleWindow(HWND hwnd);
void ResizeSimWindow(HWND hwnd);
int RepositionChildWindows(HWND parent, HWND Reg1, HWND Reg2, HWND Reg3,
                           HWND MemLB, HWND MemBP, HWND MemScroll);

#endif
