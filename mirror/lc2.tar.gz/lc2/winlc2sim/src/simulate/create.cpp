/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman

  This file contains the functions used to create,
  register, and resize windows as well as the the controls
  contained within them.
*/

#include <windows.h>
#include <commctrl.h>
#include "lc2.h"
#include "create.h"
#include "simulate.h"
#include "main.h"
#include "gui_cons.h"
#include "btnbar.h"
#include "resource.h"

//Prototypes for internal functions
static void RepositionMemoryLB(HWND hwndSim, HWND hwndMem, int displayOffset);
static void RepositionMemoryBP(HWND hwndSim, HWND hwndMem, int displayOffset);
static void RepositionMemoryScroll(HWND hwndSim, HWND hwndMem,
                                   int displayOffset);
static int RepositionRegisterDisplay(HWND hwndSim, HWND hwndReg, int index);

//Registers all window classes used in this program:
//The simulator and console.
void RegisterClasses(HINSTANCE hInstance,
                     WNDPROC SimProc,
                     WNDPROC ConsoleProc)
{
  WNDCLASSEX wndclass;

  //For the simulator
  wndclass.cbSize         = sizeof(wndclass);
  wndclass.style          = CS_VREDRAW | CS_HREDRAW;
  wndclass.lpfnWndProc    = SimProc;
  wndclass.cbClsExtra     = 0;
  wndclass.cbWndExtra     = 0;
  wndclass.hInstance      = hInstance;
  wndclass.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_APP));
  wndclass.hCursor        = LoadCursor(NULL, IDC_ARROW);
  wndclass.hbrBackground  = (HBRUSH)GetStockObject(WHITE_BRUSH);
  wndclass.lpszMenuName   = MAKEINTRESOURCE(IDM_SimMenu);
  wndclass.lpszClassName  = SIM_NAME;
  wndclass.hIconSm        = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_APP));
  RegisterClassEx(&wndclass);

  //For the console
  wndclass.cbSize         = sizeof(wndclass);
  wndclass.style          = CS_VREDRAW | CS_HREDRAW | CS_NOCLOSE;
  wndclass.lpfnWndProc    = ConsoleProc;
  wndclass.cbClsExtra     = 0;
  wndclass.cbWndExtra     = 0;
  wndclass.hInstance      = hInstance;
  wndclass.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_APP));
  wndclass.hCursor        = LoadCursor(NULL, IDC_ARROW);
  wndclass.hbrBackground  = (HBRUSH)GetStockObject(WHITE_BRUSH);
  wndclass.lpszMenuName   = NULL;
  wndclass.lpszClassName  = CONSOLE_NAME;
  wndclass.hIconSm        = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_APP));
  RegisterClassEx(&wndclass);
}

//Create the main windows (simulator, console)
//Proper sizing can be handled by a separate call
//to the resize functions contained in this file.
void CreateWindows(HINSTANCE hInstance, int iCmdShow)
{
  RECT r;
  int height5;  //5% height of display
  int consoleOffset;

  //For the Simulator
  SystemParametersInfo(SPI_GETWORKAREA, 0, &r, 0);
  height5 = r.bottom / 20;
  hwndSim = CreateWindow(SIM_NAME,
                         SIM_TITLE,
                         WS_CLIPCHILDREN |
                         (WS_OVERLAPPEDWINDOW & ~WS_MAXIMIZEBOX & ~WS_SIZEBOX),
                         height5,
                         height5,
                         CW_USEDEFAULT,
                         CW_USEDEFAULT,
                         NULL,
                         NULL,
                         hInstance,
                         NULL);

  //For the Console
  if(3 * height5 + SIM_WINDOW_WIDTH + CONSOLE_WIDTH < r.right)
    consoleOffset = 2 * height5 + SIM_WINDOW_WIDTH;
  else
    consoleOffset = 0;
  hwndConsole = CreateWindow(CONSOLE_NAME,
                             CONSOLE_TITLE,
                             WS_OVERLAPPED | WS_MINIMIZEBOX | WS_SYSMENU, 
                             consoleOffset,
                             consoleOffset?height5:0,
                             CW_USEDEFAULT,
                             CW_USEDEFAULT,
                             NULL,
                             NULL,
                             hInstance,
                             NULL);

  ShowWindow(hwndConsole, iCmdShow);
  ShowWindow(hwndSim, iCmdShow);
}

//Resizes the console window to contain 80x24
//characters at the current font size, as 
//specified in the global variables in
//simulate.cpp.
void ResizeConsoleWindow(HWND hwnd)
{
  RECT r;

  GetWindowRect(hwnd, &r);

  MoveWindow(hwnd,
             r.left,
             r.top,
             CONSOLE_WIDTH,
             CONSOLE_HEIGHT,
             TRUE);
}

//Resizes the simulator window to accomodate an integral number
//of display lines.  The simulator will use approximately 80% of
//the screen height.
void ResizeSimWindow(HWND hwnd)
{
  RECT r;
  int height90, lines;

  SystemParametersInfo(SPI_GETWORKAREA, 0, &r, 0);
  height90 = r.bottom * 9 / 10;
  lines = (int)((height90 - MIN_SIM_WINDOW_HEIGHT) / gfontHeight);
  GetWindowRect(hwnd, &r);

  MoveWindow(hwnd,
             r.left,
             r.top,
             SIM_WINDOW_WIDTH,
             (int)(MIN_SIM_WINDOW_HEIGHT + lines * gfontHeight),
             TRUE);
}


//Creates a listbox to display the memory contents
//and associated strings.  Positioning is done
//relative to the displayOffset.
HWND CreateMemoryBox(HWND hwnd, HINSTANCE hInstance)
{
  HWND hwndLB;

  hwndLB = CreateWindow("listbox", NULL,
                        WS_CHILD | WS_VISIBLE | WS_TABSTOP | LBS_NOTIFY |
                        LBS_HASSTRINGS | LBS_WANTKEYBOARDINPUT | LBS_NOINTEGRALHEIGHT,
                        0, 0, 0, 0,
                        hwnd, NULL, hInstance, NULL);

  SendMessage(hwndLB, WM_SETFONT, (WPARAM)ghFont, MAKELPARAM(FALSE, 0));

  return(hwndLB);
}

//Creates the breakpoint window.  This
//contains clickable images to display the active
//PC= breakpoints as well as the current PC position.
HWND CreateMemoryBP(HWND hwnd, HINSTANCE hInstance)
{
  HWND hwndMemBP;

  hwndMemBP = CreateWindow("listbox", NULL,
                           WS_CHILD | WS_VISIBLE | LBS_NOTIFY |
                           LBS_OWNERDRAWFIXED | LBS_NOINTEGRALHEIGHT,
                           0, 0, 0, 0,
                           hwnd, NULL, hInstance, NULL);
  return(hwndMemBP);
}

//Creates the scrollbar used to scroll through the
//memory display.  The actual link between the scroll
//bar and listbox is not created in this function.
HWND CreateMemoryScroll(HWND hwnd, HINSTANCE hInstance, int lines)
{
  HWND hwndScroll;

  hwndScroll = CreateWindow("scrollbar", NULL,
                            WS_CHILD | WS_TABSTOP | SBS_VERT,
                            0, 0, 0, 0,
                            hwnd, NULL, hInstance, NULL);
  SetScrollRange(hwndScroll, SB_CTL, 0, MEMORY_SIZE - lines, FALSE);
  SetScrollPos(hwndScroll, SB_CTL, DEFAULT_START_LOC, TRUE);

  ShowWindow(hwndScroll, SW_SHOW);
  return(hwndScroll);
}

//Creates a register display listbox.  Index and
//displayOffset are used to indicate which register
//box is being created, to determine the proper offset.
//Both are zero based offsets.
HWND CreateRegisterBox(HWND hwnd, HINSTANCE hInstance)
{
  HWND hwndLB;

  hwndLB = CreateWindow("listbox", NULL,
                        WS_CHILD | WS_VISIBLE | WS_TABSTOP | LBS_NOTIFY |
                        LBS_HASSTRINGS | LBS_NOINTEGRALHEIGHT,
                        0, 0, 0, 0,
                        hwnd, NULL, hInstance, NULL);

  SendMessage(hwndLB, WM_SETFONT, (WPARAM)ghFont, MAKELPARAM(FALSE, 0));
  return(hwndLB);
}

//Position the memory listbox and maximize its size
//according to displayOffset.
static void RepositionMemoryLB(HWND hwndSim, HWND hwndMem, int displayOffset)
{
  RECT r;

  GetClientRect(hwndSim, &r);

  MoveWindow(hwndMem,
             gfontHeight + 2*GetSystemMetrics(SM_CXBORDER),
             displayOffset,
             MEM_STRLEN * gfontWidth + 2*GetSystemMetrics(SM_CXBORDER),
             r.bottom - displayOffset,
             FALSE);
}

//Positions and sizes the breakpoint/pc display to the same
//vertical size as the memory listbox and scrollbar.
static void RepositionMemoryBP(HWND hwndSim, HWND hwndMem, int displayOffset)
{
  RECT r;

  GetClientRect(hwndSim, &r);

  MoveWindow(hwndMem,
             0,
             displayOffset,
             gfontHeight + 2*GetSystemMetrics(SM_CXBORDER),
             r.bottom - displayOffset,
             FALSE);
}

//Positions and sizes the memory scrollbar to the same
//vertical size as the memory listbox and breakpoint/pc display.
static void RepositionMemoryScroll(HWND hwndSim,
                                   HWND hwndMem,
                                   int displayOffset)
{
  RECT r;

  GetClientRect(hwndSim, &r);

  MoveWindow(hwndMem,
             r.right - GetSystemMetrics(SM_CXVSCROLL),
             displayOffset,
             GetSystemMetrics(SM_CXVSCROLL),
             r.bottom - displayOffset,
             TRUE);
}

//Repositions a single register display listbox.  Index
//is the zero based offset assigned to the listbox.
int RepositionRegisterDisplay(HWND hwndSim, HWND hwndReg, int index)
{
  RECT r;
  int rval;
  int LBwidth, LBheight;
  int topOffset;
  int startLeft;
  int spacing;

  GetClientRect(hwndSim, &r);

  //Width and height calculations
  LBwidth = 17 * gfontWidth + 2*GetSystemMetrics(SM_CXBORDER);
  spacing = r.right / 3 - LBwidth;
  topOffset = 3 * gfontHeight / 8 + TBHEIGHT;
  LBheight = 4 * gfontHeight;
  rval = topOffset + LBheight;

  //Get starting x position
  switch(index)
    {
    case 1:
      startLeft = spacing / 2;
      break;
    case 2:
      startLeft = spacing * 3/2 + LBwidth;
      break;
    case 3:
      startLeft = spacing * 5/2 + 2*LBwidth;
      break;
    default:
      return(0); //Should never happen
    }

  MoveWindow(hwndReg, startLeft, topOffset, LBwidth, LBheight, FALSE);

  return(rval);
}

//Repositions all windows in the simulator.  This is the only
//repositioning function designed to be called from outside
//this file.
int RepositionChildWindows(HWND parent,
                           HWND Reg1,
                           HWND Reg2,
                           HWND Reg3,
                           HWND MemLB,
                           HWND MemBP,
                           HWND MemScroll)
{
  int displayOffset;

  displayOffset = RepositionRegisterDisplay(parent, Reg1, 1);
  displayOffset += 3 * gfontHeight / 8;
  RepositionRegisterDisplay(parent, Reg2, 2);
  RepositionRegisterDisplay(parent, Reg3, 3);
  RepositionMemoryLB(parent, MemLB, displayOffset);
  RepositionMemoryBP(parent, MemBP, displayOffset);
  RepositionMemoryScroll(parent, MemScroll, displayOffset);
  return(displayOffset);
}

//Creates a button bar for the simulator window
//and adds the necessary buttons to it.
HWND CreateButtonBar(HWND parent, HINSTANCE hInst)
{
  HWND tb;
  TBADDBITMAP tbab;
  TBBUTTON tbbtn[NUM_TB_BTNS] =
    {
    0, 0, 0, TBSTYLE_SEP, 0, 0, 0, 0,
    STD_FILEOPEN+NUM_TB_IMGS, IDM_FILE_LOAD,         TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0, 0, 0,
    0, 0, 0, TBSTYLE_SEP, 0, 0, 0, 0,
    IDB_TB_RUN,               IDM_SIMULATE_RUN,      TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0, 0, 0,
    IDB_TB_STEP,              IDM_SIMULATE_STEP,     TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0, 0, 0,
    0, 0, 0, TBSTYLE_SEP, 0, 0, 0, 0,
    IDB_TB_ADDBP,             IDM_SIMULATE_BPADD,    TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0, 0, 0,
    IDB_TB_TOGGLEBP,          IDM_SIMULATE_BPTOGGLE,        0       , TBSTYLE_BUTTON, 0, 0, 0, 0,
    IDB_TB_REMOVEBP,          IDM_SIMULATE_BPREMOVE, TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0, 0, 0,
    0, 0, 0, TBSTYLE_SEP, 0, 0, 0, 0,
    IDB_TB_SETVALUE,          IDM_SIMULATE_SETVAL,   TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0, 0, 0,
    IDB_TB_SETPC,             IDM_SIMULATE_SETPC ,          0       , TBSTYLE_BUTTON, 0, 0, 0, 0,
    0, 0, 0, TBSTYLE_SEP, 0, 0, 0, 0,
    IDB_TB_JUMPDISP,          IDM_DISPLAY_JUMP,      TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0, 0, 0
    };

  tb = CreateToolbarEx(parent,
                       WS_CHILD | WS_VISIBLE | CCS_TOP | TBSTYLE_TOOLTIPS,
                       1,
                       0, NULL, 0,
                       NULL, 0,
                       0, 0, 16, 16,
                       sizeof(TBBUTTON));

  //Add bitmaps
  tbab.hInst = hInst;
  tbab.nID = IDB_TB_BTNS;
  SendMessage(tb, TB_ADDBITMAP, 1, (LPARAM)&tbab);
  tbab.hInst = HINST_COMMCTRL;
  tbab.nID = IDB_STD_SMALL_COLOR;
  SendMessage(tb, TB_ADDBITMAP, 1, (LPARAM)&tbab);

  //Add Buttons
  SendMessage(tb, TB_ADDBUTTONS, NUM_TB_BTNS, (LPARAM) &tbbtn);

  return(tb);
}
