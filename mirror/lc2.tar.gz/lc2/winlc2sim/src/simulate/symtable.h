/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman

  This file declares the symbol class.

  The symbol table relates strings to memory addresses.
  It is case sensitive.

  Internally, the symbol table is implemented as a linked list.
  Each node contains two next pointers: one for a sort by label,
  and one for a sort by address.  The labels are sorted alphabetically,
  while the addresses on in descending order.  Because addresses will
  be encountered in ascending order, this makes inserts less costly.
  
  See lc2.h for applicable constants.
*/

#ifndef _symtable_h
#define _symtable_h

#include "lc2.h"
#include "lc2err.h"

//Maximum number of characters in a label
#define MAX_LABEL_LENGTH 255

class symtable
{
  public:
    //Default Constructor initializes internal variables.
    symtable(void);

    //Destructor frees all memory associated with the object.
    virtual ~symtable(void);

    //Load will load a symbol table from a given file.
    //Return Values
    //  S_OK
    //  E_FILE_NOT_FOUND
    //  E_FILE_IO
    RESULT Load(const char *fname);

    //Add will add an entry to the symbol table.
    //Possible Return Values:
    //  S_SUCCESS
    //  E_ENTRY_EXISTS
    //  E_INVALID_ARG (string too long)
    //  E_INSUFFICIENT_MEMORY
    RESULT Add(const char *label, BITS address);

    //Clear will remove all entries from the symbol table.
    void Clear(void);

    //GetAddress will lookup a label in the table and return
    //its associated address.
    //Return Values:
    //  S_SUCCESS
    //  E_ENTRY_NOT_FOUND
    RESULT GetAddress(const char *label, BITS *address) const;

    //GetLabel will lookup a label in the table and return
    //its associated label.  The string must already be
    //allocated with sufficient space to hold the label.
    //Return Values:
    //  S_SUCCESS
    //  E_ENTRY_NOT_FOUND
    RESULT GetLabel(const STORAGE address, char *label) const;

    //GetEntry will return the label and address for an entry, when
    //specified by index.  Indexes start at 0.  The string must be
    //pre-allocated.
    //Return Values:
    //  S_SUCCESS
    //  E_ENTRY_NOT_FOUND
    RESULT GetEntry(unsigned int index, char *label, BITS *address) const;

    //NumEntries will return the number of entries in the symbol table.
    unsigned int NumEntries(void) const;

  protected:
    //The basic structure in the symbol table
    typedef struct node_T {
      char *label;
      BITS address;
      node_T *next_address;
      node_T *next_label;
      } node_t;

    //DeleteNode will delete all memory contained in a node,
    //including the node itself.
    void DeleteNode(node_t *node);

    //last_indexed and last_index are used for efficiency.  Often, GetEntry
    //will be called with sequential integers.  To save time iterating through
    //the list on each call, last_indexed will point to the last item indexed
    //by the GetEntry function, and last_index stores the integer.  Both are
    //reset on an Add.
    node_t *last_indexed;
    unsigned int last_index;

  private:
    //The copy constructor and operator= are disabled.  The symbol table
    //should not be copied: it is too large.  No definition is provided
    //for these functions.
    symtable(const &symtable);
    symtable operator=(const &symtable);

    unsigned int entries;  //The number of entries in the symbol table
    node_t *head_address; //Pointer to the first entry.
    node_t *head_label;
};

#endif

