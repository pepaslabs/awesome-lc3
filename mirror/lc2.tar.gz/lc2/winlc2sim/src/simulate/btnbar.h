/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman

  This file defines the bitmap identifiers.
*/

#ifndef _bitmaps_h_
#define _bitmaps_h_

#define NUM_TB_IMGS 8

#define IDB_TB_ADDBP    0
#define IDB_TB_RUN      1
#define IDB_TB_STEP     2
#define IDB_TB_JUMPDISP 3
#define IDB_TB_SETVALUE 4
#define IDB_TB_REMOVEBP 5
#define IDB_TB_TOGGLEBP 6
#define IDB_TB_SETPC    7

#endif
