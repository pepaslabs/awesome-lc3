/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman
                                  
  This file contains the functions necessary to
  operate the graphical simulator window including
  window procedures and various other tools.
*/

#include <windows.h>
#include <commdlg.h>
#include <commctrl.h>
#include <stdio.h>
#include "create.h"
#include "main.h"
#include "simulate.h"
#include "gui_cons.h"
#include "dlgprocs.h"
#include "symtable.h"
#include "resource.h"

#define BITMAP_SIZE 16

//Internal function prototypes
static void InitOpenFile(LPOPENFILENAME opfn, TCHAR *fname, HWND hwnd);
static void GenerateString(STORAGE loc, LPTSTR str);
static void GetOpcodeSTR(BITS val, LPTSTR opcode);
static HBITMAP SelectBPImage(STORAGE loc);
static STORAGE HwndOffsetToLocation(HWND hwnd, int offset, STORAGE startAddress);
static HWND LocationToHwnd(STORAGE loc);
static int LocationToOffset(STORAGE loc, STORAGE startAddress, int lines);
static LRESULT CALLBACK ListBoxProc(HWND hwnd, UINT iMsg,
                             WPARAM wParam, LPARAM lParam);

//Various global handles
HBITMAP BITMAP_NULL, BITMAP_PCONLY, BITMAP_BPONLY, BITMAP_BPANDPC;
FARPROC OrigProc[4];
HWND hwndMemScroll, hwndMemBP, hwndLB[4], hwndTB;
HWND hRunDlg = NULL, hStepDlg = NULL;
HMENU hMenuPopup = NULL;

//Menu options
char gFollowPC=1;
char gWarnLargeExecution=1;
char gStepOverTraps=1;

//Window procedure for the simulator window
LRESULT CALLBACK SimProc(HWND hwnd,
                         UINT iMsg,
                         WPARAM wParam,
                         LPARAM lParam)
{
  static HINSTANCE hInstance;
  static int lines;
  static STORAGE startAddress;

  switch(iMsg)
    {
    case WM_CREATE:
      {
      int i;

      hInstance = ((LPCREATESTRUCT)lParam)->hInstance;
      BITMAP_NULL    = LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_NULL));
      BITMAP_PCONLY  = LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_PCONLY));
      BITMAP_BPONLY  = LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_BPONLY));
      BITMAP_BPANDPC = LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_BPANDPC));

      //Create child controls
      hwndTB = CreateButtonBar(hwnd, hInstance);
      for(i=1;i<=3;i++)
        hwndLB[i] = CreateRegisterBox(hwnd, hInstance);
      hwndLB[0] = CreateMemoryBox(hwnd, hInstance);
      hwndMemBP = CreateMemoryBP(hwnd, hInstance);
      hwndMemScroll = CreateMemoryScroll(hwnd, hInstance, 0);

      //This sizes everything appropriately
      ResizeSimWindow(hwnd);

      //Subclass the listboxes
      for(i=0;i<=3;i++)
        OrigProc[i] = (FARPROC)SetWindowLong(hwndLB[i], GWL_WNDPROC, (LONG)ListBoxProc);

      //Start the display
      SendMessage(hwnd, WM_MEMRANGE, DEFAULT_START_LOC, 0);
      SendMessage(hwnd, WM_MEMREFRESH, 0, 0);  //For the registers

      //Load the popup menu
      hMenuPopup = LoadMenu(hInstance, MAKEINTRESOURCE(IDM_Popup));
      hMenuPopup = GetSubMenu(hMenuPopup, 0);

      return(0);
      }

    case WM_COMMAND:
      switch(LOWORD(wParam))
        {
        case IDM_FILE_LOAD:
          {
          OPENFILENAME opfn;
          TCHAR fname[_MAX_PATH] = "";
          RESULT r;

          SetFocus(hwnd);
          InitOpenFile(&opfn, fname, hwnd);
          if(GetOpenFileName(&opfn))
            {
            r=lc2.LoadProgram(opfn.lpstrFile);

            if(r == S_SUCCESS)
              {
              BITS pc;

              symtble.Clear();
              lc2.ClearAllBreakPoints();
              opfn.lpstrFile[opfn.nFileExtension]   = 's';
              opfn.lpstrFile[opfn.nFileExtension+1] = 'y';
              opfn.lpstrFile[opfn.nFileExtension+2] = 'm';
              opfn.lpstrFile[opfn.nFileExtension+3] = '\0';
              symtble.Load(opfn.lpstrFile);

              lc2.GetValue(PC, &pc);
              SendMessage(hwnd, WM_MEMREFRESH, 0, 0);
              //only needed for loading program outside user addresses
              SendMessage(hwnd, WM_MEMRANGE, pc, 1);
              }
            else
              MessageBox(hwnd,
                         "Unable to load program.",
                         "Load Error",
                         MB_OK | MB_ICONERROR);
            }
          return(0);
          }

        case IDM_FILE_REINIT:
          if(MessageBox(hwnd,
             "Reinitializing the machine will reset all values.  Continue?",
             "Reinitialize Machine",
             MB_YESNO | MB_ICONQUESTION) == IDYES)
            {
            symtble.Clear();
            lc2.ClearAllBreakPoints();
            lc2.ClearConsole();
            InvalidateRect(hwndConsole, NULL, FALSE); //Force refresh
            lc2.StartUp();
            LoadOS(hwnd);
            lc2.SetValue(PC, DEFAULT_START_LOC);
            gLastUserPC = DEFAULT_START_LOC;

            SendMessage(hwnd, WM_MEMRANGE, DEFAULT_START_LOC, 0);
            SendMessage(hwnd, WM_MEMREFRESH, 0, 0);
            }
          return(0);

        case IDM_FILE_CLEARCONS:
          lc2.ClearConsole();
          InvalidateRect(hwndConsole, NULL, FALSE); //Force refresh
          return(0);

        case IDM_FILE_EXIT:
          SendMessage(hwnd, WM_CLOSE, 0, 0);
          return(0);

        case IDM_DISPLAY_JUMP:
          {
          BITS pc;

          lc2.GetValue(PC, &pc);
          DialogBoxParam(hInstance, "JumpDisplay", hwnd,
                         (DLGPROC)JumpDlgProc, (LPARAM)pc);
          return(0);
          }

        case IDM_DISPLAY_FONT:
          DialogBox(hInstance, "FontSizeDlg", hwnd, (DLGPROC)FontSizeDlgProc);
          return(0);

        case IDM_SIMULATE_RUN:
          DialogBox(hInstance, "RunDlg", hwnd, (DLGPROC)RunDlgProc);
          return(0);

        case IDM_SIMULATE_STEP:
          DialogBox(hInstance, "StepDlg", hwnd, (DLGPROC)StepDlgProc);
          return(0);

        case IDM_SIMULATE_SETVAL:
          DialogBoxParam(hInstance, "SetValueDlg", hwnd, 
                         (DLGPROC)SetValueDlgProc, (LPARAM)NULL);
          return(0);

        case IDM_SIMULATE_BPADD:
          DialogBox(hInstance, "AddBPDlg", hwnd, (DLGPROC)AddBPDlgProc);
          return(0);

        case IDM_SIMULATE_SETPC:
          {
          int sel;

          if((HWND)lParam == hwndMemBP)
            sel = SendMessage((HWND)lParam, LB_GETCURSEL, 0, 0);
          else
            sel = SendMessage(hwndLB[0], LB_GETCURSEL, 0, 0);

          if(sel != -1) //Nothing selected
            {
            lc2.SetValue(PC, (BITS)(startAddress+sel));
            SendMessage(hwnd, WM_MEMREFRESH, 0, MAKELPARAM(0,1));
            SendMessage(hwndLB[0], LB_SETCURSEL, sel, 0);
            }

          return(0);
          }

        case IDM_SIMULATE_BPTOGGLE:
          {
          int sel;

          if((HWND)lParam == hwndMemBP)
            sel = SendMessage((HWND)lParam, LB_GETCURSEL, 0, 0);
          else
            sel = SendMessage(hwndLB[0], LB_GETCURSEL, 0, 0);

          if(sel == -1) //Nothing selected
            return(0);

          //First try clearing it.  If it isn't found, add it.
          if(lc2.ClearBreakPoint(PC, (BITS)(startAddress + sel)) != S_SUCCESS)
            lc2.SetBreakPoint(PC, (BITS)(startAddress + sel));
          SendMessage(hwnd, WM_MEMREFRESH,
                      startAddress + sel, MAKELPARAM(1,1));

          //Reset the selection due to refreshing
          if((HWND)lParam != hwndMemBP)
            SendMessage(hwndLB[0], LB_SETCURSEL, sel, 0);

          return(0);
          }

        case IDM_SIMULATE_BPREMOVE:
          DialogBox(hInstance, "RemoveBPDlg", hwnd, (DLGPROC)RemoveBPDlgProc);
          return(0);

        case IDM_OPTIONS_PC:
          if(GetMenuState(GetMenu(hwnd), IDM_OPTIONS_PC, MF_BYCOMMAND) &
             MF_CHECKED)
            CheckMenuItem(GetMenu(hwnd), IDM_OPTIONS_PC,
                          MF_BYCOMMAND | MF_UNCHECKED);
          else
            CheckMenuItem(GetMenu(hwnd), IDM_OPTIONS_PC,
                          MF_BYCOMMAND | MF_CHECKED);
          gFollowPC = !gFollowPC;
          return(0);

        case IDM_OPTIONS_TRAPS:
          if(GetMenuState(GetMenu(hwnd), IDM_OPTIONS_TRAPS,
                          MF_BYCOMMAND) & MF_CHECKED)
            CheckMenuItem(GetMenu(hwnd), IDM_OPTIONS_TRAPS,
                          MF_BYCOMMAND | MF_UNCHECKED);
          else
            CheckMenuItem(GetMenu(hwnd), IDM_OPTIONS_TRAPS,
                          MF_BYCOMMAND | MF_CHECKED);
          gStepOverTraps = !gStepOverTraps;
          return(0);

        case IDM_OPTIONS_LOOP:
          if(GetMenuState(GetMenu(hwnd), IDM_OPTIONS_LOOP,
                          MF_BYCOMMAND) & MF_CHECKED)
            CheckMenuItem(GetMenu(hwnd), IDM_OPTIONS_LOOP,
                          MF_BYCOMMAND | MF_UNCHECKED);
          else
            CheckMenuItem(GetMenu(hwnd), IDM_OPTIONS_LOOP,
                          MF_BYCOMMAND | MF_CHECKED);
          gWarnLargeExecution = !gWarnLargeExecution;
          return(0);

        case IDM_HELP_ABOUT:
          {
          TCHAR text[250];
          wsprintf(text,
                   "LC2 Simulator - Windows Version\n\nCopyright %d Brian J. Hartman and Matt Postiff\nSend comments to bhartman@eecs.umich.edu\n\nSimulator v%s  --  %s",
                   COPYRIGHT_YEAR, SIM_VER, SIM_DATE);
          MessageBox(hwnd, text, "About LC2 Simulator",
                     MB_OK | MB_ICONINFORMATION);
          return(0);
          }

        default:  //Used for Double click
          if(((HWND)lParam == hwndLB[0] ||
              (HWND)lParam == hwndLB[1] ||
              (HWND)lParam == hwndLB[2] ||
              (HWND)lParam == hwndLB[3]) &&
             HIWORD(wParam) == LBN_DBLCLK)
            {
            int sel;
            STORAGE loc;

            sel = SendMessage((HWND)lParam, LB_GETCURSEL, 0, 0);
            loc = HwndOffsetToLocation((HWND)lParam, sel, startAddress);

            DialogBoxParam(hInstance, "SetValueDlg", hwnd,
                           (DLGPROC)SetValueDlgProc, (LPARAM)&loc);

            //Set focus back to selected object
            SetFocus((HWND)lParam);
            SendMessage((HWND)lParam, LB_SETCURSEL, sel, 0);
            return(0);
            }

          if((HWND)lParam == hwndMemBP &&
             HIWORD(wParam) == LBN_DBLCLK) //Double clicked on dot column
            {
            SendMessage(hwndSim, WM_COMMAND,
                        MAKEWPARAM(IDM_SIMULATE_BPTOGGLE,0), lParam);
            return(0);
            }

        return(DefWindowProc(hwnd, iMsg, wParam, lParam));
      }

    case WM_NOTIFY:
      {
      LPNMHDR pnmh = (LPNMHDR) lParam;

      if(pnmh->code == TTN_NEEDTEXT)
        {
        LPTOOLTIPTEXT lpttt = (LPTOOLTIPTEXT) lParam;

        switch(lpttt->hdr.idFrom)  //Button index
          {
          case IDM_FILE_LOAD:
            lstrcpy(lpttt->szText, "Load program");
            break;
          case IDM_SIMULATE_BPADD:
            lstrcpy(lpttt->szText, "Add breakpoint");
            break;
          case IDM_SIMULATE_BPTOGGLE:
            lstrcpy(lpttt->szText, "Toggle breakpoint");
            break;
          case IDM_SIMULATE_BPREMOVE:
            lstrcpy(lpttt->szText, "Remove breakpoints");
            break;
          case IDM_SIMULATE_RUN:
            lstrcpy(lpttt->szText, "Run program");
            break;
          case IDM_SIMULATE_STEP:
            lstrcpy(lpttt->szText, "Step through program");
            break;
          case IDM_DISPLAY_JUMP:
            lstrcpy(lpttt->szText, "Jump display to memory location");
            break;
          case IDM_SIMULATE_SETVAL:
            lstrcpy(lpttt->szText, "Set value");
            break;
          case IDM_SIMULATE_SETPC:
            lstrcpy(lpttt->szText, "Set PC to selected location");
            break;
          default:
            wsprintf(lpttt->szText, "Button index %d", lpttt->hdr.idFrom);
            break;
          }
        }
      return(0);
      }

    case WM_VSCROLL:
      {
      int newpos = startAddress;
      int sel;

      if((HWND)lParam == hwndMemScroll)
        {
        switch(LOWORD(wParam))
          {
          case SB_LINEUP:
            if(startAddress)
              newpos--;
            break;
          case SB_LINEDOWN:
            if(startAddress < MEMORY_SIZE - lines)
              newpos++;
            break;
          case SB_PAGEUP:
            if(startAddress >= lines)
              newpos -= lines;
            else
              newpos = 0;
            break;
          case SB_PAGEDOWN:
            if(startAddress >= MEMORY_SIZE - 1 - lines - lines)
              newpos = MEMORY_SIZE - 1 - lines;
            else
              newpos += lines;
            break;
          case SB_THUMBTRACK:
            newpos = HIWORD(wParam);
            break;
          }
        if(newpos != startAddress)
          {
          STORAGE selectedAddressBefore;

          //Determine old selection
          sel = SendMessage(hwndLB[0], LB_GETCURSEL, 0, 0);
          selectedAddressBefore = sel + startAddress;

          //Do the scroll
          SetScrollPos(hwndMemScroll, SB_CTL, newpos, TRUE);
          SendMessage(hwnd, WM_MEMRANGE, newpos, 0);
          
          //Reset selection
          if(sel != -1 &&
             LOWORD(wParam) == SB_LINEUP ||
             LOWORD(wParam) == SB_LINEDOWN)
            if(selectedAddressBefore < startAddress)
              SendMessage(hwndLB[0], LB_SETCURSEL, 0, 0);
            else if(selectedAddressBefore > startAddress + lines - 1)
              SendMessage(hwndLB[0], LB_SETCURSEL, lines-1, 0);
            else
              SendMessage(hwndLB[0], LB_SETCURSEL,
                          selectedAddressBefore - startAddress, 0);
          }
        return(0);
        }
      else
        return(DefWindowProc(hwnd, iMsg, wParam, lParam));
      }

    case WM_VKEYTOITEM:
      if(hwndLB[0] == (HWND)lParam)
        switch(LOWORD(wParam))
          {
          int sel;
          int jumpToBounds;

          case VK_UP:
            if(!SendMessage(hwndLB[0], LB_GETCURSEL, 0, 0))
              {
              SendMessage(hwnd, WM_VSCROLL, SB_LINEUP, (LPARAM)hwndMemScroll);
              SendMessage(hwndLB[0], LB_SETCURSEL, 0, 0);
              return(-2);
              }
            break;
          case VK_PRIOR: //Page Up
            sel = SendMessage(hwndLB[0], LB_GETCURSEL, 0, 0);
            if(!startAddress)
              jumpToBounds = 1;
            else
              jumpToBounds = 0;
            SendMessage(hwnd, WM_VSCROLL, SB_PAGEUP, (LPARAM)hwndMemScroll);
            if(jumpToBounds) //If pageup while at top, jump selection to top
              SendMessage(hwndLB[0], LB_SETCURSEL, 0, 0);
            else
              SendMessage(hwndLB[0], LB_SETCURSEL, sel, 0);
            return(-2);
          case VK_DOWN:
            if(SendMessage(hwndLB[0], LB_GETCURSEL, 0, 0) == lines - 1)
              {
              SendMessage(hwnd, WM_VSCROLL, SB_LINEDOWN, (LPARAM)hwndMemScroll);
              SendMessage(hwndLB[0], LB_SETCURSEL, lines-1, 0);
              return(-2);
              }
            break;
          case VK_NEXT: //Page Down
            sel = SendMessage(hwndLB[0], LB_GETCURSEL, 0, 0);
            if(startAddress == MEMORY_SIZE - 1 - lines)
              jumpToBounds = 1;
            else
              jumpToBounds = 0;
            SendMessage(hwnd, WM_VSCROLL, SB_PAGEDOWN, (LPARAM)hwndMemScroll);
            if(jumpToBounds)
              SendMessage(hwndLB[0], LB_SETCURSEL, lines - 1, 0);
            else
              SendMessage(hwndLB[0], LB_SETCURSEL, sel, 0);
            return(-2);
          }
      return(DefWindowProc(hwnd, iMsg, wParam, lParam));

    case WM_SIZE:
      {
      RECT r;
      int displayOffset, i;
      displayOffset = RepositionChildWindows(hwnd, hwndLB[1], hwndLB[2],
                             hwndLB[3], hwndLB[0], hwndMemBP,
                             hwndMemScroll);

      //Recalculate the number of memory lines
      GetClientRect(hwnd, &r);
      lines = (r.bottom - displayOffset) / gfontHeight;

      //Update the MemBP display
      for(i=0;i<lines;i++)
        SendMessage(hwndMemBP, LB_SETITEMHEIGHT, i, gfontHeight);

      //Update the scroll range
      SetScrollRange(hwndMemScroll, SB_CTL, 0, MEMORY_SIZE - lines, FALSE);

      SendMessage(hwnd, WM_MEMREFRESH, 0, MAKELPARAM(0,1));
      return(0);
      }

    case WM_MEMRANGE:
      {
      TCHAR line[MEM_STRLEN+1];
      int i;

      startAddress = wParam;
      if(startAddress > MEMORY_SIZE - lines)
        startAddress = MEMORY_SIZE - lines;
      SendMessage(hwndLB[0], WM_SETREDRAW, (WPARAM)FALSE, 0);
      SendMessage(hwndLB[0], LB_RESETCONTENT, 0, 0);
      SendMessage(hwndMemBP, LB_RESETCONTENT, 0, 0);
      for(i=0; i<lines; i++)
        {
        GenerateString(startAddress + i, line);
        SendMessage(hwndLB[0], LB_ADDSTRING, i, (LPARAM) line);
        SendMessage(hwndMemBP, LB_ADDSTRING,
                    i, (LPARAM)SelectBPImage(startAddress + i));
        }
      SetScrollPos(hwndMemScroll, SB_CTL, startAddress, TRUE);
      SendMessage(hwndLB[0], WM_SETREDRAW, (WPARAM)TRUE, 0);
      InvalidateRect(hwndLB[0], NULL, TRUE);
      return(0);
      }

    case WM_MEMREFRESH:
      {
      TCHAR line[MEM_STRLEN+1];
      WPARAM index;
      HWND hwndCurLB;
      BITS pc;
      STORAGE loc;

      if(LOWORD(lParam))  //Update 1 entry
        {
        //Get the position
        hwndCurLB = LocationToHwnd(wParam);
        index = LocationToOffset(wParam, startAddress, lines);

        SendMessage(hwndCurLB, WM_SETREDRAW, (WPARAM)FALSE, 0);
        if(hwndCurLB == hwndLB[0])
          SendMessage(hwndLB[0], WM_SETREDRAW, (WPARAM)FALSE, 0);

        //Delete the old entries
        SendMessage(hwndCurLB, LB_DELETESTRING, index, 0);
        if(hwndCurLB == hwndLB[0])
          SendMessage(hwndMemBP, LB_DELETESTRING, index, 0);

        //Create the new ones
        GenerateString(wParam, line);
        SendMessage(hwndCurLB, LB_INSERTSTRING, index, (LPARAM)line);
        if(hwndCurLB == hwndLB[0])
          SendMessage(hwndMemBP, LB_INSERTSTRING,
                      index, (LPARAM)SelectBPImage(wParam));

        SendMessage(hwndCurLB, WM_SETREDRAW, (WPARAM)TRUE, 0);
        InvalidateRect(hwndCurLB, NULL, TRUE);
        if(hwndCurLB == hwndLB[0])
          {
          SendMessage(hwndCurLB, WM_SETREDRAW, (WPARAM)TRUE, 0);
          InvalidateRect(hwndMemBP, NULL, TRUE);
          }
        }
      else   //Update all entries
        {
        int i;

        //Memory
        if(gStepOverTraps)
          pc = gLastUserPC;
        else
          lc2.GetValue(PC, &pc);
        if(!HIWORD(lParam) && gFollowPC &&
           (pc < startAddress || pc >= startAddress + lines))
          SendMessage(hwnd, WM_MEMRANGE, pc, 0);
        else
          SendMessage(hwnd, WM_MEMRANGE, startAddress, 0);

        //Registers
        for(i=1;i<=3;i++)
          {
          SendMessage(hwndLB[i], WM_SETREDRAW, (WPARAM)FALSE, 0);
          SendMessage(hwndLB[i], LB_RESETCONTENT, 0, 0);
          }

        for(loc = PC; loc >= R7; loc--)
          {
          GenerateString(loc, line);
          SendMessage(LocationToHwnd(loc),
                      LB_INSERTSTRING,
                      LocationToOffset(loc, startAddress, lines),
                      (LPARAM)line);
          }

        for(i=1;i<=3;i++)
          SendMessage(hwndLB[i], WM_SETREDRAW, (WPARAM)TRUE, 0);
        }

      return(0);
      }

    case CONSOLE_CARET_POSITION:
      {
      unsigned int x, y;

      lc2.GetCursorPos(&x, &y);
      SetCaretPos((x-1) * gfontWidth, (y-1) * gfontHeight);
      return(0);
      }

    case WM_MEASUREITEM:
      {
      LPMEASUREITEMSTRUCT lpmis;

      lpmis = (LPMEASUREITEMSTRUCT) lParam;
      lpmis->itemWidth = gfontHeight;
      lpmis->itemHeight = gfontHeight;
      return(TRUE);
      }

    case WM_DRAWITEM:
      {
      LPDRAWITEMSTRUCT lpdis;
      HDC hDCMem;
      HBITMAP hBmp, hBmpOld;
      int stretchModeOld;

      lpdis = (LPDRAWITEMSTRUCT)lParam;
      if(lpdis->itemAction == ODA_DRAWENTIRE)
        {
        hBmp = (HBITMAP)SendMessage(lpdis->hwndItem, LB_GETITEMDATA,
                                    lpdis->itemID, 0);
        hDCMem = CreateCompatibleDC(lpdis->hDC);
        hBmpOld = (HBITMAP)SelectObject(hDCMem, hBmp);
        stretchModeOld = SetStretchBltMode(lpdis->hDC, HALFTONE);
        StretchBlt(lpdis->hDC, 2, lpdis->itemID * gfontHeight + 2, gfontHeight-2, gfontHeight-2,
                   hDCMem, 0, 0, BITMAP_SIZE, BITMAP_SIZE, SRCCOPY);
        SelectObject(hDCMem, hBmpOld);
        SetStretchBltMode(lpdis->hDC, stretchModeOld);
        DeleteDC(hDCMem);
        }
      return(TRUE);
      }

    case WM_SETCURSOR:
      if((short)LOWORD(lParam) == HTERROR &&
         HIWORD(lParam) == WM_LBUTTONDOWN)
        {
        HWND hToGiveFocus, htemp;

        hToGiveFocus = GetWindow(hwnd, GW_HWNDPREV);
        htemp = GetFocus();
        if(!htemp || htemp == hwndConsole)
          //Sometimes, hToGiveFocus is not the expected
          //window.  I think it is a child of hwnd. Don't know why yet.
          SetFocus(hToGiveFocus);
        return(0);
        }
      else
        return(DefWindowProc(hwnd, iMsg, wParam, lParam));

    case LC2_HOLD:
      {
      int choice;
      TCHAR str[65];
      STORAGE loc;
      BITS val;
      TCHAR locstr[6];

      SendMessage(hwnd, WM_MEMREFRESH, 0, 0);
      if(wParam == 0 && hRunDlg)  //Breakpoint
        {
        lc2.ActiveBreakPoint(&loc, &val);
        RegisterConstToStr(loc, locstr);
        wsprintf(str,
                 "%s = x%04X\n\nContinue Execution?",
                 locstr, val);

        choice = MessageBox(hRunDlg,
                            str,
                            "Breakpoint",
                            MB_ICONEXCLAMATION | MB_YESNO);
        if(choice == IDNO)
          {
          InterlockedExchange(&gEngineStatus, ENGINE_IDLE);
          wParam = 1; //As if clock is lost
          }
        }

      //Post because stop waits for idle, and engine won't get there
      //if message is synchronus
      if(hRunDlg && (wParam == 1 || wParam == 2))
        PostMessage(hRunDlg, WM_COMMAND, IDC_STOP, 0);
      if(hStepDlg && (wParam == 1 || wParam == 2))
        EnableWindow(GetDlgItem(hStepDlg, IDC_STEP), TRUE);
      if(wParam == 1)
        PostMessage(hRunDlg?hRunDlg:hStepDlg, WM_COMMAND, IDC_CLOSE, 0);

      return(0);
      }

    case WM_CLOSE:
      {
      int choice;

      choice = MessageBox(hwnd,
                          "Are you sure you wish to exit the LC2 Simulator?",
                          "Confirm Exit",
                          MB_YESNO | MB_ICONQUESTION);
      if(choice == IDYES)
        DestroyWindow(hwnd);
      return(0);
      }

    case WM_DESTROY:
      {
      DestroyMenu(hMenuPopup);
      DeleteObject(BITMAP_NULL);
      DeleteObject(BITMAP_PCONLY);
      DeleteObject(BITMAP_BPONLY);
      DeleteObject(BITMAP_BPANDPC);
      PostQuitMessage(0);
      return(0);
      }

    default:
      return(DefWindowProc(hwnd, iMsg, wParam, lParam));
    }
}


//Initializes a structure for the open file common dialog
static void InitOpenFile(LPOPENFILENAME opfn, TCHAR *fname, HWND hwnd)
{
  opfn->lStructSize       = sizeof(OPENFILENAME);
  opfn->hwndOwner         = hwnd;
  opfn->hInstance         = NULL;
  opfn->lpstrFilter       = "Object Files (*.obj)\0*.obj\0All Files (*.*)\0*.*\0";
  opfn->lpstrCustomFilter = NULL;
  opfn->nMaxCustFilter    = 0;
  opfn->nFilterIndex      = 0;
  opfn->lpstrFile         = fname;
  opfn->nMaxFile          = _MAX_PATH;
  opfn->lpstrFileTitle    = NULL;
  opfn->nMaxFileTitle     = 0;
  opfn->lpstrInitialDir   = NULL;
  opfn->lpstrTitle        = "Load Object File";
  opfn->Flags             = OFN_PATHMUSTEXIST |
                            OFN_FILEMUSTEXIST |
                            OFN_HIDEREADONLY;
  opfn->nFileOffset       = 0;
  opfn->nFileExtension    = 0;
  opfn->lpstrDefExt       = ".obj";
  opfn->lCustData         = 0L;
  opfn->lpfnHook          = NULL;
  opfn->lpTemplateName    = NULL;
}

//Window subclassing.  Trap some list box messages
//to update menu options and to prevent multiple
//selections in the various listboxes.
static LRESULT CALLBACK ListBoxProc(HWND hwnd, UINT iMsg,
                                    WPARAM wParam, LPARAM lParam)
{
  int i;

  switch(iMsg)
    {
    case WM_KEYDOWN:
      //Simulate double click with enter
      if(LOWORD(wParam) == VK_RETURN)
        SendMessage(hwndSim, WM_COMMAND, MAKEWPARAM(0, LBN_DBLCLK), (LPARAM)hwnd);
      return(0);

    case WM_KILLFOCUS:
      EnableMenuItem(GetMenu(hwndSim), IDM_SIMULATE_BPTOGGLE,
                     MF_DISABLED | MF_GRAYED | MF_BYCOMMAND);
      EnableMenuItem(hMenuPopup, IDM_SIMULATE_BPTOGGLE,
                     MF_DISABLED | MF_GRAYED | MF_BYCOMMAND);
      SendMessage(hwndTB, TB_ENABLEBUTTON, IDM_SIMULATE_BPTOGGLE, FALSE);

      EnableMenuItem(GetMenu(hwndSim), IDM_SIMULATE_SETPC,
                     MF_DISABLED | MF_GRAYED | MF_BYCOMMAND);
      EnableMenuItem(hMenuPopup, IDM_SIMULATE_SETPC,
                     MF_DISABLED | MF_GRAYED | MF_BYCOMMAND);
      SendMessage(hwndTB, TB_ENABLEBUTTON, IDM_SIMULATE_SETPC, FALSE);
      break;

    case WM_SETFOCUS:
      for(i=0;i<4;i++)
        if(hwnd != hwndLB[i])
          SendMessage(hwndLB[i], LB_SETCURSEL, (WPARAM)(-1), 0);

      //Activate and deactivate memory specific options when focus changes
      if(hwnd == hwndLB[0])
        {
        EnableMenuItem(GetMenu(hwndSim), IDM_SIMULATE_BPTOGGLE,
                       MF_ENABLED | MF_BYCOMMAND);
        EnableMenuItem(hMenuPopup, IDM_SIMULATE_BPTOGGLE,
                       MF_ENABLED | MF_BYCOMMAND);
        SendMessage(hwndTB, TB_ENABLEBUTTON, IDM_SIMULATE_BPTOGGLE, TRUE);

        EnableMenuItem(GetMenu(hwndSim), IDM_SIMULATE_SETPC,
                       MF_ENABLED | MF_BYCOMMAND);
        EnableMenuItem(hMenuPopup, IDM_SIMULATE_SETPC,
                       MF_ENABLED | MF_BYCOMMAND);
        SendMessage(hwndTB, TB_ENABLEBUTTON, IDM_SIMULATE_SETPC, TRUE);
        }
      break; //Still need to call DefWindowProc for highlighting

    case WM_RBUTTONUP:
      {
      POINT p;

      //Set selection to right clicked line
      SendMessage(hwnd, WM_LBUTTONDOWN, wParam, lParam);

      p.x = LOWORD(lParam);
      p.y = HIWORD(lParam);
      ClientToScreen(hwnd, &p);

      TrackPopupMenu(hMenuPopup, TPM_RIGHTBUTTON, p.x, p.y, 0, hwnd, NULL);
      return(0);
      }

    case WM_COMMAND:
      if(!HIWORD(wParam)) //From the popup menu
        {
        //Translate SetValue to a double click
        if(LOWORD(wParam) == IDM_SIMULATE_SETVAL)
          SendMessage(hwndSim, WM_COMMAND,
                      MAKEWPARAM(0, LBN_DBLCLK), (LPARAM)hwnd);
        else
          SendMessage(hwndSim, iMsg, wParam, lParam);
        return(0);
        }
      break;
    }

  for(i=0;i<4;i++)
    if(hwnd == hwndLB[i])
      return(CallWindowProc((WNDPROC)OrigProc[i], hwnd, iMsg, wParam, lParam));
  return(0);  //Should never be called
}

//Determines whether the string indicates
//a valid storage location.  1 if it is,
//otherwise 0.  The location constant
//is placed in pconst.
int isValidLoc(LPTSTR str, STORAGE *pconst)
{
  BITS temp;
  int rval;

  if(!lstrcmp(str, "R0"))
    {
    *pconst = R0;
    return(1);
    }
  if(!lstrcmp(str, "R1"))
    {
    *pconst = R1;
    return(1);
    }
  if(!lstrcmp(str, "R2"))
    {
    *pconst = R2;
    return(1);
    }
  if(!lstrcmp(str, "R3"))
    {
    *pconst = R3;
    return(1);
    }
  if(!lstrcmp(str, "R4"))
    {
    *pconst = R4;
    return(1);
    }
  if(!lstrcmp(str, "R5"))
    {
    *pconst = R5;
    return(1);
    }
  if(!lstrcmp(str, "R6"))
    {
    *pconst = R6;
    return(1);
    }
 if(!lstrcmp(str, "R7"))
    {
    *pconst = R7;
    return(1);
    }
  if(!lstrcmp(str, "PC"))
    {
    *pconst = PC;
    return(1);
    }
  if(!lstrcmp(str, "IR"))
    {
    *pconst = IR;
    return(1);
    }
  if(!lstrcmp(str, "CC"))
    {
    *pconst = CC;
    return(1);
    }

  rval = isValidVal(str, &temp); //check memory
  if(rval)
    *pconst = temp;
  return(rval);
}

//Determines whether the given value is in the
//storage range of the lc2.  Returns 1 if it
//is, otherwise 0.  The binary value is placed
//in val.
int isValidVal(LPTSTR str, BITS *val)
{
  int offset = 0, rval, temp;

  //Check for hex
  if(str[0] == 'X')
    offset = 1;
  else if(str[0] == '0' && str[1] == 'X')
    offset = 2;

  if(offset)
    {
    if(lstrlen(str) > offset)
      {
      rval = sscanf(str+offset, "%X", &temp);
      *val = (BITS)(temp & 0x0FFFF);
      }
    else
      rval = 0;
    }
  else
    {
    rval = sscanf(str, "%d", &temp);  //need temp storage for neg. #'s.
    if(temp > MAX_SIGNED_MAG || temp < MIN_SIGNED_MAG)
      return(0);
    else
      *val = (BITS)(temp & 0x0FFFF);
    }

  if(rval)
    return(1);
  else
    return(0);
}

/*
  Determines if a location and value are consistent
  and valid.  Places the binary form in given pointers.
  String values are altered to remove extra white space.
  Return Values:
    0 - Valid
    1 - invalid location
    2 - invalid value
    3 - invalid condition code
*/
int ValidateValues(LPTSTR locstr, LPTSTR valstr, STORAGE *loc, BITS *val)
{
  int i,len;

  //Get rid or trailing spaces
  len = lstrlen(locstr);
  for(i=len-1; i>=0; i--)
    if(locstr[i] == ' ')
      locstr[i] = '\0';
    else
      break;
  len = lstrlen(valstr);
  for(i=len-1; i>=0; i--)
    if(valstr[i] == ' ')
      valstr[i] = '\0';
    else
      break;

  //Convert strings to uppercase
  CharUpper(locstr);
  CharUpper(valstr);

  if(!isValidLoc(locstr, loc))
    return(1);

  if(*loc == CC)
    if(lstrlen(valstr) == 1)
      switch(valstr[0])
        {
        case 'N':
        case 'n':
          *val = NCC;
          break;
        case 'Z':
        case 'z':
          *val = ZCC;
          break;
        case 'P':
        case 'p':
          *val = PCC;
          break;
        default:
          return(3);
        }
    else
      return(3);
  else if(!isValidVal(valstr, val))
    return(2);
  return(0);
}

//Converts a register constant to a string
//for use in dialog boxes.  str must contain
//sufficient space to hold the output.
void RegisterConstToStr(STORAGE loc, LPTSTR str)
{
  switch(loc)
    {
    case R0:
      lstrcpy(str, "R0");
      break;
    case R1:
      lstrcpy(str, "R1");
      break;
    case R2:
      lstrcpy(str, "R2");
      break;
    case R3:
      lstrcpy(str, "R3");
      break;
    case R4:
      lstrcpy(str, "R4");
      break;
    case R5:
      lstrcpy(str, "R5");
      break;
    case R6:
      lstrcpy(str, "R6");
      break;
    case R7:
      lstrcpy(str, "R7");
      break;
    case PC:
      lstrcpy(str, "PC");
      break;
    case IR:
      lstrcpy(str, "IR");
      break;
    case CC:
      lstrcpy(str, "CC");
      break;
    default:
      wsprintf(str, "x%04X", loc);
      break;
    }
}

//Generate string will generate a string for the
//memory display.  str must contains sufficient
//allocated space.
//Only displays first 8 char's of label.  Doesn't use #define for 8 yet
static void GenerateString(STORAGE loc, LPTSTR str)
{
  BITS val;
  int temp;
  char cc;
  TCHAR opcode[6], args[15+1];
  char label[MAX_LABEL_LENGTH];

  //Generate opcode string
  lc2.GetValue(loc, &val);

  if(loc < 0)  //Register
    {
    RegisterConstToStr(loc, opcode);
    temp = val;
    if(loc != CC)
      wsprintf(str, "%-2s  x%04X  %d", opcode, temp, temp);
    else
      {
      if(temp == NCC)
        cc = 'N';
      else if(temp == ZCC)
        cc = 'Z';
      else
        cc = 'P';
      wsprintf(str, "%-2s  %c", opcode, cc);
      }
    }
  else  //Memory
    {
    GetOpcodeSTR(val, opcode);

    //Make arg string
    switch(OPCODE(val))
      {
      case ADD:
      case AND:
        if(IMMVAL(val))
          wsprintf(args, "R%d, R%d, x%04X", DR(val), SR1(val), IMM5(val));
        else
          wsprintf(args, "R%d, R%d, R%d", DR(val), SR1(val), SR2(val));
        break;

      case BR:
      case JSR:
        symtble.GetLabel(PC6(loc+1)+PGOFFSET9(val), label);
        if(label[0])
          label[8] = '\0';
        else
          wsprintf(label, "x%04X", PC6(loc+1)+PGOFFSET9(val));
        wsprintf(args, "%s", label);
        break;

      case JSRR:
        wsprintf(args, "R%d, x%04X", BASER(val), INDEX6(val));
        break;

      case LEA:
        symtble.GetLabel(PC6(loc+1)+PGOFFSET9(val), label);
        if(label[0])
          label[8] = '\0';
        else
          wsprintf(label, "x%04X", PC6(loc+1)+PGOFFSET9(val));
        wsprintf(args, "R%d, %s", DR(val), label);
        break;

      case LD:
      case LDI:
        symtble.GetLabel(PC6(loc+1)+PGOFFSET9(val), label);
        if(label[0])
          label[8] = '\0';
        else
          wsprintf(label, "x%04X", PC6(loc+1)+PGOFFSET9(val));
        wsprintf(args, "R%d, %s", DR(val), label);
        break;

      case LDR:
      case STR:
        wsprintf(args, "R%d, R%d x%04X", DR(val), BASER(val), INDEX6(val));
        break;

      case NOT:
        wsprintf(args, "R%d, R%d", DR(val), SR1(val));
        break;

      case ST:
      case STI:
        symtble.GetLabel(PC6(loc+1)+PGOFFSET9(val), label);
        if(label[0])
          label[8] = '\0';
        else
          wsprintf(label, "x%04X", PC6(loc+1)+PGOFFSET9(val));
        wsprintf(args, "R%d, %s", SR(val), label);
        break;

      case TRAP:
        switch(TRAPVECT8(val))
          {
          case 0x20:
            lstrcpy(args, "GETC");
            break;
          case 0x21:
            lstrcpy(args, "OUT");
            break;
          case 0x22:
            lstrcpy(args, "PUTS");
            break;
          case 0x23:
            lstrcpy(args, "IN");
            break;
          case 0x24:
            lstrcpy(args, "PUTSP");
            break;
          case 0x25:
            lstrcpy(args, "HALT");
            break;
          default:
            wsprintf(args, "x%02X", TRAPVECT8(val));
          }
        break;

      default:
        strcpy(args, "");
        break;
      }

    //Get the label and truncate it for the display
    symtble.GetLabel(loc, label);
    label[8] = '\0';

    wsprintf(str,
             "x%04X  %d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d  x%04X  %-8s  %-5s  %-15s",
             loc,
             (val & 0x08000) >> 15,
             (val & 0x04000) >> 14,
             (val & 0x02000) >> 13,
             (val & 0x01000) >> 12,
             (val & 0x00800) >> 11,
             (val & 0x00400) >> 10,
             (val & 0x00200) >> 9,
             (val & 0x00100) >> 8,
             (val & 0x00080) >> 7,
             (val & 0x00040) >> 6,
             (val & 0x00020) >> 5,
             (val & 0x00010) >> 4,
             (val & 0x00008) >> 3,
             (val & 0x00004) >> 2,
             (val & 0x00002) >> 1,
             (val & 0x00001),
             val,
             label,
             opcode,
             args);
    }
}

//Generates the mnemonic string for a given
//opcode.  The string is placed in opcode.
static void GetOpcodeSTR(BITS val, LPTSTR opcode)
{
  switch(OPCODE(val))
    {
    case ADD:
      lstrcpy(opcode,"ADD");
      break;
    case AND:
      lstrcpy(opcode,"AND");
      break;
    case BR:
      {
      int cc;

      lstrcpy(opcode,"BR");
      cc = CONDCODES(val);
      if(NBIT(cc))
        lstrcat(opcode, "N");
      if(ZBIT(cc))
        lstrcat(opcode, "Z");
      if(PBIT(cc))
        lstrcat(opcode, "P");
      if(!cc)
        lstrcat(opcode, "NOP");
      break;
      }
    case JSR:
      if(LINK(val))
        lstrcpy(opcode,"JSR");
      else
        lstrcpy(opcode,"JMP");
      break;
    case JSRR:
      if(LINK(val))
        lstrcpy(opcode,"JSRR");
      else
        lstrcpy(opcode,"JMPR");
      break;
    case LD:
      lstrcpy(opcode,"LD");
      break;
    case LDI:
      lstrcpy(opcode,"LDI");
      break;
    case LDR:
      lstrcpy(opcode,"LDR");
      break;
    case LEA:
      lstrcpy(opcode,"LEA");
      break;
#ifdef OLD_INSTRUCTION_SET
    case NOP:
      lstrcpy(opcode,"NOP");
      break;
#else
    case RTI:
      lstrcpy(opcode,"RTI");
      break;
#endif
    case NOT:
      lstrcpy(opcode,"NOT");
      break;
    case RET:
      lstrcpy(opcode,"RET");
      break;
    case ST:
      lstrcpy(opcode,"ST");
      break;
    case STI:
      lstrcpy(opcode,"STI");
      break;
    case STR:
      lstrcpy(opcode,"STR");
      break;
    case TRAP:
      lstrcpy(opcode,"TRAP");
      break;
    default:
      lstrcpy(opcode,"");
      break;
    }
}

//Looks up the location of the PC and current
//breakpoints to determine the appropriate
//image to display in the bp column for a 
//given location.
static HBITMAP SelectBPImage(STORAGE loc)
{
  BITS pc;
  STORAGE *locations;
  BITS *values;
  int numBP;
  int flags = 0;
  int i;

  //Check for PC
  lc2.GetValue(PC, &pc);
  if(loc == pc)
    flags = 1;

  //Check for Breakpoints
  numBP = lc2.NumBreakPoints();
  if(numBP)
    {
    if((locations = new STORAGE[numBP]) == NULL)
      return(NULL);
    if((values = new BITS[numBP]) == NULL)
      {
      delete [] locations;
      return(NULL);
      }
    lc2.ListBreakPoints(locations, values);
    for(i=0;i<numBP;i++)
      if(locations[i] == PC && values[i] == loc)
        {
        flags |= 2;
        break;
        }
    delete [] locations;
    delete [] values;
    }

  switch(flags)
    {
    case 0:
      return(BITMAP_NULL);
    case 1:
      return(BITMAP_PCONLY);
    case 2:
      return(BITMAP_BPONLY);
    case 3:
      return(BITMAP_BPANDPC);
    }

  return(NULL);
}

//Given a location, returns the hwnd to the
//listbox that would contain it.
static HWND LocationToHwnd(STORAGE loc)
{
  switch(loc)
    {
    case R0:
    case R1:
    case R2:
    case R3:
      return(hwndLB[1]);
    case R4:
    case R5:
    case R6:
    case R7:
      return(hwndLB[2]);
    case PC:
    case IR:
    case CC:
      return(hwndLB[3]);
    default:
      return(hwndLB[0]);
    }
}

//Determines the offset of a given location in the list
//box that contains it.
int LocationToOffset(STORAGE loc, STORAGE startAddress, int lines)
{
  switch(loc)
    {
    case R0:
    case R4:
    case PC:
      return(0);
    case R1:
    case R5:
    case IR:
      return(1);
    case R2:
    case R6:
    case CC:
      return(2);
    case R3:
    case R7:
      return(3);
    default:
      if(loc < startAddress || loc >= startAddress + lines)
        return(-1);
      return(loc - startAddress);
    }
}

//Converts an hwnd and offset to the location it displays.
static STORAGE HwndOffsetToLocation(HWND hwnd, int offset, STORAGE startAddress)
{
  if(hwnd == hwndLB[1])
    switch(offset)
      {
      case 0: return(R0);
      case 1: return(R1);
      case 2: return(R2);
      case 3: return(R3);
      }
  else if(hwnd == hwndLB[2])
    switch(offset)
      {
      case 0: return(R4);
      case 1: return(R5);
      case 2: return(R6);
      case 3: return(R7);
      }
  else if(hwnd == hwndLB[3])
    switch(offset)
      {
      case 0: return(PC);
      case 1: return(IR);
      case 2: return(CC);
      }
  return(startAddress + offset);
}
