/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman
  
  This file declares the breakpoint manager.
  It is included automatically with the engine
  and does not need to be referenced separately.
*/

#ifndef _bpman_h_
#define _bpman_h_

#include "lc2.h"
#include "lc2err.h"

//Forward Declaration
class engine;

class BPManager
{
  public:
    //Default Constructor.  The BreakPoint manager must
    //be initialized to an engine.
    BPManager(void);

    //Destructor frees memory associated with the manager
    virtual ~BPManager(void);

    //Add will add a breakpoint to the LC2
    //Return Values
    //  S_OK
    //  E_INSUFFICIENT_MEMORY
    //  E_INVALID_ARG
    RESULT Add(const STORAGE location, const BITS value);

    //Remove will remove a specific breakpoint
    //Return Values
    //  S_OK
    //  E_ENTRY_NOT_FOUND
    //  E_INVALID_ARG
    RESULT Remove(const STORAGE location, const BITS value);

    //Clear will remove all breakpoints
    void Clear(void);

    //List will output all the breakpoints.  The pointers passed in
    //must point to sufficient memory to hold all the breakpoint
    //values.  If a parameter is NULL, that value is skipped.
    void List(STORAGE *locations, BITS *values) const;

    //Number will return the number of active breakpoints.
    int Number(void) const;

    //OnActive will return the index of the active breakpoint if the engine is
    //sitting on an active breakpoint, otherwise -1.  Parameters will contain the
    //values for the breakpoint, if they are non NULL.
    int OnActive(engine *lc2, STORAGE *loc, BITS *val);

  protected:
    //The basic components of a breakpoint
    typedef struct {
      STORAGE location; //Register or address to check
      BITS value;       //Value to break on
      char valid;       //Determines if this struct contains an active bp
      } BPnode_t;

    //Class scoped constant.  The number of entrys to initally create
    enum {INITIAL_ALLOC = 10};

    //Grow will double the size of the breakpoint structure.
    //Return Values:
    //  S_OK
    //  E_INSUFFICIENT_MEMORY
    RESULT Grow(void);

  private:
    //The actual array of breakpoints (dynamically growing array)
    BPnode_t *breakpoints;
    unsigned int cntBP;
    unsigned int allocatedBP;

    //The copy constructor and operator= are disabled.  The BPManager
    //should not be copied: it is too large.  No definition is provided
    //for these functions.
    BPManager(const &BPManager);
    BPManager operator=(const &BPManager);
};

#endif