/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman

  This file is the starting point for the LC2 simulator.
  It contains the entry point for both the main and engine
  thread.  It also contains the OS related functions.

  The preprocessor definition OLD_INSTRUCTION_SET can be defined
  to use the simulator without the new RTI instruction.  This results
  in the following changes:
    BR becomes opcode 8000
    NOP becomes opcode 0000
    RTI is removed
*/

#include <windows.h>
#include <commctrl.h>
#include <string.h>
#include "main.h"
#include "dlgprocs.h"
#include "create.h"
#include "gui_cons.h"
#include "simulate.h"
#include "lc2.h"
#include "engine.h"
#include "resource.h"

//Local prototypes
static DWORD WINAPI EngineMain(LPVOID pParams);
static void GoIdle(void);

//Operating System specific variables/declarations
#define NUM_OSFILES 7
#define INFINITE_LOOP_WARN 10000
static char *osFiles[] = {"ivtable.obj",
                          "halt.obj",
                          "getc.obj",
                          "promptgetc.obj",
                          "putc.obj",
                          "puts.obj",
                          "putspacked.obj"};
#define DIRLENGTH (_MAX_PATH + 1) //Length of directory name + 1
char gPath[DIRLENGTH];

//Font specific globals
int gfontWidth, gfontHeight;
HFONT ghFont = NULL;
int gfontPT = 9;

//Misc. Globals
engine lc2;
symtable symtble;
HWND hwndConsole, hwndSim;
HANDLE hEngineThread;
long gEngineStatus, gEngineInstructions, gExecuted=0;
BITS gLastUserPC = DEFAULT_START_LOC;

//The main entry point for the application.
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   PSTR szCmdLine, int iCmdShow)
{
  MSG msg;
  HACCEL hAccel;
  DWORD iTID;

  GetCurrentDirectory(DIRLENGTH-1, gPath);

  InitializeCriticalSection(&ConsoleUpdateCS);
  InitCommonControls();

  lc2.Init();
  LoadOS(NULL);
  lc2.SetValue(PC, DEFAULT_START_LOC);

  InterlockedExchange(&gEngineStatus, ENGINE_IDLE);
  InterlockedExchange(&gEngineInstructions, 0);

  //Use initial value as default
  SetFont(gfontPT);

  RegisterClasses(hInstance, SimProc, ConsoleProc);
  CreateWindows(hInstance, iCmdShow);

  hAccel = LoadAccelerators(hInstance, MAKEINTRESOURCE(SimMenuAccel));

  //Startup the Engine thread
  hEngineThread = CreateThread(NULL, 0, EngineMain,
                               hInstance, CREATE_SUSPENDED, &iTID);
  SetThreadPriority(hEngineThread, THREAD_PRIORITY_LOWEST);

  //Message Loop
  while(GetMessage(&msg, NULL, 0, 0))
    if(!TranslateAccelerator(hwndSim, hAccel, &msg))
      {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
      }

  InterlockedExchange(&gEngineStatus, ENGINE_OFF);
  ResumeThread(hEngineThread);
  while(gEngineStatus != ENGINE_EXIT)
    Sleep(0);
  DeleteObject(ghFont);
  DeleteCriticalSection(&ConsoleUpdateCS);
  return(msg.wParam);
}

//This is the entry point for the engine thread which handles
//all execution of LC2 instructions.  It is active for the
//duration of the program, though is suspended when not needed.
static DWORD WINAPI EngineMain(void *pParams)
{
  RESULT r;
  BITS pcTarget=0, pcCurrent, ir, pc;
  int trapStart=1;
  HINSTANCE hInstance;

  hInstance = (HINSTANCE)(pParams);

  while(gEngineStatus != ENGINE_OFF)
    if(gEngineStatus == ENGINE_RUNNING || gEngineStatus == ENGINE_TRAP)
      {
      //Check for trap
      lc2.GetValue(PC, &pcCurrent);
      lc2.GetValue(pcCurrent, &ir);
      if(gEngineStatus == ENGINE_TRAP)
        {
        if(trapStart && OPCODE(ir) == TRAP)
          {
          pcTarget = (BITS)(pcCurrent + 1);
          trapStart = 0;
          }
        }
      else
        trapStart = 1;

      lc2.GetValue(PC, &pc);
      r = lc2.Execute(1);
      if(pc >= MIN_USER_MEM_LOC && pc <= MAX_USER_MEM_LOC)
        {
        gLastUserPC = pc;
        InterlockedIncrement(&gExecuted);
        }
#ifndef REALISTIC_CONSOLE_REFRESH
      else //This clause is purely for optimzation purposes
        {
        GuiConsoleUpdate(hwndConsole,0,0,0);
        }
#endif

      //Infinite loop warning
      if(gWarnLargeExecution && !(gExecuted%INFINITE_LOOP_WARN) &&
         gExecuted && gEngineInstructions == EXECUTE_CONTINUOUS)
        DialogBox(hInstance, "InfiniteLoopDlg", hRunDlg,
                  (DLGPROC)InfiniteLoopDlgProc);
    
      //Invalid instruction warning
      if(r == E_INVALID_INSTRUCTION)
        {
        TCHAR str[200];

        wsprintf(str, "An RTI instruction was just executed at x%04X.\n", pc);
        lstrcat(str, "RTI is not supported and will act as a NOP.\n");
        lstrcat(str, "Do you wish to continue execution?");
        if(MessageBox(hwndSim, str, "Unsupported Instruction",
                      MB_YESNO | MB_ICONERROR) == IDYES)
          r = S_SUCCESS;
        }

      //Inform main thread of status
      if(r == S_HOLD_BP)
        SendMessage(hwndSim, LC2_HOLD, 0, 0);
      else if(r != S_SUCCESS)
        SendMessage(hwndSim, LC2_HOLD, 1, 0);

      lc2.GetValue(PC, &pcCurrent);

      //Determine end of trap
      if(!trapStart && pcTarget == pcCurrent)
        trapStart = 1;

      //Update Globals
      //Decrement if not continuous and either not trap or (trap and pc's match)
      if(gEngineInstructions != EXECUTE_CONTINUOUS && trapStart)
        InterlockedDecrement(&gEngineInstructions);

      if((r != S_SUCCESS && r != S_HOLD_BP) || //no clock, or done executing
         !gEngineInstructions)                 //will also idle on invalid instr.
        GoIdle();
      }
    else
      GoIdle();

  InterlockedExchange(&gEngineStatus, ENGINE_EXIT);

  return(0);
}

//Called when the engine in suspending itself.
static void GoIdle(void)
{
  InterlockedExchange(&gEngineStatus, ENGINE_IDLE);
  SendMessage(hwndSim, LC2_HOLD, 2, 0);
  SuspendThread(hEngineThread);
}

//This function loads the operating system.  It is expected that 
//the object files be in the same location as the programs
//working directory.
int LoadOS(HWND hwnd)
{
  char file[DIRLENGTH+20];  //Enough to accomodate file name
  char list[(DIRLENGTH+20)*NUM_OSFILES];
  char output[250];
  int i, success=1;

  list[0] = '\0';
  for(i=0;i<NUM_OSFILES;i++)
    {
    wsprintf(file, "%s\\%s", gPath, osFiles[i]);
    if(lc2.LoadProgram(file) != S_SUCCESS)
      {
      strcat(list, osFiles[i]);
      strcat(list, "\n");
      success = 0;
      }
    }

  if(!success)
    {
    wsprintf(output,
             "Unable to load:\n\n%s\nSome trap instructions may execute incorrectly.",
             list);
    MessageBox(hwnd, output, "Load Failure", MB_OK | MB_ICONERROR);
    }
  return(success);
}

//Sets the variables related to the font size.  This function
//does not redraw any displays.
void SetFont(int pointsize)
{
  HDC hDC;
  TEXTMETRIC tm;

  hDC = GetDC(NULL);

  if(ghFont)
    DeleteObject(ghFont);

  gfontPT = pointsize;
  ghFont = CreateFont(-MulDiv(pointsize,GetDeviceCaps(hDC,LOGPIXELSY),72),
                      0,
                      0, 0,
                      FW_MEDIUM,
                      FALSE, FALSE, FALSE,
                      ANSI_CHARSET,
                      OUT_DEFAULT_PRECIS,
                      CLIP_DEFAULT_PRECIS,
                      DEFAULT_QUALITY,
                      FF_MODERN,
                      "Courier New");

  //Set globals
  SelectObject(hDC, ghFont);
  GetTextMetrics(hDC, &tm);
  gfontWidth = tm.tmAveCharWidth;
  gfontHeight = tm.tmHeight;

  ReleaseDC(NULL, hDC);
}
