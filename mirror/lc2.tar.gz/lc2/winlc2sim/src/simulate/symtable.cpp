/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman

  This file implements the functions needed for the symbol table
  class.
*/

#include "symtable.h"
#include "string.h"
#include "stdio.h"

//Default Constructor initializes internal variables.
symtable::symtable(void)
{
   last_indexed = NULL;
   last_index = 0;
   entries = 0;
   head_address = NULL;
   head_label = NULL;
}

//Destructor frees all memory associated with the object.
symtable::~symtable(void)
{
  Clear();
}

//Load will load a symbol table from a given file.
//Return Values
//  S_OK
//  E_FILE_NOT_FOUND
//  E_FILE_IO
RESULT symtable::Load(const char *fname)
{
  FILE *fp;
  char label[MAX_LABEL_LENGTH+1], junk[80];;
  int value, i, rval;

  fp = fopen(fname, "r");
  if(!fp)
    return(E_FILE_NOT_FOUND);

  //Skip the first four lines (headers)
  for(i=0;i<4;i++)
    fgets(junk, 80, fp);

  while((rval = fscanf(fp, " %*c%*c%s %x", label, &value)) == 2)
    Add(label, (BITS)value);

  if(rval == 1)
    return(E_FILE_IO);

  fclose(fp);
  return(S_SUCCESS);
}

//Add will add an entry to the symbol table.
//Possible Return Values:
//  S_SUCCESS
//  E_ENTRY_EXISTS
//  E_INVALID_ARG (string too long)
//  E_INSUFFICIENT_MEMORY
RESULT symtable::Add(const char *label, BITS address)
{
  node_t *newnode, *trav;
  int length;

  //Verify label is not too long
  if((length = strlen(label)) > MAX_LABEL_LENGTH)
    return(E_INVALID_ARG);

  //Verify label doesn't already exist.
  if(GetAddress(label, NULL) != E_ENTRY_NOT_FOUND)
    return(E_ENTRY_EXISTS);

  //Create the new entry
  if((newnode = new node_t) == NULL)
    return(E_INSUFFICIENT_MEMORY);
  if((newnode->label = new char[length + 1]) == NULL)
    {
    delete newnode;
    return(E_INSUFFICIENT_MEMORY);
    }

  //Insert the data
  strcpy(newnode->label, label);
  newnode->address = address;

  //Insert the node into the list
  if(!entries)
    {
    head_address = head_label = newnode;
    newnode->next_address = newnode->next_label = NULL;
    }
  else
    {
    //First insert by label
    if(strcmp(newnode->label, head_label->label) < 0) //new head
      {
      newnode->next_label = head_label;
      head_label = newnode;
      }
    else
      {
      trav = head_label;
      while(trav->next_label &&
            strcmp(newnode->label, trav->next_label->label) > 0)
        trav = trav->next_label;
      newnode->next_label = trav->next_label;
      trav->next_label = newnode;
      }

    //Now insert by address
    if(newnode->address > head_address->address) //new head
      {
      newnode->next_address = head_address;
      head_address = newnode;
      }
    else
      {
      trav = head_address;
      while(trav->next_address &&
            newnode->address < trav->next_address->address)
        trav = trav->next_address;
      newnode->next_address = trav->next_address;
      trav->next_address = newnode;
      }
    }

  //Reset the index variables
  last_indexed = NULL;
  last_index = 0;

  entries++;

  return(S_SUCCESS);
}

//Clear will remove all entries from the symbol table.
void symtable::Clear(void)
{
  unsigned int i;
  node_t *successor;

  for(i=0;i<entries;i++)
    {
    successor = head_label->next_label;
    DeleteNode(head_label);
    head_label = successor;
    }

  last_indexed = NULL;
  last_index = 0;
  entries = 0;
  head_address = NULL;
  head_label = NULL;
}

//GetAddress will lookup a label in the table and return
//its associated address.
//Return Values:
//  S_SUCCESS
//  E_ENTRY_NOT_FOUND
RESULT symtable::GetAddress(const char *label, BITS *address) const
{
  node_t *trav;
  int rval=1;

  trav = head_label;
  while(trav && (rval = strcmp(label, trav->label)) > 0)
    trav = trav->next_label;

  if(rval)  //Entry not found
    return(E_ENTRY_NOT_FOUND);

  if(address)
    *address = trav->address;
  return(S_SUCCESS);
}

//GetLabel will lookup a label in the table and return
//its associated label.  The string must already be
//allocated with sufficient space to hold the label.
//Return Values:
//  S_SUCCESS
//  E_ENTRY_NOT_FOUND
RESULT symtable::GetLabel(const STORAGE address, char *label) const
{
  node_t *trav;

  trav = head_address;
  while(trav && address < trav->address)
    trav = trav->next_address;

  if(!trav || address != trav->address)  //Entry not found
    {
    strcpy(label, "");
    return(E_ENTRY_NOT_FOUND);
    }

  if(label)
    strcpy(label, trav->label);
  return(S_SUCCESS);
}

//GetEntry will return the label and address for an entry, when
//specified by index.  Indexes start at 0.  The string must be
//pre-allocated.
//Return Values:
//  S_SUCCESS
//  E_ENTRY_NOT_FOUND
RESULT symtable::GetEntry(unsigned int index,
                          char *label, BITS *address) const
{
  int diff;
  node_t *trav;

  if(index >= entries)  //index out of range
    return(E_ENTRY_NOT_FOUND);

  //Set up
  if(last_indexed && last_index <= index)
    {
    diff = index - last_index;
    trav = last_indexed;
    }
  else
    {
    diff = index;
    trav = head_address;
    }

  //Get node
  while(diff)
    {
    trav = trav->next_address;
    diff--;
    }

  //Return values
  if(label)
    strcpy(label, trav->label);
  if(address)
    *address = trav->address;
  return(S_SUCCESS);
}

//NumEntries will return the number of entries in the symbol table.
unsigned int symtable::NumEntries(void) const
{
  return(entries);
}

//DeleteNode will delete all memory contained in a node,
//including the node itself.
void symtable::DeleteNode(node_t *node)
{
  delete [] node->label;
  delete node;
}
