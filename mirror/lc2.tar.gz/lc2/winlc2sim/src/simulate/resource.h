//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by main.rc
//
#define IDM_FILE_LOAD                   1
#define IDM_FILE_REINIT                 2
#define IDM_FILE_CLEARCONS              3
#define IDM_FILE_EXIT                   4
#define IDM_OPTIONS_PC                  11
#define IDM_OPTIONS_TRAPS               12
#define IDM_OPTIONS_LOOP                13
#define IDM_SIMULATE_RUN                21
#define IDM_SIMULATE_STEP               22
#define IDM_SIMULATE_SETVAL             23
#define IDM_SIMULATE_SETPC              24
#define IDM_SIMULATE_BPADD              25
#define IDM_SIMULATE_BPTOGGLE           26
#define IDM_SIMULATE_BPREMOVE           27
#define IDM_DISPLAY_JUMP                31
#define IDM_DISPLAY_FONT                32
#define IDM_HELP_ABOUT                  41
#define IDI_APP                         101
#define IDB_TB_BTNS                     103
#define IDB_BPANDPC                     111
#define IDB_PCONLY                      112
#define IDB_NULL                        113
#define IDB_BPONLY                      114
#define IDM_SimMenu                     115
#define IDM_Popup                       118
#define SimMenuAccel                    150
#define IDC_ChkShow                     201
#define ID_YES                          202
#define ID_NO                           203
#define IDC_ICN                         204
#define IDC_LBLDESC                     205
#define IDC_LBLLOC                      206
#define IDC_LBLVALUE                    207
#define IDC_COMBOLOC                    208
#define IDC_EDITVALUE                   209
#define IDC_CLEAR                       210
#define IDC_LB                          211
#define IDC_ALL                         212
#define IDC_TEXT                        213
#define IDC_PT8                         214
#define IDC_PT9                         215
#define IDC_PT10                        216
#define IDC_PT11                        217
#define IDC_PT12                        218
#define IDC_PC                          219
#define IDC_STOP                        220
#define IDC_CLOSE                       221
#define IDC_START                       222
#define IDC_STEP                        223
#define IDC_LBL                         224
#define IDC_EDITLOC                     225

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        119
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
