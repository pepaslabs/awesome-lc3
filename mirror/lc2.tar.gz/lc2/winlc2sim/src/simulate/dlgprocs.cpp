/*
  Copyright 1999 Brian J. Hartman and Matt Postiff
  Written by Brian J. Hartman

  This file contains the dialog procedures for all dialog boxes.
*/

#include <windows.h>
#include "main.h"
#include "lc2.h"
#include "simulate.h"
#include "engine.h"
#include "dlgprocs.h"
#include "create.h"
#include "resource.h"

#define MAX_INPUT 5 //Max input for an edit box

#define NUM_LOC_CONST_STR 12
#define LOC_CONST_STR_PC 0
static TCHAR LOC_CONST_STR[][3] = {"PC",
                                   "x",
                                   "IR",
                                   "CC",
                                   "R0",
                                   "R1",
                                   "R2",
                                   "R3",
                                   "R4",
                                   "R5",
                                   "R6",
                                   "R7"};

BOOL CALLBACK AddBPDlgProc(HWND hwnd,
                           UINT iMsg,
                           WPARAM wParam,
                           LPARAM lParam)
{
  switch(iMsg)
    {
    case WM_INITDIALOG:
      {
      int i;

      SendDlgItemMessage(hwnd, IDC_COMBOLOC, CB_LIMITTEXT, MAX_INPUT, 0);
      SendDlgItemMessage(hwnd, IDC_EDITVALUE, EM_LIMITTEXT, MAX_INPUT, 0);

      for(i=0;i<NUM_LOC_CONST_STR;i++)
        SendDlgItemMessage(hwnd, IDC_COMBOLOC, CB_ADDSTRING, 0, (LPARAM)(LOC_CONST_STR[i]));

      SendDlgItemMessage(hwnd, IDC_COMBOLOC, CB_SETCURSEL, 0, 0);
      SetDlgItemText(hwnd, IDC_EDITVALUE, "x");
      return(TRUE);
      }

    case WM_COMMAND:
      switch(LOWORD(wParam))
        {
        case IDOK:
          {
          TCHAR loc[MAX_INPUT+1];
          TCHAR val[MAX_INPUT+1];
          STORAGE locConst;
          BITS value;

          GetDlgItemText(hwnd, IDC_COMBOLOC, loc, MAX_INPUT+1);
          GetDlgItemText(hwnd, IDC_EDITVALUE, val, MAX_INPUT+1);

          //Input validation
          switch(ValidateValues(loc, val, &locConst, &value))
            {
            case 0: //All is good
              if(lc2.SetBreakPoint(locConst, value) == E_INSUFFICIENT_MEMORY)
                {
                MessageBox(hwnd,
                           "Insufficient Memory.",
                           "Memory Error",
                           MB_OK | MB_ICONERROR);
                break;
                }

              if(locConst == PC)
                SendMessage(hwndSim, WM_MEMREFRESH, value, MAKELPARAM(1,1));
              EndDialog(hwnd, 0);
              break;
            case 1: //Invalid location
              MessageBox(hwnd,
                         "Invalid Location.\n\nThe location can be an address or a register (i.e. R1, PC, x3005)",
                         "Invalid Location",
                         MB_OK | MB_ICONERROR);
              break;
            case 2: //Invalid value
              MessageBox(hwnd,
                         "Invalid value.",
                         "Invalid Value",
                         MB_OK | MB_ICONERROR);
              break;
            case 3:
              MessageBox(hwnd,
                         "Invalid condition code value.",
                         "Invalid Value",
                         MB_OK | MB_ICONERROR);
              break;
            }

          return(TRUE);
          }

        case IDCANCEL:
          EndDialog(hwnd, 0);
          return(TRUE);

        default:
          return(FALSE);
        }

    default:
      return(FALSE);
    }
}


BOOL CALLBACK RemoveBPDlgProc(HWND hwnd,
                              UINT iMsg,
                              WPARAM wParam,
                              LPARAM lParam)
{
  static int num;

  switch(iMsg)
    {
    case WM_INITDIALOG:
      {
      STORAGE *locations;
      BITS *values;
      TCHAR str[14];
      TCHAR loc[6];
      int i;

      num = lc2.NumBreakPoints();
      locations = new STORAGE[num];
      values = new BITS[num];

      if(!locations || !values)
        MessageBox(hwnd,
                       "Insufficient Memory.",
                       "Memory Error",
                       MB_OK | MB_ICONERROR);
      else 
        {
        lc2.ListBreakPoints(locations, values);
        for(i=0;i<num;i++)
          {
          RegisterConstToStr(locations[i], loc);
          wsprintf(str, "%s = x%04X",loc,values[i]);
          SendDlgItemMessage(hwnd, IDC_LB, LB_ADDSTRING, 0, (LPARAM)str);
          }
        }

      delete [] locations;
      delete [] values;
      return(TRUE);
      }

    case WM_COMMAND:
      switch(LOWORD(wParam))
        {
        STORAGE loc;
        BITS val;
        int i, sel, *index;
        int offset;
        TCHAR str[14];

        case IDOK:
          if((index = new int[num]) == NULL)
            MessageBox(hwnd,
                       "Insufficient Memory.",
                       "Memory Error",
                       MB_OK | MB_ICONERROR);
          else
            {
            sel = SendDlgItemMessage(hwnd, IDC_LB, LB_GETSELITEMS,
                                     num, (LPARAM)index);
            for(i=0;i<sel;i++)
              {
              SendDlgItemMessage(hwnd, IDC_LB, LB_GETTEXT,
                                 index[i], (LPARAM)str);
              CharUpper(str);
              if(str[0] == 'X')
                offset = 5;
              else
                offset = 2;
              str[offset] = '\0';
              isValidLoc(str, &loc);
              isValidVal(str+offset+3, &val);
              lc2.ClearBreakPoint(loc, val);
              if(loc == PC)
                SendMessage(hwndSim, WM_MEMREFRESH, val, MAKELPARAM(1,1));
              }
            delete [] index;
            }

          EndDialog(hwnd, 0);
          return(TRUE);

        case IDCANCEL:
          EndDialog(hwnd, 0);
          return(TRUE);

        case IDC_ALL:
          SendDlgItemMessage(hwnd, IDC_LB, LB_SETSEL, TRUE, -1);
          return(TRUE);

        case IDC_CLEAR:
          SendDlgItemMessage(hwnd, IDC_LB, LB_SETSEL, FALSE, -1);
          return(TRUE);

        default:
          return(FALSE);
        }

    default:
      return(FALSE);
    }
}


BOOL CALLBACK SetValueDlgProc(HWND hwnd,
                              UINT iMsg,
                              WPARAM wParam,
                              LPARAM lParam)
{
  switch(iMsg)
    {
    case WM_INITDIALOG:
      {
      int i;
      STORAGE s;
      BITS bits;
      TCHAR loc[MAX_INPUT+1];
      TCHAR value[MAX_INPUT+1];

      SendDlgItemMessage(hwnd, IDC_COMBOLOC, CB_LIMITTEXT, MAX_INPUT, 0);
      SendDlgItemMessage(hwnd, IDC_EDITVALUE, EM_LIMITTEXT, MAX_INPUT, 0);

      for(i=0;i<NUM_LOC_CONST_STR;i++)
        SendDlgItemMessage(hwnd, IDC_COMBOLOC, CB_ADDSTRING, 0, 
                           (LPARAM)(LOC_CONST_STR[i]));

      if(lParam != NULL)
        {
        s = *((STORAGE *)lParam);
        RegisterConstToStr(s, loc);
        lc2.GetValue(s, &bits);
        if(!lstrcmp(loc, "CC"))
          {
          if(bits == NCC)
            lstrcpy(value, "N");
          else if(bits == ZCC)
            lstrcpy(value, "Z");
          else
            lstrcpy(value, "P");
          }
        else
          wsprintf(value, "x%04x", bits);
        SetDlgItemText(hwnd, IDC_COMBOLOC, loc);
        SetDlgItemText(hwnd, IDC_EDITVALUE, value);
        }

      return(TRUE);
      }

    case WM_COMMAND:
      switch(LOWORD(wParam))
        {
        case IDOK:
          {
          TCHAR loc[MAX_INPUT+1];
          TCHAR val[MAX_INPUT+1];
          int locConst;
          BITS value;

          GetDlgItemText(hwnd, IDC_COMBOLOC, loc, MAX_INPUT+1);
          GetDlgItemText(hwnd, IDC_EDITVALUE, val, MAX_INPUT+1);

          //Input validation
          switch(ValidateValues(loc, val, &locConst, &value))
            {
            case 0: //All is good
              lc2.SetValue(locConst, value);
              SendMessage(hwndSim, WM_MEMREFRESH, locConst, MAKELPARAM(0,1));
              EndDialog(hwnd, 0);
              break;
            case 1: //Invalid location
              MessageBox(hwnd,
                         "Invalid Location.\n\nThe location can be an address or a register (i.e. R1, R5, PC, IR)",
                         "Invalid Location",
                         MB_OK | MB_ICONERROR);
              break;
            case 2: //Invalid value
              MessageBox(hwnd,
                         "Invalid value.",
                         "Invalid Value",
                         MB_OK | MB_ICONERROR);
              break;
            case 3:
              MessageBox(hwnd,
                         "Invalid condition code value.",
                         "Invalid Value",
                         MB_OK | MB_ICONERROR);
              break;
            }

          return(TRUE);
          }

        case IDCANCEL:
          EndDialog(hwnd, 0);
          return(TRUE);

        default:
          return(FALSE);
        }

    default:
      return(FALSE);
    }
}

BOOL CALLBACK FontSizeDlgProc(HWND hwnd,
                              UINT iMsg,
                              WPARAM wParam,
                              LPARAM lParam)
{
  switch(iMsg)
    {
    case WM_INITDIALOG:
      CheckRadioButton(hwnd, IDC_PT8, IDC_PT12, IDC_PT8 + gfontPT - 8);
      return(TRUE);

    case WM_COMMAND:
      switch(LOWORD(wParam))
        {
        case IDOK:
          {
          int i;

          for(i=0;i<5;i++)
            if(IsDlgButtonChecked(hwnd, IDC_PT8+i))
              {
              SetFont(8 + i);
              break;
              }

          SendMessage(hwndConsole, WM_SETFONT, (WPARAM)ghFont, 0);
          for(i=0;i<4;i++)
            SendMessage(hwndLB[i],  WM_SETFONT, (WPARAM)ghFont, 0);

          ResizeSimWindow(hwndSim);
          RepositionChildWindows(hwndSim, hwndLB[1], hwndLB[2],
                                 hwndLB[3], hwndLB[0], hwndMemBP,
                                 hwndMemScroll);
          ResizeConsoleWindow(hwndConsole);
          EndDialog(hwnd, 0);
          return(TRUE);
          }

        case IDCANCEL:
          EndDialog(hwnd, 0);
          return(TRUE);

        case BN_CLICKED:
          CheckRadioButton(hwnd, IDC_PT8, IDC_PT12, LOWORD(wParam));
          return(TRUE);

        default:
          return(FALSE);
        }

    default:
      return(FALSE);
    }
}

BOOL CALLBACK RunDlgProc(HWND hwnd,
                         UINT iMsg,
                         WPARAM wParam,
                         LPARAM lParam)
{
  switch(iMsg)
    {
    case WM_INITDIALOG:
      {
      TCHAR str[6];
      BITS pc;

      lc2.GetValue(PC, &pc);
      wsprintf(str, "x%04X", pc);
      SendDlgItemMessage(hwnd, IDC_PC, EM_LIMITTEXT, MAX_INPUT, 0);
      SetDlgItemText(hwnd, IDC_PC, str);
      hRunDlg = hwnd;
      return(TRUE);
      }

    case WM_COMMAND:
      switch(LOWORD(wParam))
        {
        case IDC_START:
          {
          BITS pc;
          TCHAR str[MAX_INPUT+1];
          int istr, i;

          //Verify and set PC
          istr = GetDlgItemText(hwnd, IDC_PC, str, MAX_INPUT+1);
          for(i=istr-1; i>=0; i--)   //Get rid or trailing spaces
            if(str[i] == ' ')
              str[i] = '\0';
            else
              break;
          CharUpper(str);    //Convert location to uppercase

          if(!isValidVal(str, &pc))
            {
            MessageBox(hwnd, "Invalid start location.",
                       "Error", MB_ICONERROR | MB_OK);
            return(TRUE);
            }
          else
            lc2.SetValue(PC, pc);

          //Gray out start and close, enable stop
          EnableWindow(GetDlgItem(hwnd, IDC_START), FALSE);
          EnableWindow(GetDlgItem(hwnd, IDC_CLOSE), FALSE);
          EnableWindow(GetDlgItem(hwnd, IDC_STOP),  TRUE);
          InterlockedExchange(&gExecuted, 0L);
          InterlockedExchange(&gEngineInstructions,
                              EXECUTE_CONTINUOUS);
          InterlockedExchange(&gEngineStatus, ENGINE_RUNNING);

          //while because thread maybe in idle clause but not yet suspended
          while(!ResumeThread(hEngineThread))
            Sleep(0);
          return(TRUE);
          }

        case IDC_STOP:
          if(gEngineStatus != ENGINE_IDLE)
            InterlockedExchange(&gEngineStatus, ENGINE_GOIDLE);
          while(gEngineStatus != ENGINE_IDLE)
            Sleep(0);

          //gray out stop, enable start and close
          EnableWindow(GetDlgItem(hwnd, IDC_START), TRUE);
          EnableWindow(GetDlgItem(hwnd, IDC_CLOSE), TRUE);
          EnableWindow(GetDlgItem(hwnd, IDC_STOP),  FALSE);

          //Update PC display
          SendMessage(hwnd, WM_INITDIALOG, 0, 0);

          return(TRUE);

        case IDC_CLOSE:
          //Display is updated by hold message from engine thread
          EndDialog(hwnd, 0);
          return(TRUE);

        default:
          return(FALSE);
        }

    case WM_DESTROY:
      hRunDlg = NULL;
      return(FALSE);

    default:
      return(FALSE);
    }
}

BOOL CALLBACK StepDlgProc(HWND hwnd,
                          UINT iMsg,
                          WPARAM wParam,
                          LPARAM lParam)
{
  switch(iMsg)
    {
    case WM_INITDIALOG:
      hStepDlg = hwnd;
      return(TRUE);

    case WM_COMMAND:
      switch(LOWORD(wParam))
        {
        case IDC_STEP:
          {
          BITS pc, instr;
          int goTrap=0;

          EnableWindow(GetDlgItem(hwnd, IDC_STEP), FALSE);

          //Determine if we are stepping over a trap
          lc2.GetValue(PC, &pc);
          lc2.GetValue(pc, &instr);
          if(OPCODE(instr) == TRAP && gStepOverTraps)
            goTrap = 1;

          //Prepare engine thread to go
          InterlockedExchange(&gEngineInstructions, 1L);
          if(goTrap)
            InterlockedExchange(&gEngineStatus, ENGINE_TRAP);
          else
            InterlockedExchange(&gEngineStatus, ENGINE_RUNNING);

          //while because engine may be in GoIdle but not yet suspended
          while(!ResumeThread(hEngineThread))
            Sleep(0);

          return(TRUE);
          }

        case IDC_STOP:

          //gray out stop, enable start and close
          EnableWindow(GetDlgItem(hwnd, IDC_STEP), TRUE);

          return(TRUE);

        case IDC_CLOSE:
          //Display is updated by hold message from engine thread

          //Go idle, in case in trap during stop
          if(gEngineStatus != ENGINE_IDLE)
            InterlockedExchange(&gEngineStatus, ENGINE_GOIDLE);
          while(gEngineStatus != ENGINE_IDLE)
            Sleep(0);

          EndDialog(hwnd, 0);
          return(TRUE);

        default:
          return(FALSE);
        }

    case WM_DESTROY:
      hStepDlg = NULL;
      return(FALSE);

    default:
      return(FALSE);
    }
}

BOOL CALLBACK JumpDlgProc(HWND hwnd,
                          UINT iMsg,
                          WPARAM wParam,
                          LPARAM lParam)
{
  switch(iMsg)
    {
    case WM_INITDIALOG:
      {
      TCHAR locstr[MAX_INPUT+1];

      SendDlgItemMessage(hwnd, IDC_EDITLOC, EM_LIMITTEXT, MAX_INPUT, 0);
      wsprintf(locstr, "x%04x", lParam);
      SetDlgItemText(hwnd, IDC_EDITLOC, locstr);
      return(TRUE);
      }

    case WM_COMMAND:
      switch(LOWORD(wParam))
        {
        case IDOK:
          {
          TCHAR loc[MAX_INPUT+1];
          int iloc, i;
          BITS locConst;

          iloc = GetDlgItemText(hwnd, IDC_EDITLOC, loc, MAX_INPUT+1);

          //Get rid or trailing spaces
          for(i=iloc-1; i>=0; i--)
            if(loc[i] == ' ')
              loc[i] = '\0';
            else
              break;

          //Convert location to uppercase
          CharUpper(loc);

          //Input validation
          if(!isValidVal(loc, &locConst))
            {
            MessageBox(hwnd,
                       "Invalid Location.\n\nThe location must be a 16 bit address.",
                       "Invalid Location",
                       MB_OK | MB_ICONERROR);
            return(TRUE);
            }

          //Do the jump
          CheckMenuItem(GetMenu(hwndSim), IDM_OPTIONS_PC,
                        MF_BYCOMMAND | MF_UNCHECKED);
          gFollowPC = 0;
          SendMessage(hwndSim, WM_MEMRANGE, locConst, 0);

          EndDialog(hwnd, 0);
          return(TRUE);
          }

        case IDCANCEL:
          EndDialog(hwnd, 0);
          return(TRUE);

        default:
          return(FALSE);
        }

    default:
      return(FALSE);
    }
}

BOOL CALLBACK InfiniteLoopDlgProc(HWND hwnd,
                                  UINT iMsg,
                                  WPARAM wParam,
                                  LPARAM lParam)
{
  switch(iMsg)
    {
    case WM_INITDIALOG:
      {
      TCHAR warning[120];

      //Set the text
      wsprintf(warning,
               "Possible infinite loop detected.\n\n%d instructions executed.\n\nDo you wish to continue execution?",
               gExecuted);
      SetDlgItemText(hwnd, IDC_LBL, warning);

      //Set the icon
      SendDlgItemMessage(hwnd, IDC_ICN, STM_SETIMAGE, IMAGE_ICON, 
                         (LPARAM)LoadIcon(NULL, IDI_EXCLAMATION));
      return(TRUE);
      }

    case WM_COMMAND:
      switch(LOWORD(wParam))
        {
        case ID_NO:  //Stop execution
          InterlockedExchange(&gEngineStatus, ENGINE_GOIDLE);
        case ID_YES:
          if(IsDlgButtonChecked(hwnd, IDC_ChkShow) == BST_CHECKED)
            SendMessage(hwndSim, WM_COMMAND, IDM_OPTIONS_LOOP, 0);
          EndDialog(hwnd, 0);
          return(TRUE);
        default:
          return(FALSE);
        }

    default:
      return(FALSE);
    }
}
