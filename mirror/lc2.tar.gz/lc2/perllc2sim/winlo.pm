package winlo;

# LC-2 simulator, Perl version
# Copyright (c) 1998 by Donald C. Winsor
# All rights reserved
# $version = "0.5";

# This package provides a low-level interface
# to the terminal window routines.

# As implemented here, the Perl Curses package
# is used, but by keeping the interface here
# in this package, it should be easy to replace
# it with a different terminal handler.

use Curses;

# Initialize the terminal handler.
# This returns a two-element array containing
# the number of screen lines and columns.

sub init {
  initscr;
  cbreak;
  noecho;
  nonl;
  intrflush(stdscr, FALSE);
  keypad(stdscr, TRUE);
  ($LINES,$COLS);
}

# Put a character on the screen at a specified location

sub putchar {
  my($char, $row, $col) = @_;
  addch($row, $col, $char);
}

# Get a character from the keyboard

sub lo_getch {
  getch;
}

# Refresh the screen

sub update {
  refresh;
}

# Clean up prior to exit.
# This is necessary to undo any destructive changes
# made by "curses" to the terminal mode.

sub cleanup {
  endwin;
}

1;
