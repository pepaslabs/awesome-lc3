package winhi;
use winlo;

# LC-2 simulator, Perl version
# Copyright (c) 1998 by Donald C. Winsor
# All rights reserved
# $version = "0.5";

# High level screen terminal window package.
# This uses a separate low level package for actual I/O,
# so it should be relatively easy to accomodate different
# terminal functionality on different platforms.

# Window initialization - this should be
# called once only at program startup.

sub w_init {
  ($rows, $cols) = winlo::init;
  my $screen = [];
  my $self = {
    "rows"   => $rows,
    "cols"   => $cols,
    "screen" => $screen,
  };
  my ($x, $y);
  for ($x = 0; $x < $rows; $x++) {
    for ($y = 0; $y < $cols; $y++) {
      winlo::putchar(' ', $top + $y, $left + $x, '');
      $$screen[$x][$y] = ' ';
    }
  }
  bless $self;
  return $self;
}

# Cleanup - this should be called
# once only at program exit.

sub w_cleanup {
  winlo::cleanup;
  # print "\n$DEBUG\n";
}

# Functions beginning with "w_" are valid for the whole window

sub w_putchar {
  my($self, $char, $row, $col) = @_;
  my($screen);
  if (($row >= 0) && ($row < $self->{'rows'}) &&
      ($col >= 0) && ($col < $self->{'cols'}) &&
      ($char ge ' ') && ($char le '~')) {
    $screen = $self->{'screen'};
    if ($$screen[$row][$col] ne $char) {
      $$screen[$row][$col] = $char;
      winlo::putchar($char, $row, $col);
      winlo::refresh;
    }
  }
}

sub w_putstr {
  my($self, $str, $row, $col) = @_;
  my($i);
  for ($i = 0; $i < length($str); $i++) {
    $self->w_putchar(substr($str, $i, 1), $row, $col + $i);
  }
}

sub w_getchar {
  my($self, $row, $col) = @_;
  my($char, $pos, $screen);
  $char = ' ';
  if (($row >= 0) && ($row < $self->{'rows'}) &&
      ($col >= 0) && ($col < $self->{'cols'})) {
    $screen = $self->{'screen'};
    $char = $$screen[$row][$col];
  }
  return($char);
}

# Make a terminal subwindow.  Multiple (non-overlapping) terminal
# subwindows are allowed, so this may be called more than once.

sub t_init {
  my ($parent, $top, $left, $trows, $tcols) = @_;
  my $self = {
    "parent" => $parent,
    "top"    => $top,
    "left"   => $left,
    "trows"  => $trows,
    "tcols"  => $tcols,
    "currow" => 0,
    "curcol" => 0,
    "screen" => $parent->{'screen'},
  };
  # winlo::refresh;
  bless $self;
  return $self;
}

# Functions beginning with "t_" are valid for terminal subwindows

# Scroll up

sub t_scrollup {
  my($s) = @_;
  my($row, $col, $char, $w);
  $w = $s->{'parent'};
  for ($row = $s->{'top'}; $row < $s->{'top'} + $s->{'trows'} - 1; $row++) {
    for ($col = $s->{'left'}; $col < $s->{'left'} + $s->{'tcols'}; $col++) {
      $char = $w->w_getchar($row + 1, $col);
      $w->w_putchar($char, $row, $col);
    }
  }
  for ($col = $s->{'left'}; $col < $s->{'left'} + $s->{'tcols'}; $col++) {
    $w->w_putchar(' ', $s->{'top'} + $s->{'trows'} - 1, $col);
  }
}

# Nondestructive cursor advance

sub t_nd {
  my($s) = @_;
  if ($s->{'curcol'} < $s->{'tcols'} - 1) {
    $s->{'curcol'} = $s->{'curcol'} + 1;
  } else {
    $s->t_cr;
    $s->t_do;
  }
}

# Refresh the cursor position in a terminal subwindow

sub t_curset {
  my($s) = @_;
  my($w, $y, $x, $char, $tmp);
  $w = $s->{'parent'};
  $y = $s->{'top'} + $s->{'currow'};
  $x = $s->{'left'} + $s->{'curcol'} - 1;
  $char = $w->w_getchar($y, $x);
  $tmp = ($char eq ' ') ? '_' : ' ';
  $w->w_putchar($tmp, $y, $x);
  winlo::refresh;
  $w->w_putchar($char, $y, $x);
  winlo::refresh;
}

# Refresh the whole screen

sub refr {
  winlo::refresh
}

# Output a string

sub t_putstr {
  my($s, $str) = @_;
  my($w, $i, $char);
  $w = $s->{'parent'};
  for ($i = 0; $i < length($str); $i++) {
    $char = substr($str, $i, 1);
    if (($char ge ' ') && ($char le '~')) {
      $w->w_putchar($char,
        $s->{'top'} + $s->{'currow'}, $s->{'left'} + $s->{'curcol'});
      $s->t_nd;
    } elsif ($char eq "\r") {
      $s->t_cr;
    } elsif ($char eq "\n") {
      $s->t_cr;
      $s->t_do;
    } elsif ($char eq "\b") {
      $s->t_le;
    } elsif ($char eq "\f") {
      $s->t_nd;
    } elsif ($char eq "\006") {
      $s->t_nd;
    }
  }
  winlo::refresh;
}

# Carriage return

sub t_cr {
  my($s) = @_;
  $s->{'curcol'} = 0;
}

# Move the cursor down

sub t_do {
  my($s) = @_;
  if ($s->{'currow'} < $s->{'trows'} - 1) {
    $s->{'currow'} = $s->{'currow'} + 1;
  } else {
    $s->t_scrollup;
    $s->{'currow'} = $s->{'trows'} - 1;
  }
}

# Move the cursor up

sub t_up {
  my($s) = @_;
  if ($s->{'currow'} > 0) {
    $s->{'currow'} = $s->{'currow'} - 1;
  }
}

# Move the cursor left

sub t_le {
  my($s) = @_;
  if ($s->{'curcol'} > 1) {
    $s->{'curcol'} = $s->{'curcol'} - 1;
  } elsif ($s->{'currow'} > 1) {
    $s->t_up;
    $s->{'curcol'} = $s->{'tcols'} - 1;
  }
}

# Move the cursor to the home position (top left)

sub t_ho {
  my($s) = @_;
  $s->{'currow'} = 0;
  $s->{'curcol'} = 0;
}

# Move the cursor to the lower left position

sub t_ll {
  my($s) = @_;
  $s->{'currow'} = $s->{'trows'} - 1;
  $s->{'curcol'} = 0;
}

# Clear the terminal
sub t_cl {
  my($s) = @_;
  my($i);
  $s->t_ho;
  for ($i = 0; $i < $s->{'trows'}; $i++) {
    $s->t_putstr(' ' x $s->{'tcols'});
  }
  $s->t_ho;
}

sub hi_getch {
  &winlo::lo_getch;
}

1;
